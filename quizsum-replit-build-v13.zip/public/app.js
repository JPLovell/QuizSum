// QuizSum Frontend State & Game Engine (v11 with Speed & Pro Modes)
let gameState = {
  mode: 'speed', // 'speed' or 'pro'
  puzzleDate: null,
  target: 0,
  numbers: [],
  solutionsFound: [],
  activeTimeMs: 0,
  timerInterval: null,
  syncInterval: null,
  startTime: null,
  isPaused: false,
  isCompleted: false,
  currentTokens: [] // Array of { type: 'number'|'operator', val: string, tileIndex?: number }
};

let currentLeaderboardType = 'daily';
let currentLeaderboardMode = 'speed';

document.addEventListener('DOMContentLoaded', () => {
  initApp();
  bindEvents();
});

// Sync timer state on mobile navigation & tab visibility changes
window.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    pauseTimer();
  } else if (!gameState.isCompleted && !gameState.isPaused && gameState.puzzleDate) {
    const screenActive = !document.getElementById('screen-active').classList.contains('hidden');
    const modalPauseHidden = document.getElementById('modal-pause').classList.contains('hidden');
    if (screenActive && modalPauseHidden) {
      startTimer();
    }
  }
});

window.addEventListener('pagehide', () => {
  syncTimerWithServer();
});

function getLocalDateString() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

async function initApp() {
  checkAuthStatus();
  await fetchTodayPuzzle();
}

// ------------------------------------------------------------------
// API Interaction
// ------------------------------------------------------------------
async function fetchTodayPuzzle() {
  const localDate = getLocalDateString();
  const startBtn = document.getElementById('btn-start-game');

  startBtn.disabled = true;
  startBtn.textContent = 'LOADING PUZZLE...';

  try {
    const res = await fetch(`/api/daily?date=${localDate}&mode=${gameState.mode}`);
    const data = await res.json();

    if (data.error) {
      alert(data.error);
      return;
    }

    gameState.puzzleDate = data.puzzle_date;
    gameState.mode = data.game_mode || gameState.mode;
    gameState.target = data.target;
    gameState.numbers = data.numbers;
    gameState.currentTokens = [];

    const modeLabel = (gameState.mode === 'pro') ? 'PRO CHALLENGE' : 'SPEED CHALLENGE';
    document.getElementById('daily-date').textContent = `${modeLabel} • ${data.puzzle_date}`;
    document.getElementById('target-number').textContent = data.target;

    // Load timer & game progress from server + localStorage
    let savedMs = 0;
    if (data.user_game) {
      savedMs = data.user_game.active_time_ms || 0;
      gameState.solutionsFound = data.user_game.solutions_found || [];
      gameState.isCompleted = data.user_game.is_completed;
    } else {
      savedMs = 0;
      gameState.solutionsFound = [];
      gameState.isCompleted = false;
    }

    const localMs = parseInt(localStorage.getItem(`quizsum_time_${data.puzzle_date}_${gameState.mode}`) || '0', 10);
    gameState.activeTimeMs = Math.max(savedMs, localMs);

    updateFoundCountDisplay();
    updateTimerDisplay(gameState.activeTimeMs);

    // If completed, present summary screen directly
    if (gameState.isCompleted) {
      showSummaryScreen();
    } else {
      document.getElementById('screen-summary').classList.add('hidden');
      document.getElementById('screen-active').classList.add('hidden');
      document.getElementById('screen-start').classList.remove('hidden');

      if (gameState.activeTimeMs > 0 || gameState.solutionsFound.length > 0) {
        startBtn.textContent = 'CONTINUE PUZZLE';
      } else {
        startBtn.textContent = 'START PUZZLE';
      }
      startBtn.disabled = false;
    }

  } catch (err) {
    console.error('Failed to load puzzle', err);
    document.getElementById('daily-date').textContent = 'Error loading puzzle. Please refresh.';
  }
}

function getAuthHeaders(extra = {}) {
  const token = localStorage.getItem('quizsum_auth_token');
  const h = { ...extra };
  if (token) h['Authorization'] = 'Bearer ' + token;
  return h;
}

async function checkAuthStatus() {
  try {
    const res = await fetch('/api/auth/me', { headers: getAuthHeaders() });
    const data = await res.json();
    if (data.loggedIn && data.user) {
      if (data.token) localStorage.setItem('quizsum_auth_token', data.token);
      localStorage.setItem('quizsum_user', JSON.stringify(data.user));
      document.getElementById('btn-account').textContent = data.user.username;
      document.getElementById('profile-username').textContent = data.user.username;
      document.getElementById('profile-email').textContent = data.user.email;
      document.getElementById('auth-forms').classList.add('hidden');
      document.getElementById('user-profile-view').classList.remove('hidden');
    } else {
      const savedUserStr = localStorage.getItem('quizsum_user');
      const savedToken = localStorage.getItem('quizsum_auth_token');
      if (savedUserStr && savedToken) {
        const savedUser = JSON.parse(savedUserStr);
        document.getElementById('btn-account').textContent = savedUser.username;
        document.getElementById('profile-username').textContent = savedUser.username;
        document.getElementById('profile-email').textContent = savedUser.email;
        document.getElementById('auth-forms').classList.add('hidden');
        document.getElementById('user-profile-view').classList.remove('hidden');
      }
    }
  } catch (err) {
    console.error('Auth check error', err);
  }
}

async function syncTimerWithServer() {
  if (!gameState.puzzleDate || gameState.activeTimeMs <= 0) return;

  localStorage.setItem(`quizsum_time_${gameState.puzzleDate}_${gameState.mode}`, String(gameState.activeTimeMs));

  try {
    await fetch('/api/sync-timer', {
      method: 'POST',
      headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        puzzle_date: gameState.puzzleDate,
        mode: gameState.mode,
        active_time_ms: gameState.activeTimeMs
      })
    });
  } catch (e) {
    // Silent catch
  }
}

// ------------------------------------------------------------------
// Game Logic & Events
// ------------------------------------------------------------------
function bindEvents() {
  // Mode Switcher Bar
  document.getElementById('mode-btn-speed').addEventListener('click', () => switchGameMode('speed'));
  document.getElementById('mode-btn-pro').addEventListener('click', () => switchGameMode('pro'));

  // Start Game Button
  document.getElementById('btn-start-game').addEventListener('click', startGame);

  // Deck & Clear
  document.getElementById('btn-clear').addEventListener('click', clearEquation);
  document.getElementById('btn-backspace').addEventListener('click', backspaceEquation);
  document.getElementById('btn-submit').addEventListener('click', submitEquation);

  // Midway Finish Button
  document.getElementById('btn-finish-midway').addEventListener('click', finishAndRecordScore);

  // Summary Actions
  document.getElementById('btn-share-results').addEventListener('click', shareResults);
  document.getElementById('btn-open-leaderboard-summary').addEventListener('click', () => openLeaderboard('daily', gameState.mode));

  // Operators
  document.querySelectorAll('.op-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      addOperatorToken(btn.dataset.op);
    });
  });

  // Pause Screen Buttons
  document.getElementById('btn-try-another').addEventListener('click', resumeGameSearch);
  document.getElementById('btn-finish-score').addEventListener('click', finishAndRecordScore);

  // Nav Modals
  document.getElementById('btn-account').addEventListener('click', () => {
    clearAuthErrors();
    document.getElementById('modal-account').classList.remove('hidden');
  });
  document.getElementById('close-account').addEventListener('click', () => {
    document.getElementById('modal-account').classList.add('hidden');
  });

  document.getElementById('btn-leaderboard').addEventListener('click', () => openLeaderboard('daily', gameState.mode));
  document.getElementById('close-leaderboard').addEventListener('click', () => {
    document.getElementById('modal-leaderboard').classList.add('hidden');
  });

  // Leaderboard Mode Switchers
  document.querySelectorAll('.lb-mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.lb-mode-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      openLeaderboard(currentLeaderboardType, btn.dataset.lbMode);
    });
  });

  // Leaderboard Timeframe Tabs
  document.querySelectorAll('.lb-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.lb-tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      openLeaderboard(btn.dataset.type, currentLeaderboardMode);
    });
  });

  // Auth form switches
  document.getElementById('switch-to-register').addEventListener('click', (e) => {
    e.preventDefault();
    clearAuthErrors();
    document.getElementById('login-section').classList.add('hidden');
    document.getElementById('register-section').classList.remove('hidden');
  });
  document.getElementById('switch-to-login').addEventListener('click', (e) => {
    e.preventDefault();
    clearAuthErrors();
    document.getElementById('register-section').classList.add('hidden');
    document.getElementById('login-section').classList.remove('hidden');
  });

  // Auth Forms Submit
  document.getElementById('form-login').addEventListener('submit', handleLogin);
  document.getElementById('form-register').addEventListener('submit', handleRegister);
  document.getElementById('btn-logout').addEventListener('click', handleLogout);
}

async function switchGameMode(newMode) {
  if (gameState.mode === newMode) return;

  pauseTimer();

  gameState.mode = newMode;

  document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`mode-btn-${newMode}`).classList.add('active');

  // Update Pre-Start Box visuals
  if (newMode === 'pro') {
    document.getElementById('mode-badge-icon').textContent = '🧠';
    document.getElementById('mode-title').textContent = "Ready for Today's Pro Challenge?";
    document.getElementById('mode-description').textContent = "Deeper multi-solution mathematical challenge! Find as many valid equation paths as you can.";
  } else {
    document.getElementById('mode-badge-icon').textContent = '⚡';
    document.getElementById('mode-title').textContent = "Ready for Today's Speed Challenge?";
    document.getElementById('mode-description').textContent = "Connect tiles to hit the target number as fast as you can. Clean, fun daily math!";
  }

  await fetchTodayPuzzle();
}

function startGame() {
  if (!gameState.target || gameState.numbers.length === 0) {
    alert('Puzzle is still loading. Please wait a moment.');
    return;
  }

  document.getElementById('screen-start').classList.add('hidden');
  document.getElementById('screen-summary').classList.add('hidden');
  document.getElementById('screen-active').classList.remove('hidden');

  document.getElementById('target-number').textContent = gameState.target;
  renderTiles();

  if (!gameState.isCompleted) {
    startTimer();
  }
}

function renderTiles() {
  const container = document.getElementById('tiles-container');
  container.innerHTML = '';

  gameState.numbers.forEach((num, index) => {
    const tile = document.createElement('button');
    tile.className = 'num-tile';
    tile.textContent = num;
    tile.dataset.index = index;
    tile.addEventListener('click', () => handleTileClick(num, index));
    container.appendChild(tile);
  });
}

function handleTileClick(num, index) {
  const tileEl = document.querySelector(`.num-tile[data-index="${index}"]`);
  if (tileEl.classList.contains('used')) return;

  tileEl.classList.add('used');
  gameState.currentTokens.push({ type: 'number', val: num, tileIndex: index });
  renderEquationDisplay();
}

function addOperatorToken(op) {
  gameState.currentTokens.push({ type: 'operator', val: op });
  renderEquationDisplay();
}

function clearEquation() {
  gameState.currentTokens = [];
  document.querySelectorAll('.num-tile').forEach(t => t.classList.remove('used'));
  renderEquationDisplay();
}

function backspaceEquation() {
  const popped = gameState.currentTokens.pop();
  if (popped && popped.type === 'number') {
    const tileEl = document.querySelector(`.num-tile[data-index="${popped.tileIndex}"]`);
    if (tileEl) tileEl.classList.remove('used');
  }
  renderEquationDisplay();
}

function renderEquationDisplay() {
  const box = document.getElementById('equation-display');
  if (gameState.currentTokens.length === 0) {
    box.innerHTML = '<span class="placeholder-text">Tap tiles & operators to build equation...</span>';
    return;
  }

  box.textContent = gameState.currentTokens.map(t => t.val).join(' ');
}

// ------------------------------------------------------------------
// Timer (Stopwatch) Engine with Persistence
// ------------------------------------------------------------------
function startTimer() {
  if (gameState.timerInterval) clearInterval(gameState.timerInterval);
  if (gameState.syncInterval) clearInterval(gameState.syncInterval);

  gameState.startTime = Date.now() - gameState.activeTimeMs;
  gameState.isPaused = false;

  gameState.timerInterval = setInterval(() => {
    if (!gameState.isPaused) {
      gameState.activeTimeMs = Date.now() - gameState.startTime;
      updateTimerDisplay(gameState.activeTimeMs);
    }
  }, 100);

  gameState.syncInterval = setInterval(() => {
    if (!gameState.isPaused) {
      syncTimerWithServer();
    }
  }, 5000);
}

function pauseTimer() {
  gameState.isPaused = true;
  if (gameState.timerInterval) clearInterval(gameState.timerInterval);
  if (gameState.syncInterval) clearInterval(gameState.syncInterval);
  syncTimerWithServer();
}

function updateTimerDisplay(ms) {
  const totalSec = Math.floor(ms / 1000);
  const mins = String(Math.floor(totalSec / 60)).padStart(2, '0');
  const secs = String(totalSec % 60).padStart(2, '0');
  const tenths = Math.floor((ms % 1000) / 100);

  document.getElementById('timer-display').textContent = `${mins}:${secs}.${tenths}`;
}

// ------------------------------------------------------------------
// Solution Verification & Pause Screen (Anti-Cheat Blur)
// ------------------------------------------------------------------
async function submitEquation() {
  if (gameState.currentTokens.length === 0) return;

  const equationStr = gameState.currentTokens.map(t => t.val).join(' ');

  try {
    const res = await fetch(`/api/verify?date=${gameState.puzzleDate || getLocalDateString()}&mode=${gameState.mode}`, {
      method: 'POST',
      headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        equation: equationStr,
        mode: gameState.mode,
        active_time_ms: gameState.activeTimeMs
      })
    });

    const data = await res.json();

    if (data.is_correct) {
      pauseTimer();
      gameState.solutionsFound = data.solutions_found;
      updateFoundCountDisplay();

      document.getElementById('latest-solution-box').textContent = `${equationStr} = ${gameState.target}`;
      document.getElementById('modal-pause').classList.remove('hidden');
      clearEquation();
    } else {
      showFeedback(data.message || 'Invalid equation', 'error');
    }
  } catch (err) {
    showFeedback('Error verifying submission', 'error');
  }
}

function resumeGameSearch() {
  document.getElementById('modal-pause').classList.add('hidden');
  startTimer();
}

async function finishAndRecordScore() {
  pauseTimer();
  gameState.isCompleted = true;
  document.getElementById('modal-pause').classList.add('hidden');

  try {
    const res = await fetch(`/api/finish?date=${gameState.puzzleDate || getLocalDateString()}&mode=${gameState.mode}`, {
      method: 'POST',
      headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        mode: gameState.mode,
        active_time_ms: gameState.activeTimeMs
      })
    });

    const data = await res.json();

    showSummaryScreen();

    if (data.is_guest) {
      clearAuthErrors();
      document.getElementById('modal-account').classList.remove('hidden');
      document.getElementById('register-section').classList.remove('hidden');
      document.getElementById('login-section').classList.add('hidden');
      document.getElementById('auth-title').textContent = '🏆 Save Score to Leaderboard!';
    }
  } catch (err) {
    console.error('Error finishing game', err);
    showSummaryScreen();
  }
}

function showSummaryScreen() {
  document.getElementById('screen-start').classList.add('hidden');
  document.getElementById('screen-active').classList.add('hidden');
  document.getElementById('screen-summary').classList.remove('hidden');

  const modeBadge = (gameState.mode === 'pro') ? '🧠 PRO MODE COMPLETE' : '⚡ SPEED MODE COMPLETE';
  document.getElementById('summary-mode-badge').textContent = modeBadge;
  document.getElementById('summary-target-val').textContent = gameState.target;
  document.getElementById('summary-solutions-count').textContent = gameState.solutionsFound.length;

  const totalSec = Math.floor(gameState.activeTimeMs / 1000);
  const mins = String(Math.floor(totalSec / 60)).padStart(2, '0');
  const secs = String(totalSec % 60).padStart(2, '0');
  const tenths = Math.floor((gameState.activeTimeMs % 1000) / 100);
  document.getElementById('summary-final-time').textContent = `${mins}:${secs}.${tenths}`;

  const listContainer = document.getElementById('summary-solutions-list');
  if (gameState.solutionsFound.length === 0) {
    listContainer.innerHTML = '<p class="no-solutions-text">No valid solutions submitted for this puzzle.</p>';
  } else {
    listContainer.innerHTML = gameState.solutionsFound
      .map(eq => `<div class="solution-item"><span>✅</span> <strong>${eq} = ${gameState.target}</strong></div>`)
      .join('');
  }
}

function shareResults() {
  const totalSec = Math.floor(gameState.activeTimeMs / 1000);
  const mins = String(Math.floor(totalSec / 60)).padStart(2, '0');
  const secs = String(totalSec % 60).padStart(2, '0');
  const modeName = (gameState.mode === 'pro') ? '🧠 Pro Mode' : '⚡ Speed Mode';

  const shareText = `QuizSum Daily (${gameState.puzzleDate})\n${modeName}\n🎯 Target: ${gameState.target}\n💡 Solutions Found: ${gameState.solutionsFound.length}\n⏱️ Time: ${mins}:${secs}\n\nPlay today's puzzle at quizsum.onrender.com!`;

  navigator.clipboard.writeText(shareText).then(() => {
    const toast = document.getElementById('share-toast');
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 3000);
  }).catch(() => {
    alert(shareText);
  });
}

function updateFoundCountDisplay() {
  document.getElementById('found-count').textContent = gameState.solutionsFound.length;
}

function showFeedback(msg, type) {
  const banner = document.getElementById('feedback-msg');
  banner.textContent = msg;
  banner.className = `feedback-banner ${type}`;
  banner.classList.remove('hidden');

  setTimeout(() => {
    banner.classList.add('hidden');
  }, 3000);
}

function showAuthError(msg) {
  const box = document.getElementById('auth-error-msg');
  box.textContent = msg;
  box.classList.remove('hidden');
}

function clearAuthErrors() {
  const box = document.getElementById('auth-error-msg');
  box.textContent = '';
  box.classList.add('hidden');
}

// ------------------------------------------------------------------
// Leaderboard & Authentication
// ------------------------------------------------------------------
async function openLeaderboard(type = 'daily', mode = null) {
  currentLeaderboardType = type;
  currentLeaderboardMode = mode || gameState.mode || 'speed';

  // Update active UI tabs
  document.querySelectorAll('.lb-mode-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.lbMode === currentLeaderboardMode);
  });

  try {
    const res = await fetch(`/api/leaderboard?type=${type}&mode=${currentLeaderboardMode}&date=${gameState.puzzleDate || getLocalDateString()}`);
    const data = await res.json();

    const container = document.getElementById('leaderboard-list');
    if (!data.leaderboard || data.leaderboard.length === 0) {
      container.innerHTML = '<p style="text-align:center; color: var(--text-muted); padding: 1.5rem 0;">No recorded scores yet for this mode. Be the first!</p>';
    } else {
      const isMultiDay = type === 'weekly' || type === 'overall';

      let html = `<table class="lb-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Player</th>
            <th>Solutions</th>
            <th>${isMultiDay ? 'Puzzles' : 'Time'}</th>
          </tr>
        </thead>
        <tbody>`;

      data.leaderboard.forEach((row, idx) => {
        const sec = Math.floor(row.active_time_ms / 1000);
        const mins = String(Math.floor(sec / 60)).padStart(2, '0');
        const secs = String(sec % 60).padStart(2, '0');

        html += `<tr>
          <td><strong>${idx + 1}</strong></td>
          <td>${row.username}</td>
          <td><strong style="color:var(--gold-color)">${row.solutions_count}</strong></td>
          <td>${isMultiDay ? row.games_played : `${mins}:${secs}`}</td>
        </tr>`;
      });

      html += '</tbody></table>';
      container.innerHTML = html;
    }

    document.getElementById('modal-leaderboard').classList.remove('hidden');
  } catch (err) {
    console.error('Leaderboard error', err);
  }
}

async function handleLogin(e) {
  e.preventDefault();
  clearAuthErrors();

  const userOrEmail = document.getElementById('login-user').value;
  const pass = document.getElementById('login-pass').value;

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ username_or_email: userOrEmail, password: pass })
    });

    const data = await res.json();
    if (data.success) {
      if (data.token) localStorage.setItem('quizsum_auth_token', data.token);
      if (data.user) localStorage.setItem('quizsum_user', JSON.stringify(data.user));
      location.reload();
    } else {
      showAuthError(data.error || 'Login failed.');
    }
  } catch (err) {
    showAuthError('Login failed. Please check your network connection.');
  }
}

async function handleRegister(e) {
  e.preventDefault();
  clearAuthErrors();

  const username = document.getElementById('reg-user').value;
  const email = document.getElementById('reg-email').value;
  const password = document.getElementById('reg-pass').value;
  const email_opt_in = document.getElementById('reg-optin').checked;

  const puzzleDate = gameState.puzzleDate || getLocalDateString();

  try {
    const res = await fetch(`/api/auth/register?date=${puzzleDate}&mode=${gameState.mode}`, {
      method: 'POST',
      headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ username, email, password, email_opt_in })
    });

    const data = await res.json();
    if (data.success) {
      try {
        await fetch(`/api/finish?date=${puzzleDate}&mode=${gameState.mode}`, {
          method: 'POST',
          headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ mode: gameState.mode, active_time_ms: gameState.activeTimeMs })
        });
      } catch (fErr) {
        // silent
      }
      location.reload();
    } else {
      showAuthError(data.error || 'Registration failed.');
    }
  } catch (err) {
    showAuthError('Registration failed. Please check your network connection.');
  }
}

async function handleLogout() {
  localStorage.removeItem('quizsum_auth_token');
  localStorage.removeItem('quizsum_user');
  await fetch('/api/auth/logout', { method: 'POST', headers: getAuthHeaders() });
  location.reload();
}
