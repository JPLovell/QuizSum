const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const path = require('path');
const { db, parseAndEvaluate, getOrGenerateDailyPuzzle } = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

// Render/Replit Proxy Trust
app.set('trust proxy', 1);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'quizsum-secret-key-replit-2026',
    resave: false,
    saveUninitialized: true,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      sameSite: 'lax',
      secure: false // allow fallback on non-HTTPS local dev
    }
  })
);

// Helper: Extract user ID from session or Bearer Auth Token (Persistent across server restarts)
function getUserIdFromReq(req) {
  if (req.session && req.session.userId) {
    return req.session.userId;
  }

  const authHeader = req.headers.authorization || '';
  let token = null;

  if (authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  } else if (req.query && req.query.auth_token) {
    token = req.query.auth_token;
  } else if (req.body && req.body.auth_token) {
    token = req.body.auth_token;
  }

  if (token) {
    const user = db.prepare('SELECT id, username FROM users WHERE auth_token = ?').get(token);
    if (user) {
      if (req.session) {
        req.session.userId = user.id;
        req.session.username = user.username;
      }
      return user.id;
    }
  }

  return null;
}

// Helpers
function getSanitizedDate(req) {
  const reqDate = req.query.date || req.body.date || req.body.puzzle_date;
  if (reqDate && /^\d{4}-\d{2}-\d{2}$/.test(reqDate)) {
    return reqDate;
  }
  return new Date().toISOString().split('T')[0];
}

function getSanitizedMode(req) {
  const mode = req.query.mode || req.body.mode || req.body.game_mode;
  if (mode === 'pro') return 'pro';
  return 'speed'; // Default mode is Speed
}

// Helper: Auto-publish user scores to leaderboards
function syncUserScoresToLeaderboard(userId, username) {
  try {
    const completedGames = db.prepare(`
      SELECT puzzle_date, game_mode, solutions_found, active_time_ms
      FROM user_daily_games
      WHERE user_id = ? AND is_completed = 1
    `).all(userId);

    for (const game of completedGames) {
      const solutions = JSON.parse(game.solutions_found || '[]');
      if (solutions.length > 0) {
        db.prepare(`
          INSERT INTO leaderboards (puzzle_date, game_mode, user_id, username, solutions_count, active_time_ms)
          VALUES (?, ?, ?, ?, ?, ?)
          ON CONFLICT(puzzle_date, game_mode, user_id) DO UPDATE SET
            solutions_count = excluded.solutions_count,
            active_time_ms = excluded.active_time_ms
        `).run(game.puzzle_date, game.game_mode, userId, username, solutions.length, game.active_time_ms);
      }
    }
  } catch (err) {
    console.error('Error syncing scores to leaderboard:', err.message);
  }
}

// ------------------------------------------------------------------
// 1. GET /api/daily - Fetch today's target & numbers by mode
// ------------------------------------------------------------------
app.get('/api/daily', (req, res) => {
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);
  const puzzle = getOrGenerateDailyPuzzle(today, mode);

  if (!puzzle) {
    return res.status(500).json({ error: 'Could not generate daily puzzle.' });
  }

  const userId = getUserIdFromReq(req);
  const guestId = req.session ? req.session.id : 'guest-fallback';

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(userId, today, mode);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?').get(guestId, today, mode);
  }

  res.json({
    puzzle_date: puzzle.puzzle_date,
    game_mode: puzzle.game_mode,
    target: puzzle.target,
    numbers: JSON.parse(puzzle.numbers),
    user_game: gameRecord ? {
      active_time_ms: gameRecord.active_time_ms,
      solutions_found: JSON.parse(gameRecord.solutions_found),
      is_completed: Boolean(gameRecord.is_completed)
    } : null
  });
});

// ------------------------------------------------------------------
// 2. POST /api/sync-timer - Periodically save stopwatch progress
// ------------------------------------------------------------------
app.post('/api/sync-timer', (req, res) => {
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);
  const { active_time_ms } = req.body;

  const userId = getUserIdFromReq(req);
  const guestId = req.session ? req.session.id : 'guest-fallback';

  if (active_time_ms === undefined || active_time_ms === null) {
    return res.status(400).json({ error: 'Valid active_time_ms required.' });
  }

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(userId, today, mode);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?').get(guestId, today, mode);
  }

  if (gameRecord) {
    const updatedTime = Math.max(gameRecord.active_time_ms, active_time_ms);
    db.prepare('UPDATE user_daily_games SET active_time_ms = ? WHERE id = ?').run(updatedTime, gameRecord.id);
  } else {
    db.prepare(`
      INSERT INTO user_daily_games (user_id, guest_session_id, puzzle_date, game_mode, active_time_ms, solutions_found, canonical_paths)
      VALUES (?, ?, ?, ?, ?, '[]', '[]')
    `).run(userId, guestId, today, mode, active_time_ms);
  }

  res.json({ success: true, active_time_ms, mode });
});

// ------------------------------------------------------------------
// 3. POST /api/verify - Verify equation path & deduplicate
// ------------------------------------------------------------------
app.post('/api/verify', (req, res) => {
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);
  const { equation, active_time_ms } = req.body;

  const puzzle = getOrGenerateDailyPuzzle(today, mode);
  if (!puzzle) {
    return res.status(500).json({ error: 'Daily puzzle not found.' });
  }

  const availableNumbers = JSON.parse(puzzle.numbers);
  const evalResult = parseAndEvaluate(equation, availableNumbers);

  if (!evalResult.valid) {
    return res.json({ is_correct: false, message: evalResult.reason });
  }

  if (evalResult.value !== puzzle.target) {
    return res.json({
      is_correct: false,
      message: `Equation equals ${evalResult.value}, but target is ${puzzle.target}.`
    });
  }

  const userId = getUserIdFromReq(req);
  const guestId = req.session ? req.session.id : 'guest-fallback';

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(userId, today, mode);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?').get(guestId, today, mode);
  }

  let solutionsFound = gameRecord ? JSON.parse(gameRecord.solutions_found) : [];
  let canonicalPaths = gameRecord ? JSON.parse(gameRecord.canonical_paths) : [];

  if (canonicalPaths.includes(evalResult.canonical)) {
    return res.json({
      is_correct: false,
      message: 'You already discovered this exact mathematical path!'
    });
  }

  solutionsFound.push(equation);
  canonicalPaths.push(evalResult.canonical);

  const updatedTime = Math.max(gameRecord ? gameRecord.active_time_ms : 0, active_time_ms || 0);

  if (gameRecord) {
    db.prepare(`
      UPDATE user_daily_games 
      SET solutions_found = ?, canonical_paths = ?, active_time_ms = ?
      WHERE id = ?
    `).run(JSON.stringify(solutionsFound), JSON.stringify(canonicalPaths), updatedTime, gameRecord.id);
  } else {
    db.prepare(`
      INSERT INTO user_daily_games (user_id, guest_session_id, puzzle_date, game_mode, active_time_ms, solutions_found, canonical_paths)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(userId, guestId, today, mode, updatedTime, JSON.stringify(solutionsFound), JSON.stringify(canonicalPaths));
  }

  res.json({
    is_correct: true,
    message: 'Valid solution!',
    solutions_count: solutionsFound.length,
    solutions_found: solutionsFound
  });
});

// ------------------------------------------------------------------
// 4. POST /api/finish - Lock score & publish to leaderboard
// ------------------------------------------------------------------
app.post('/api/finish', (req, res) => {
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);
  const { active_time_ms } = req.body;

  const userId = getUserIdFromReq(req);
  const guestId = req.session ? req.session.id : 'guest-fallback';

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(userId, today, mode);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?').get(guestId, today, mode);
  }

  if (!gameRecord) {
    return res.status(400).json({ error: 'No active game session found.' });
  }

  const finalTime = Math.max(gameRecord.active_time_ms, active_time_ms || gameRecord.active_time_ms);
  const solutions = JSON.parse(gameRecord.solutions_found || '[]');

  db.prepare('UPDATE user_daily_games SET is_completed = 1, active_time_ms = ? WHERE id = ?').run(finalTime, gameRecord.id);

  let leaderboardPosition = null;
  if (userId) {
    const user = db.prepare('SELECT username FROM users WHERE id = ?').get(userId);
    if (user && solutions.length > 0) {
      db.prepare(`
        INSERT INTO leaderboards (puzzle_date, game_mode, user_id, username, solutions_count, active_time_ms)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(puzzle_date, game_mode, user_id) DO UPDATE SET
          solutions_count = excluded.solutions_count,
          active_time_ms = excluded.active_time_ms
      `).run(today, mode, userId, user.username, solutions.length, finalTime);

      const higherRanks = db.prepare(`
        SELECT COUNT(*) as rank FROM leaderboards
        WHERE puzzle_date = ? AND game_mode = ? AND (solutions_count > ? OR (solutions_count = ? AND active_time_ms < ?))
      `).get(today, mode, solutions.length, solutions.length, finalTime).rank;

      leaderboardPosition = higherRanks + 1;
    }
  }

  res.json({
    is_completed: true,
    solutions_found_count: solutions.length,
    solutions_found: solutions,
    final_time_ms: finalTime,
    leaderboard_position: leaderboardPosition,
    is_guest: !userId
  });
});

// ------------------------------------------------------------------
// 5. GET /api/leaderboard - Daily, Weekly, and Overall Leaderboard by Mode
// ------------------------------------------------------------------
app.get('/api/leaderboard', (req, res) => {
  const type = (req.query.type || 'daily').toLowerCase();
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);

  if (type === 'weekly') {
    const d = new Date(today);
    d.setDate(d.getDate() - 7);
    const sevenDaysAgo = d.toISOString().split('T')[0];

    const rows = db.prepare(`
      SELECT username, 
             SUM(solutions_count) as solutions_count, 
             SUM(active_time_ms) as active_time_ms, 
             COUNT(DISTINCT puzzle_date) as games_played
      FROM leaderboards
      WHERE puzzle_date >= ? AND game_mode = ?
      GROUP BY user_id, username
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(sevenDaysAgo, mode);

    return res.json({ type: 'weekly', game_mode: mode, leaderboard: rows });
  } else if (type === 'overall') {
    const rows = db.prepare(`
      SELECT username, 
             SUM(solutions_count) as solutions_count, 
             SUM(active_time_ms) as active_time_ms, 
             COUNT(DISTINCT puzzle_date) as games_played
      FROM leaderboards
      WHERE game_mode = ?
      GROUP BY user_id, username
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(mode);

    return res.json({ type: 'overall', game_mode: mode, leaderboard: rows });
  } else {
    const rows = db.prepare(`
      SELECT username, solutions_count, active_time_ms, created_at 
      FROM leaderboards 
      WHERE puzzle_date = ? AND game_mode = ?
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(today, mode);

    return res.json({ type: 'daily', game_mode: mode, puzzle_date: today, leaderboard: rows });
  }
});

// ------------------------------------------------------------------
// 6. Auth Routes (Register, Login, Logout, Me)
// ------------------------------------------------------------------
app.post('/api/auth/register', (req, res) => {
  const { username, email, password, email_opt_in } = req.body;

  const cleanUser = (username || '').trim();
  const cleanEmail = (email || '').trim().toLowerCase();
  const cleanPass = (password || '').trim();

  if (!cleanUser || cleanUser.length < 3) {
    return res.status(400).json({ error: 'Username must be at least 3 characters.' });
  }
  if (!cleanEmail || !cleanEmail.includes('@')) {
    return res.status(400).json({ error: 'Valid email address required.' });
  }
  if (!cleanPass || cleanPass.length < 4) {
    return res.status(400).json({ error: 'Password must be at least 4 characters.' });
  }

  const existingUser = db.prepare('SELECT id FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)').get(cleanUser, cleanEmail);
  if (existingUser) {
    return res.status(400).json({ error: 'Username or email already registered. Please log in.' });
  }

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(cleanPass, salt);
  const authToken = crypto.randomBytes(32).toString('hex');

  try {
    const result = db.prepare(`
      INSERT INTO users (username, email, password_hash, auth_token, email_opt_in)
      VALUES (?, ?, ?, ?, ?)
    `).run(cleanUser, cleanEmail, hash, authToken, email_opt_in ? 1 : 0);

    const newUserId = result.lastInsertRowid;

    if (req.session) {
      req.session.userId = newUserId;
      req.session.username = cleanUser;
    }

    // Migrate guest game record & publish score to leaderboard
    try {
      const today = getSanitizedDate(req);
      const mode = getSanitizedMode(req);
      const guestId = req.session ? req.session.id : null;

      if (guestId) {
        db.prepare('UPDATE user_daily_games SET user_id = ? WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?')
          .run(newUserId, guestId, today, mode);
      }

      syncUserScoresToLeaderboard(newUserId, cleanUser);
    } catch (migErr) {
      console.error('Non-fatal guest record migration notice:', migErr.message);
    }

    res.json({
      success: true,
      user: { id: newUserId, username: cleanUser, email: cleanEmail },
      token: authToken
    });
  } catch (err) {
    console.error('Registration DB Error:', err);
    return res.status(500).json({ error: 'Account registration failed. Please try again.' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { username_or_email, password } = req.body;

  const cleanCred = (username_or_email || '').trim();
  const cleanPass = (password || '').trim();

  if (!cleanCred || !cleanPass) {
    return res.status(400).json({ error: 'Username/email and password are required.' });
  }

  const user = db.prepare(`
    SELECT * FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)
  `).get(cleanCred, cleanCred.toLowerCase());

  if (!user || !bcrypt.compareSync(cleanPass, user.password_hash)) {
    return res.status(400).json({ error: 'Invalid username/email or password.' });
  }

  // Ensure persistent token exists
  let authToken = user.auth_token;
  if (!authToken) {
    authToken = crypto.randomBytes(32).toString('hex');
    db.prepare('UPDATE users SET auth_token = ? WHERE id = ?').run(authToken, user.id);
  }

  if (req.session) {
    req.session.userId = user.id;
    req.session.username = user.username;
  }

  // Link any current guest game and sync leaderboards
  try {
    const today = getSanitizedDate(req);
    const mode = getSanitizedMode(req);
    const guestId = req.session ? req.session.id : null;

    if (guestId) {
      const existingUserGame = db.prepare('SELECT id FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(user.id, today, mode);
      if (!existingUserGame) {
        db.prepare('UPDATE user_daily_games SET user_id = ? WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?')
          .run(user.id, guestId, today, mode);
      }
    }

    syncUserScoresToLeaderboard(user.id, user.username);
  } catch (migErr) {
    console.error('Non-fatal login guest sync notice:', migErr.message);
  }

  res.json({
    success: true,
    user: { id: user.id, username: user.username, email: user.email },
    token: authToken
  });
});

app.post('/api/auth/logout', (req, res) => {
  if (req.session) req.session.destroy();
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  const userId = getUserIdFromReq(req);
  if (userId) {
    const user = db.prepare('SELECT id, username, email, email_opt_in, auth_token FROM users WHERE id = ?').get(userId);
    if (user) {
      return res.json({
        loggedIn: true,
        user: { id: user.id, username: user.username, email: user.email },
        token: user.auth_token
      });
    }
  }
  res.json({ loggedIn: false });
});

// Start server
app.listen(PORT, () => {
  console.log(`QuizSum server running on port ${PORT}`);
});
