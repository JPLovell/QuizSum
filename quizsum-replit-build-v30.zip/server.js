const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const path = require('path');
const { db, parseAndEvaluate, getOrGenerateDailyPuzzle } = require('./database');
const { sendResendNotification, sendCompletionNotification, sendDailyDigestNotifications } = require('./mailer');

const app = express();
const PORT = process.env.PORT || 3000;

// Render/Replit Proxy Trust
app.set('trust proxy', 1);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'quizsum-secret-key-replit-2026',
    resave: false,
    saveUninitialized: true,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      sameSite: 'lax',
      secure: false // allow fallback on non-HTTPS local dev
    }
  })
);

// Helper: Extract user ID from session or Bearer Auth Token (Persistent across server restarts)
function getUserIdFromReq(req) {
  if (req.session && req.session.userId) {
    return req.session.userId;
  }

  const authHeader = req.headers.authorization || '';
  let token = null;

  if (authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  } else if (req.query && req.query.auth_token) {
    token = req.query.auth_token;
  } else if (req.body && req.body.auth_token) {
    token = req.body.auth_token;
  }

  if (token) {
    let user = db.prepare('SELECT id, username FROM users WHERE auth_token = ?').get(token);
    
    // Auto-heal / auto-recreate user if token missing on ephemeral container reset
    if (!user) {
      const headerUser = req.headers['x-quizsum-username'] || (req.body && req.body.username);
      const headerEmail = req.headers['x-quizsum-email'] || (req.body && req.body.email) || ((headerUser || 'user') + '@quizsum.local');
      if (headerUser && headerUser.trim().length >= 3) {
        const cleanUser = headerUser.trim();
        const cleanEmail = headerEmail.trim().toLowerCase();
        try {
          const dummyHash = bcrypt.hashSync('auto-restored-account', 10);
          const res = db.prepare(`
            INSERT INTO users (username, email, password_hash, auth_token, email_opt_in)
            VALUES (?, ?, ?, ?, 1)
          `).run(cleanUser, cleanEmail, dummyHash, token);
          user = { id: res.lastInsertRowid, username: cleanUser };
        } catch (e) {
          user = db.prepare('SELECT id, username FROM users WHERE LOWER(username) = LOWER(?)').get(cleanUser);
        }
      }
    }

    if (user) {
      if (req.session) {
        req.session.userId = user.id;
        req.session.username = user.username;
      }
      return user.id;
    }
  }

  return null;
}

// Helpers
function getSanitizedDate(req) {
  const reqDate = req.query.date || req.body.date || req.body.puzzle_date;
  if (reqDate && /^\d{4}-\d{2}-\d{2}$/.test(reqDate)) {
    return reqDate;
  }
  return new Date().toISOString().split('T')[0];
}

function getSanitizedMode(req) {
  const mode = req.query.mode || req.body.mode || req.body.game_mode;
  if (mode === 'pro') return 'pro';
  return 'speed'; // Default mode is Speed
}

// Helper: Auto-publish user scores to leaderboards
function syncUserScoresToLeaderboard(userId, username) {
  try {
    const completedGames = db.prepare(`
      SELECT puzzle_date, game_mode, solutions_found, active_time_ms
      FROM user_daily_games
      WHERE user_id = ? AND is_completed = 1
    `).all(userId);

    for (const game of completedGames) {
      const solutions = JSON.parse(game.solutions_found || '[]');
      if (solutions.length > 0) {
        db.prepare(`
          INSERT INTO leaderboards (puzzle_date, game_mode, user_id, username, solutions_count, active_time_ms)
          VALUES (?, ?, ?, ?, ?, ?)
          ON CONFLICT(puzzle_date, game_mode, user_id) DO UPDATE SET
            solutions_count = excluded.solutions_count,
            active_time_ms = excluded.active_time_ms
        `).run(game.puzzle_date, game.game_mode, userId, username, solutions.length, game.active_time_ms);
      }
    }
  } catch (err) {
    console.error('Error syncing scores to leaderboard:', err.message);
  }
}

// ------------------------------------------------------------------
// 1. GET /api/daily - Fetch today's target & numbers by mode
// ------------------------------------------------------------------
app.get('/api/daily', (req, res) => {
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);
  const puzzle = getOrGenerateDailyPuzzle(today, mode);

  if (!puzzle) {
    return res.status(500).json({ error: 'Could not generate daily puzzle.' });
  }

  const userId = getUserIdFromReq(req);
  const guestId = req.session ? req.session.id : 'guest-fallback';

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(userId, today, mode);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?').get(guestId, today, mode);
  }

  const totalUsers = db.prepare('SELECT COUNT(*) AS count FROM users').get().count;

  res.json({
    puzzle_date: puzzle.puzzle_date,
    game_mode: puzzle.game_mode,
    target: puzzle.target,
    numbers: JSON.parse(puzzle.numbers),
    registered_players: totalUsers,
    user_game: gameRecord ? {
      active_time_ms: gameRecord.active_time_ms,
      solutions_found: JSON.parse(gameRecord.solutions_found),
      is_completed: Boolean(gameRecord.is_completed)
    } : null
  });
});

// ------------------------------------------------------------------
// GET /api/puzzles/yesterday - Fetch yesterday's puzzle & full solution breakdown
// ------------------------------------------------------------------
app.get('/api/puzzles/yesterday', (req, res) => {
  try {
    const now = new Date();
    const yesterdayDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const yesterday = yesterdayDate.toISOString().split('T')[0];

    const speedPuzzle = getOrGenerateDailyPuzzle(yesterday, 'speed');
    const proPuzzle = getOrGenerateDailyPuzzle(yesterday, 'pro');

    const speedSolutions = speedPuzzle ? JSON.parse(speedPuzzle.solutions_json || '[]') : [];
    const proSolutions = proPuzzle ? JSON.parse(proPuzzle.solutions_json || '[]') : [];

    res.json({
      puzzle_date: yesterday,
      speed: {
        target: speedPuzzle ? speedPuzzle.target : null,
        numbers: speedPuzzle ? JSON.parse(speedPuzzle.numbers) : [],
        solutions: speedSolutions
      },
      pro: {
        target: proPuzzle ? proPuzzle.target : null,
        numbers: proPuzzle ? JSON.parse(proPuzzle.numbers) : [],
        solutions_count: proSolutions.length,
        solutions: proSolutions
      }
    });
  } catch (err) {
    console.error('Error fetching yesterday solutions:', err);
    res.status(500).json({ error: 'Could not fetch yesterday solutions' });
  }
});

// ------------------------------------------------------------------
// 2. POST /api/sync-timer - Periodically save stopwatch progress
// ------------------------------------------------------------------
app.post('/api/sync-timer', (req, res) => {
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);
  const { active_time_ms } = req.body;

  const userId = getUserIdFromReq(req);
  const guestId = req.session ? req.session.id : 'guest-fallback';

  if (active_time_ms === undefined || active_time_ms === null) {
    return res.status(400).json({ error: 'Valid active_time_ms required.' });
  }

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(userId, today, mode);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?').get(guestId, today, mode);
  }

  if (gameRecord) {
    const updatedTime = Math.max(gameRecord.active_time_ms, active_time_ms);
    db.prepare('UPDATE user_daily_games SET active_time_ms = ? WHERE id = ?').run(updatedTime, gameRecord.id);
  } else {
    db.prepare(`
      INSERT INTO user_daily_games (user_id, guest_session_id, puzzle_date, game_mode, active_time_ms, solutions_found, canonical_paths)
      VALUES (?, ?, ?, ?, ?, '[]', '[]')
    `).run(userId, guestId, today, mode, active_time_ms);
  }

  res.json({ success: true, active_time_ms, mode });
});

// ------------------------------------------------------------------
// 3. POST /api/verify - Verify equation path & deduplicate
// ------------------------------------------------------------------
app.post('/api/verify', (req, res) => {
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);
  const { equation, active_time_ms } = req.body;

  const puzzle = getOrGenerateDailyPuzzle(today, mode);
  if (!puzzle) {
    return res.status(500).json({ error: 'Daily puzzle not found.' });
  }

  const availableNumbers = JSON.parse(puzzle.numbers);
  const evalResult = parseAndEvaluate(equation, availableNumbers, mode);

  if (!evalResult.valid) {
    return res.json({ is_correct: false, message: evalResult.reason });
  }

  if (evalResult.value !== puzzle.target) {
    return res.json({
      is_correct: false,
      message: `Equation equals ${evalResult.value}, but target is ${puzzle.target}.`
    });
  }

  const userId = getUserIdFromReq(req);
  const guestId = req.session ? req.session.id : 'guest-fallback';

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(userId, today, mode);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?').get(guestId, today, mode);
  }

  let solutionsFound = gameRecord ? JSON.parse(gameRecord.solutions_found) : [];

  if (mode === 'speed' && solutionsFound.length >= 3) {
    return res.json({
      is_correct: false,
      message: 'You have already found all 3 Speed solutions for today!'
    });
  }
  let canonicalPaths = gameRecord ? JSON.parse(gameRecord.canonical_paths) : [];

  if (canonicalPaths.includes(evalResult.canonical)) {
    return res.json({
      is_correct: false,
      message: 'You already discovered this exact mathematical path!'
    });
  }

  solutionsFound.push(equation);
  canonicalPaths.push(evalResult.canonical);

  const updatedTime = Math.max(gameRecord ? gameRecord.active_time_ms : 0, active_time_ms || 0);

  if (gameRecord) {
    db.prepare(`
      UPDATE user_daily_games 
      SET solutions_found = ?, canonical_paths = ?, active_time_ms = ?
      WHERE id = ?
    `).run(JSON.stringify(solutionsFound), JSON.stringify(canonicalPaths), updatedTime, gameRecord.id);
  } else {
    db.prepare(`
      INSERT INTO user_daily_games (user_id, guest_session_id, puzzle_date, game_mode, active_time_ms, solutions_found, canonical_paths)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(userId, guestId, today, mode, updatedTime, JSON.stringify(solutionsFound), JSON.stringify(canonicalPaths));
  }

  res.json({
    is_correct: true,
    message: 'Valid solution!',
    solutions_count: solutionsFound.length,
    solutions_found: solutionsFound
  });
});

// ------------------------------------------------------------------
// 4. POST /api/finish - Lock score & publish to leaderboard
// ------------------------------------------------------------------
app.post('/api/finish', (req, res) => {
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);
  const { active_time_ms } = req.body;

  const userId = getUserIdFromReq(req);
  const guestId = req.session ? req.session.id : 'guest-fallback';

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(userId, today, mode);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?').get(guestId, today, mode);
  }

  if (!gameRecord) {
    return res.status(400).json({ error: 'No active game session found.' });
  }

  const existingSolutions = JSON.parse(gameRecord.solutions_found || '[]');

  // Protect completed games with solutions from being overwritten
  if (gameRecord.is_completed && existingSolutions.length > 0) {
    const finalTime = Math.min(gameRecord.active_time_ms, active_time_ms || gameRecord.active_time_ms);
    db.prepare('UPDATE user_daily_games SET active_time_ms = ? WHERE id = ?').run(finalTime, gameRecord.id);
    if (userId) {
      const user = db.prepare('SELECT username FROM users WHERE id = ?').get(userId);
      if (user) syncUserScoresToLeaderboard(userId, user.username);
    }
    return res.json({
      is_completed: true,
      solutions_found_count: existingSolutions.length,
      solutions_found: existingSolutions,
      final_time_ms: finalTime,
      is_guest: !userId
    });
  }

  const finalTime = Math.max(gameRecord.active_time_ms, active_time_ms || gameRecord.active_time_ms);
  const solutions = existingSolutions;

  db.prepare('UPDATE user_daily_games SET is_completed = 1, active_time_ms = ? WHERE id = ?').run(finalTime, gameRecord.id);

  let leaderboardPosition = null;
  if (userId) {
    const user = db.prepare('SELECT username FROM users WHERE id = ?').get(userId);
    if (user && solutions.length > 0) {
      db.prepare(`
        INSERT INTO leaderboards (puzzle_date, game_mode, user_id, username, solutions_count, active_time_ms)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(puzzle_date, game_mode, user_id) DO UPDATE SET
          solutions_count = excluded.solutions_count,
          active_time_ms = excluded.active_time_ms
      `).run(today, mode, userId, user.username, solutions.length, finalTime);

      const higherRanks = db.prepare(`
        SELECT COUNT(*) as rank FROM leaderboards
        WHERE puzzle_date = ? AND game_mode = ? AND (solutions_count > ? OR (solutions_count = ? AND active_time_ms < ?))
      `).get(today, mode, solutions.length, solutions.length, finalTime).rank;

      leaderboardPosition = higherRanks + 1;
      // Instant completion recap disabled per configuration (Daily Digest only)
    }
  }

  res.json({
    is_completed: true,
    solutions_found_count: solutions.length,
    solutions_found: solutions,
    final_time_ms: finalTime,
    leaderboard_position: leaderboardPosition,
    is_guest: !userId
  });
});

// ------------------------------------------------------------------
// 5. GET /api/leaderboard - Daily, Weekly, and Overall Leaderboard by Mode
// ------------------------------------------------------------------
app.get('/api/leaderboard', (req, res) => {
  const type = (req.query.type || 'daily').toLowerCase();
  const today = getSanitizedDate(req);
  const mode = getSanitizedMode(req);

  if (type === 'weekly') {
    const d = new Date(today);
    d.setDate(d.getDate() - 7);
    const sevenDaysAgo = d.toISOString().split('T')[0];

    const rows = db.prepare(`
      SELECT username, 
             SUM(solutions_count) as solutions_count, 
             SUM(active_time_ms) as active_time_ms, 
             COUNT(DISTINCT puzzle_date) as games_played
      FROM leaderboards
      WHERE puzzle_date >= ? AND game_mode = ?
      GROUP BY user_id, username
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(sevenDaysAgo, mode);

    return res.json({ type: 'weekly', game_mode: mode, leaderboard: rows });
  } else if (type === 'overall') {
    const rows = db.prepare(`
      SELECT username, 
             SUM(solutions_count) as solutions_count, 
             SUM(active_time_ms) as active_time_ms, 
             COUNT(DISTINCT puzzle_date) as games_played
      FROM leaderboards
      WHERE game_mode = ?
      GROUP BY user_id, username
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(mode);

    return res.json({ type: 'overall', game_mode: mode, leaderboard: rows });
  } else {
    const rows = db.prepare(`
      SELECT username, solutions_count, active_time_ms, created_at 
      FROM leaderboards 
      WHERE puzzle_date = ? AND game_mode = ?
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(today, mode);

    return res.json({ type: 'daily', game_mode: mode, puzzle_date: today, leaderboard: rows });
  }
});

// ------------------------------------------------------------------
// 6. Auth Routes (Register, Login, Logout, Me)
// ------------------------------------------------------------------
app.post('/api/auth/register', (req, res) => {
  const { username, email, password, email_opt_in } = req.body;

  const cleanUser = (username || '').trim();
  const cleanEmail = (email || '').trim().toLowerCase();
  const cleanPass = (password || '').trim();

  if (!cleanUser || cleanUser.length < 3) {
    return res.status(400).json({ error: 'Username must be at least 3 characters.' });
  }
  if (!cleanEmail || !cleanEmail.includes('@')) {
    return res.status(400).json({ error: 'Valid email address required.' });
  }
  if (!cleanPass || cleanPass.length < 4) {
    return res.status(400).json({ error: 'Password must be at least 4 characters.' });
  }

  const existingUser = db.prepare('SELECT id FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)').get(cleanUser, cleanEmail);
  if (existingUser) {
    return res.status(400).json({ error: 'Username or email already registered. Please log in.' });
  }

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(cleanPass, salt);
  const authToken = crypto.randomBytes(32).toString('hex');

  try {
    const result = db.prepare(`
      INSERT INTO users (username, email, password_hash, auth_token, email_opt_in)
      VALUES (?, ?, ?, ?, ?)
    `).run(cleanUser, cleanEmail, hash, authToken, email_opt_in ? 1 : 0);

    const newUserId = result.lastInsertRowid;

    if (req.session) {
      req.session.userId = newUserId;
      req.session.username = cleanUser;
    }

    // Migrate guest game record & publish score to leaderboard
    try {
      const today = getSanitizedDate(req);
      const mode = getSanitizedMode(req);
      const guestId = req.session ? req.session.id : null;

      if (guestId) {
        db.prepare('UPDATE user_daily_games SET user_id = ? WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?')
          .run(newUserId, guestId, today, mode);
      }

      syncUserScoresToLeaderboard(newUserId, cleanUser);
    } catch (migErr) {
      console.error('Non-fatal guest record migration notice:', migErr.message);
    }

    res.json({
      success: true,
      user: { id: newUserId, username: cleanUser, email: cleanEmail },
      token: authToken
    });
  } catch (err) {
    console.error('Registration DB Error:', err);
    return res.status(500).json({ error: 'Account registration failed. Please try again.' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { username_or_email, password } = req.body;

  const cleanCred = (username_or_email || '').trim();
  const cleanPass = (password || '').trim();

  if (!cleanCred || !cleanPass) {
    return res.status(400).json({ error: 'Username/email and password are required.' });
  }

  const user = db.prepare(`
    SELECT * FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)
  `).get(cleanCred, cleanCred.toLowerCase());

  if (!user || !bcrypt.compareSync(cleanPass, user.password_hash)) {
    return res.status(400).json({ error: 'Invalid username/email or password.' });
  }

  // Ensure persistent token exists
  let authToken = user.auth_token;
  if (!authToken) {
    authToken = crypto.randomBytes(32).toString('hex');
    db.prepare('UPDATE users SET auth_token = ? WHERE id = ?').run(authToken, user.id);
  }

  if (req.session) {
    req.session.userId = user.id;
    req.session.username = user.username;
  }

  // Link any current guest game and sync leaderboards
  try {
    const today = getSanitizedDate(req);
    const mode = getSanitizedMode(req);
    const guestId = req.session ? req.session.id : null;

    if (guestId) {
      const existingUserGame = db.prepare('SELECT id FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?').get(user.id, today, mode);
      if (!existingUserGame) {
        db.prepare('UPDATE user_daily_games SET user_id = ? WHERE guest_session_id = ? AND puzzle_date = ? AND game_mode = ?')
          .run(user.id, guestId, today, mode);
      }
    }

    syncUserScoresToLeaderboard(user.id, user.username);
  } catch (migErr) {
    console.error('Non-fatal login guest sync notice:', migErr.message);
  }

  res.json({
    success: true,
    user: { id: user.id, username: user.username, email: user.email },
    token: authToken
  });
});

app.post('/api/auth/logout', (req, res) => {
  if (req.session) req.session.destroy();
  res.json({ success: true });
});

app.post('/api/auth/restore', (req, res) => {
  const { username, email, token, completed_games } = req.body;
  const cleanUser = (username || '').trim();
  const cleanEmail = (email || '').trim().toLowerCase() || (cleanUser.toLowerCase() + '@quizsum.local');
  const cleanToken = (token || '').trim();

  if (!cleanUser || cleanUser.length < 3 || !cleanToken) {
    return res.status(400).json({ error: 'Valid user profile required for restore.' });
  }

  let user = db.prepare('SELECT id, username, email, auth_token FROM users WHERE auth_token = ? OR LOWER(username) = LOWER(?)').get(cleanToken, cleanUser);

  if (!user) {
    try {
      const dummyHash = bcrypt.hashSync('restored-account-pass', 10);
      const result = db.prepare(`
        INSERT INTO users (username, email, password_hash, auth_token, email_opt_in)
        VALUES (?, ?, ?, ?, 1)
      `).run(cleanUser, cleanEmail, dummyHash, cleanToken);
      
      user = { id: result.lastInsertRowid, username: cleanUser, email: cleanEmail, auth_token: cleanToken };
    } catch (err) {
      user = db.prepare('SELECT id, username, email, auth_token FROM users WHERE LOWER(username) = LOWER(?)').get(cleanUser);
    }
  } else if (user.auth_token !== cleanToken) {
    db.prepare('UPDATE users SET auth_token = ? WHERE id = ?').run(cleanToken, user.id);
  }

  if (user) {
    if (req.session) {
      req.session.userId = user.id;
      req.session.username = user.username;
    }

    // Restore completed games history if provided
    if (Array.isArray(completed_games) && completed_games.length > 0) {
      for (const game of completed_games) {
        try {
          if (!game.puzzle_date || !game.game_mode) continue;
          const solutionsStr = JSON.stringify(game.solutions_found || []);
          const activeMs = game.active_time_ms || 0;
          const isComp = game.is_completed ? 1 : 0;

          const existingGame = db.prepare('SELECT id FROM user_daily_games WHERE user_id = ? AND puzzle_date = ? AND game_mode = ?')
            .get(user.id, game.puzzle_date, game.game_mode);

          if (!existingGame) {
            db.prepare(`
              INSERT INTO user_daily_games (user_id, puzzle_date, game_mode, active_time_ms, solutions_found, canonical_paths, is_completed)
              VALUES (?, ?, ?, ?, ?, '[]', ?)
            `).run(user.id, game.puzzle_date, game.game_mode, activeMs, solutionsStr, isComp);
          } else if (isComp) {
            const existingRec = db.prepare('SELECT solutions_found FROM user_daily_games WHERE id = ?').get(existingGame.id);
            const existingSols = existingRec ? JSON.parse(existingRec.solutions_found || '[]') : [];
            const newSols = game.solutions_found || [];
            if (newSols.length >= existingSols.length) {
              db.prepare('UPDATE user_daily_games SET is_completed = 1, active_time_ms = ?, solutions_found = ? WHERE id = ?')
                .run(activeMs, solutionsStr, existingGame.id);
            }
          }
        } catch (hErr) {
          console.error('History sync line error:', hErr.message);
        }
      }
    }

    syncUserScoresToLeaderboard(user.id, user.username);

    return res.json({
      success: true,
      user: { id: user.id, username: user.username, email: user.email },
      token: cleanToken
    });
  }

  res.status(500).json({ error: 'Restore failed.' });
});

app.get('/api/auth/me', (req, res) => {
  const userId = getUserIdFromReq(req);
  if (userId) {
    const user = db.prepare('SELECT id, username, email, email_opt_in, auth_token FROM users WHERE id = ?').get(userId);
    if (user) {
      return res.json({
        loggedIn: true,
        user: { id: user.id, username: user.username, email: user.email },
        token: user.auth_token
      });
    }
  }
  res.json({ loggedIn: false });
});


// ------------------------------------------------------------------
// GET /api/stats - Global application statistics
// ------------------------------------------------------------------
app.get('/api/stats', (req, res) => {
  try {
    const totalUsers = db.prepare('SELECT COUNT(*) AS count FROM users').get().count;
    res.json({ registered_players: totalUsers });
  } catch (err) {
    console.error('Error fetching player stats:', err.message);
    res.status(500).json({ error: 'Failed to fetch player stats' });
  }
});


// Email notification endpoints
app.post('/api/user/test-email', async (req, res) => {
  const userId = getUserIdFromReq(req);
  if (!userId) {
    return res.status(401).json({ error: 'Please log in to send a test notification.' });
  }

  const user = db.prepare('SELECT username, email FROM users WHERE id = ?').get(userId);
  if (!user || !user.email || !user.email.includes('@')) {
    return res.status(400).json({ error: 'Valid email required.' });
  }

  const result = await sendResendNotification({
    to: user.email,
    subject: 'QuizSum Notification Test for ' + user.username,
    html: '<p>QuizSum notification service is active!</p>'
  });

  if (result.success) {
    res.json({ success: true, message: 'Test notification sent to ' + user.email + '!' });
  } else {
    res.status(500).json({ error: result.reason || 'Failed to send test notification.', details: result.error });
  }
});

app.get('/api/admin/send-daily-emails', async (req, res) => {
  const summary = await sendDailyDigestNotifications(db);
  res.json({ success: true, summary });
});

// Daily email schedule aligned precisely to 07:00 AM GMT (UTC)
function scheduleDaily7AMDigest() {
  function getMsUntil7AMUTC() {
    const now = new Date();
    const next7AM = new Date();
    next7AM.setUTCHours(7, 0, 0, 0);
    if (now >= next7AM) {
      next7AM.setUTCDate(next7AM.getUTCDate() + 1);
    }
    return next7AM.getTime() - now.getTime();
  }

  function runAndReschedule() {
    console.log('[Daily Digest] Running scheduled daily digest at 07:00 GMT...');
    sendDailyDigestNotifications(db).catch(err => console.error('Daily digest error:', err));
    const delay = getMsUntil7AMUTC();
    console.log();
    setTimeout(runAndReschedule, delay);
  }

  const initialDelay = getMsUntil7AMUTC();
  console.log();
  setTimeout(runAndReschedule, initialDelay);
}

// Internal timer disabled to prevent duplicate emails (handled by external cron job at 6:00 AM)
// scheduleDaily7AMDigest();



// Reset password / account recovery
app.post('/api/auth/reset-password', (req, res) => {
  const { email, new_password } = req.body;
  const cleanEmail = (email || '').trim().toLowerCase();
  const cleanPass = (new_password || '').trim();

  if (!cleanEmail) {
    return res.status(400).json({ error: 'Email or username required.' });
  }
  if (!cleanPass || cleanPass.length < 4) {
    return res.status(400).json({ error: 'New password must be at least 4 characters.' });
  }

  const user = db.prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(?) OR LOWER(username) = LOWER(?)').get(cleanEmail, cleanEmail);

  if (!user) {
    return res.status(400).json({ error: 'No account found with that email address or username.' });
  }

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(cleanPass, salt);
  const authToken = crypto.randomBytes(32).toString('hex');

  db.prepare(`
    UPDATE users 
    SET password_hash = ?, auth_token = ?, email_opt_in = 1 
    WHERE id = ?
  `).run(hash, authToken, user.id);

  if (req.session) {
    req.session.userId = user.id;
    req.session.username = user.username;
  }

  res.json({
    success: true,
    message: 'Password updated successfully! You are now logged in.',
    user: { id: user.id, username: user.username, email: user.email },
    token: authToken
  });
});

// Admin User Management routes
app.get('/api/admin/users', (req, res) => {
  try {
    const users = db.prepare('SELECT id, username, email, email_opt_in, created_at FROM users ORDER BY id DESC').all();
    res.json({ success: true, count: users.length, users });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/admin/reset-user-password', (req, res) => {
  const { username_or_email, new_password, email_opt_in } = req.body;
  const cleanCred = (username_or_email || '').trim();
  const cleanPass = (new_password || 'quizsum123').trim();

  const user = db.prepare('SELECT * FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)').get(cleanCred, cleanCred.toLowerCase());
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(cleanPass, salt);
  const optInVal = email_opt_in !== undefined ? (email_opt_in ? 1 : 0) : 1;

  db.prepare('UPDATE users SET password_hash = ?, email_opt_in = ? WHERE id = ?').run(hash, optInVal, user.id);

  res.json({
    success: true,
    message: `Password reset for ${user.username} (${user.email}).`,
    user: { id: user.id, username: user.username, email: user.email, email_opt_in: optInVal }
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`QuizSum server running on port ${PORT}`);
});
