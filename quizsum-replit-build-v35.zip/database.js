const Database = require('better-sqlite3');
const path = require('path');

const dbPath = process.env.DB_PATH || path.join(__dirname, 'quizsum.db');
const db = new Database(dbPath);

// Enable SQLite performance & concurrency pragmas
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('busy_timeout = 5000');

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    auth_token TEXT,
    email_opt_in INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS daily_puzzles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    puzzle_date TEXT NOT NULL, -- YYYY-MM-DD
    game_mode TEXT NOT NULL DEFAULT 'speed', -- 'speed' or 'pro'
    target INTEGER NOT NULL,
    numbers TEXT NOT NULL, -- JSON array e.g. "[3, 5, 8, 12, 20]"
    solutions_json TEXT NOT NULL, -- Array of pre-calculated valid solution strings
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(puzzle_date, game_mode)
  );

  CREATE TABLE IF NOT EXISTS user_daily_games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER, -- NULL for guest
    guest_session_id TEXT,
    puzzle_date TEXT NOT NULL,
    game_mode TEXT NOT NULL DEFAULT 'speed',
    active_time_ms INTEGER NOT NULL DEFAULT 0,
    solutions_found TEXT NOT NULL DEFAULT '[]', -- JSON array of submitted equations
    canonical_paths TEXT NOT NULL DEFAULT '[]', -- JSON array of canonical trees
    is_completed INTEGER DEFAULT 0,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS leaderboards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    puzzle_date TEXT NOT NULL,
    game_mode TEXT NOT NULL DEFAULT 'speed',
    user_id INTEGER NOT NULL,
    username TEXT NOT NULL,
    solutions_count INTEGER NOT NULL,
    active_time_ms INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(puzzle_date, game_mode, user_id)
  );
`);

// Safe column migrations for existing databases
try { db.exec("ALTER TABLE users ADD COLUMN auth_token TEXT"); } catch(e) {}
try { db.exec("ALTER TABLE daily_puzzles ADD COLUMN game_mode TEXT DEFAULT 'speed'"); } catch(e) {}
try { db.exec("ALTER TABLE user_daily_games ADD COLUMN game_mode TEXT DEFAULT 'speed'"); } catch(e) {}
try { db.exec("ALTER TABLE leaderboards ADD COLUMN game_mode TEXT DEFAULT 'speed'"); } catch(e) {}

// Safe Mathematical Expression Evaluator
function safeEval(expr) {
  const tokens = expr.match(/\d+|[+\-*/()]/g);
  if (!tokens) return null;

  let pos = 0;

  function parseExpression() {
    let left = parseTerm();
    while (pos < tokens.length && (tokens[pos] === '+' || tokens[pos] === '-')) {
      const op = tokens[pos++];
      const right = parseTerm();
      if (op === '+') left += right;
      if (op === '-') left -= right;
    }
    return left;
  }

  function parseTerm() {
    let left = parseFactor();
    while (pos < tokens.length && (tokens[pos] === '*' || tokens[pos] === '/')) {
      const op = tokens[pos++];
      const right = parseFactor();
      if (op === '*') left *= right;
      if (op === '/') {
        if (right === 0 || left % right !== 0) throw new Error('Invalid division');
        left = left / right;
      }
    }
    return left;
  }

  function parseFactor() {
    if (tokens[pos] === '(') {
      pos++; // consume '('
      const val = parseExpression();
      if (tokens[pos] !== ')') throw new Error('Missing closing parenthesis');
      pos++; // consume ')'
      return val;
    }
    const token = tokens[pos++];
    const num = parseInt(token, 10);
    if (isNaN(num)) throw new Error('Expected number');
    return num;
  }

  const res = parseExpression();
  if (pos !== tokens.length) throw new Error('Unexpected tokens at end');
  return res;
}

// Algebraic AST Canonical Normalizer to detect commutative duplicates
function getCanonicalForm(expr) {
  try {
    const tokens = expr.replace(/\s+/g, '').match(/\d+|[+\-*/()]/g);
    if (!tokens) return expr.replace(/\s+/g, '');

    let pos = 0;

    function parseE() {
      let terms = [parseT()];
      while (pos < tokens.length && (tokens[pos] === '+' || tokens[pos] === '-')) {
        const op = tokens[pos++];
        const right = parseT();
        if (op === '+') terms.push(right);
        else terms.push('-' + right);
      }
      if (terms.length === 1) return terms[0];
      return '(' + terms.map(String).sort().join('+') + ')';
    }

    function parseT() {
      let factors = [parseF()];
      while (pos < tokens.length && (tokens[pos] === '*' || tokens[pos] === '/')) {
        const op = tokens[pos++];
        const right = parseF();
        if (op === '*') factors.push(right);
        else factors.push('/' + right);
      }
      if (factors.length === 1) return factors[0];
      let mults = [], divs = [];
      for (let f of factors) {
        let str = String(f);
        if (str.startsWith('/')) divs.push(str);
        else mults.push(str);
      }
      mults.sort();
      divs.sort();
      return '(' + [...mults, ...divs].join('*') + ')';
    }

    function parseF() {
      if (tokens[pos] === '(') {
        pos++;
        const res = parseE();
        pos++;
        return res;
      }
      return tokens[pos++];
    }

    return String(parseE());
  } catch (e) {
    return expr.replace(/\s+/g, '');
  }
}

// Mathematical Equation Evaluator & Validation
function parseAndEvaluate(equationStr, availableNumbers, mode = 'speed') {
  const cleanCheck = equationStr.replace(/\s+/g, '');
  if (mode === 'speed' && /[()]/.test(cleanCheck)) {
    return { valid: false, reason: 'Speed Mode equations do not use parentheses ().' };
  }
  const clean = equationStr.replace(/\s+/g, '');

  if (!/^[0-9+\-*/()]+$/.test(clean)) {
    return { valid: false, reason: 'Invalid characters in equation.' };
  }

  const numbersUsed = clean.match(/\d+/g) ? clean.match(/\d+/g).map(Number) : [];
  if (numbersUsed.length === 0) {
    return { valid: false, reason: 'No numbers found in equation.' };
  }

  const availableCopy = [...availableNumbers];
  for (const num of numbersUsed) {
    const idx = availableCopy.indexOf(num);
    if (idx === -1) {
      return { valid: false, reason: `Number ${num} is not in the available tiles or used too many times.` };
    }
    availableCopy.splice(idx, 1);
  }

  try {
    const result = safeEval(clean);
    if (result === null || !Number.isInteger(result)) {
      return { valid: false, reason: 'Equation results in a non-integer or division error.' };
    }
    const canonical = getCanonicalForm(clean);
    return { valid: true, value: result, numbersUsed, canonical };
  } catch (err) {
    return { valid: false, reason: 'Invalid mathematical expression syntax.' };
  }
}

// Curated Speed Puzzles Pool
const CURATED_SPEED_PUZZLES = [
  {
    "target": 24,
    "numbers": [
      3,
      4,
      6,
      8,
      10
    ],
    "solutions": [
      "3 * 8",
      "3 * 10 - 6",
      "3 * 6 - 4 + 10"
    ]
  },
  {
    "target": 40,
    "numbers": [
      2,
      4,
      5,
      10,
      25
    ],
    "solutions": [
      "4 * 10",
      "2 * 4 * 5",
      "2 * 10 + 4 * 5"
    ]
  },
  {
    "target": 50,
    "numbers": [
      2,
      5,
      10,
      15,
      25
    ],
    "solutions": [
      "2 * 25",
      "5 * 15 - 25",
      "2 * 5 + 15 + 25"
    ]
  },
  {
    "target": 60,
    "numbers": [
      5,
      10,
      15,
      20,
      25
    ],
    "solutions": [
      "15 + 20 + 25",
      "5 * 10 - 15 + 25",
      "5 + 10 + 20 + 25"
    ]
  },
  {
    "target": 75,
    "numbers": [
      5,
      10,
      15,
      20,
      25
    ],
    "solutions": [
      "15 * 5",
      "5 * 10 + 25",
      "5 * 20 - 10 - 15"
    ]
  },
  {
    "target": 80,
    "numbers": [
      4,
      5,
      10,
      20,
      25
    ],
    "solutions": [
      "4 * 20",
      "4 * 25 - 20",
      "4 * 10 - 5 + 20 + 25"
    ]
  },
  {
    "target": 90,
    "numbers": [
      5,
      10,
      15,
      20,
      25
    ],
    "solutions": [
      "5 * 20 - 10",
      "5 * 10 + 15 + 25",
      "5 * 15 - 10 + 25"
    ]
  },
  {
    "target": 100,
    "numbers": [
      4,
      5,
      10,
      20,
      25
    ],
    "solutions": [
      "4 * 25",
      "4 * 20 - 5 + 25",
      "10 * 20 - 4 * 25"
    ]
  },
  {
    "target": 120,
    "numbers": [
      6,
      10,
      15,
      20,
      25
    ],
    "solutions": [
      "6 * 20",
      "6 * 15 + 10 + 20",
      "6 * 25 - 10 - 20"
    ]
  },
  {
    "target": 125,
    "numbers": [
      10,
      20,
      25,
      50,
      100
    ],
    "solutions": [
      "25 + 100",
      "50 - 25 + 100",
      "10 * 20 - 25 - 50"
    ]
  },
  {
    "target": 150,
    "numbers": [
      10,
      20,
      25,
      50,
      100
    ],
    "solutions": [
      "100 + 50",
      "10 * 20 - 50",
      "10 * 25 - 100"
    ]
  },
  {
    "target": 180,
    "numbers": [
      8,
      10,
      20,
      25,
      50
    ],
    "solutions": [
      "8 * 25 - 20",
      "10 * 25 - 20 - 50",
      "8 * 25 + 10 + 20 - 50"
    ]
  },
  {
    "target": 200,
    "numbers": [
      10,
      20,
      25,
      50,
      100
    ],
    "solutions": [
      "10 * 20",
      "10 * 25 - 50",
      "10 * 25 + 50 - 100"
    ]
  },
  {
    "target": 250,
    "numbers": [
      10,
      20,
      25,
      50,
      100
    ],
    "solutions": [
      "10 * 25",
      "10 * 20 + 50",
      "10 * 20 - 50 + 100"
    ]
  }
];


// Automated Solver Engine for Pro Mode Full Solutions
function solveProPuzzle(target, numbers) {
  const ops = ['+', '-', '*', '/'];
  const uniqueCanonical = new Map();

  function permute(arr) {
    if (arr.length === 1) return [arr];
    let res = [];
    for (let i = 0; i < arr.length; i++) {
      let current = arr[i];
      let remaining = arr.slice(0, i).concat(arr.slice(i + 1));
      for (let p of permute(remaining)) {
        res.push([current].concat(p));
      }
    }
    return res;
  }

  function getSubsets(arr) {
    let res = [];
    function helper(start, current) {
      if (current.length >= 2) res.push([...current]);
      for (let i = start; i < arr.length; i++) {
        current.push(arr[i]);
        helper(i + 1, current);
        current.pop();
      }
    }
    helper(0, []);
    return res;
  }

  function buildTrees(numArr) {
    if (numArr.length === 1) return [String(numArr[0])];
    let trees = [];
    for (let i = 1; i < numArr.length; i++) {
      let leftArr = numArr.slice(0, i);
      let rightArr = numArr.slice(i);
      let leftTrees = buildTrees(leftArr);
      let rightTrees = buildTrees(rightArr);
      for (let l of leftTrees) {
        for (let r of rightTrees) {
          for (let op of ops) {
            trees.push('(' + l + ' ' + op + ' ' + r + ')');
          }
        }
      }
    }
    return trees;
  }

  const subsets = getSubsets(numbers);
  for (let sub of subsets) {
    const orderings = permute(sub);
    for (let ord of orderings) {
      const exprs = buildTrees(ord);
      for (let expr of exprs) {
        const evalRes = parseAndEvaluate(expr, numbers, 'pro');
        if (evalRes.valid && evalRes.value === target) {
          if (!uniqueCanonical.has(evalRes.canonical)) {
            uniqueCanonical.set(evalRes.canonical, expr);
          }
        }
      }
    }
  }
  return Array.from(uniqueCanonical.values());
}

// Curated Pro Puzzles Pool
const CURATED_PRO_PUZZLES = [
  {
    "target": 29,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((3 * (10 - 7)) + 20)",
      "((3 + (10 * 20)) / 7)",
      "((3 * (20 - 7)) - 10)",
      "((7 * (10 - 3)) - 20)",
      "(20 - (3 * (7 - 10)))",
      "(((3 * 14) + 7) - 20)",
      "((3 * 14) + (7 - 20))",
      "(((3 * 14) - 20) + 7)",
      "((3 * 14) - (20 - 7))",
      "(7 - (20 - (3 * 14)))"
    ]
  },
  {
    "target": 33,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(3 * ((7 - 10) + 14))",
      "(3 * (7 - (10 - 14)))",
      "(3 * ((7 + 14) - 10))",
      "(3 * (7 + (14 - 10)))",
      "((3 - 14) * (7 - 10))",
      "(3 * (14 - (10 - 7)))",
      "((10 - 7) * (14 - 3))",
      "(3 + 10) + 20",
      "3 + (10 + 20)",
      "(3 + 20) + 10"
    ]
  },
  {
    "target": 46,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((7 - 3) * 14) - 10)",
      "((3 - (7 / 10)) * 20)",
      "(3 * 20) - 14",
      "(((3 + 20) / 7) * 14)",
      "((3 + 20) / (7 / 14))",
      "(((3 + 20) * 14) / 7)",
      "((3 + 20) * (14 / 7))",
      "(14 / (7 / (3 + 20)))",
      "(((10 - 7) * 20) - 14)"
    ]
  },
  {
    "target": 48,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(3 * ((10 - 14) + 20))",
      "(3 * (10 - (14 - 20)))",
      "(3 * ((10 + 20) - 14))",
      "(3 * (10 + (20 - 14)))",
      "(3 * (14 + (20 / 10)))",
      "(3 * (20 - (14 - 10)))",
      "((7 * (14 - 10)) + 20)",
      "(20 - (7 * (10 - 14)))"
    ]
  },
  {
    "target": 55,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((3 * 7) + 14) + 20)",
      "((3 * 7) + (14 + 20))",
      "(((3 * 7) + 20) + 14)",
      "(((3 * 14) - 7) + 20)",
      "((3 * 14) - (7 - 20))",
      "(((3 * 14) + 20) - 7)",
      "((3 * 14) + (20 - 7))",
      "(20 - (7 - (3 * 14)))"
    ]
  },
  {
    "target": 59,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((3 + (7 * 10)) - 14)",
      "(3 + ((7 * 10) - 14))",
      "((3 - 14) + (7 * 10))",
      "(3 - (14 - (7 * 10)))",
      "(((3 * 14) + 7) + 10)",
      "((3 * 14) + (7 + 10))",
      "(((3 * 14) + 10) + 7)",
      "((7 * 10) - (14 - 3))"
    ]
  },
  {
    "target": 62,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((3 + (10 / 7)) * 14)",
      "(3 * 14) + 20",
      "((3 * 20) + (14 / 7))",
      "(((10 * 20) - 14) / 3)",
      "(((10 - 7) * 14) + 20)",
      "(20 - ((7 - 10) * 14))"
    ]
  },
  {
    "target": 68,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((7 * 14) - (3 * 10))",
      "((3 - 20) * (10 - 14))",
      "((14 - 10) * (20 - 3))",
      "((7 * 14) - (10 + 20))",
      "(((7 * 14) - 10) - 20)",
      "(((7 * 14) - 20) - 10)"
    ]
  },
  {
    "target": 72,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "3 * (10 + 14)",
      "(((3 * 14) + 10) + 20)",
      "((3 * 14) + (10 + 20))",
      "(3 * ((14 - 10) + 20))",
      "(3 * (14 - (10 - 20)))",
      "(((3 * 14) + 20) + 10)",
      "(3 * ((14 + 20) - 10))",
      "(3 * (14 + (20 - 10)))",
      "(3 * (20 - (10 - 14)))"
    ]
  },
  {
    "target": 73,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "3 + (7 * 10)",
      "(3 - ((7 - 14) * 10))",
      "((3 * (7 + 14)) + 10)",
      "(3 + (10 * (14 - 7)))",
      "(3 - (7 * (10 - 20)))",
      "(3 + (7 * (20 - 10)))",
      "(((14 - 10) * 20) - 7)"
    ]
  },
  {
    "target": 76,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((7 - 3) * 14) + 20)",
      "(20 - ((3 - 7) * 14))",
      "((3 * (10 + 20)) - 14)",
      "(((7 * 10) - 14) + 20)",
      "((7 * 10) - (14 - 20))",
      "(((7 * 10) + 20) - 14)",
      "((7 * 10) + (20 - 14))",
      "(20 - (14 - (7 * 10)))"
    ]
  },
  {
    "target": 77,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "7 * (14 - 3)",
      "(((3 + 10) * 7) - 14)",
      "(((3 * 20) + 7) + 10)",
      "((3 * 20) + (7 + 10))",
      "(((3 * 20) + 10) + 7)",
      "(((14 - 10) * 20) - 3)",
      "((7 + (14 / 20)) * 10)"
    ]
  },
  {
    "target": 80,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(7 - 3) * 20",
      "(((3 + 7) * 10) - 20)",
      "((14 - (3 + 7)) * 20)",
      "(((14 - 3) - 7) * 20)",
      "(((14 - 7) - 3) * 20)",
      "(14 - 10) * 20",
      "((10 * 14) - (3 * 20))",
      "(7 * (10 + (20 / 14)))"
    ]
  },
  {
    "target": 88,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(7 * 14) - 10",
      "((3 + (14 / 10)) * 20)",
      "(((7 * 14) + 10) - 20)",
      "((7 * 14) + (10 - 20))",
      "(((7 * 14) - 20) + 10)",
      "((7 * 14) - (20 - 10))",
      "(10 - (20 - (7 * 14)))"
    ]
  },
  {
    "target": 93,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(3 * ((7 + 10) + 14))",
      "(3 * (7 + (10 + 14)))",
      "(3 * ((7 + 14) + 10))",
      "((3 + (7 * 10)) + 20)",
      "(3 + ((7 * 10) + 20))",
      "((3 + 20) + (7 * 10))"
    ]
  },
  {
    "target": 98,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "7 * 14",
      "(10 - 3) * 14",
      "((7 * 20) - (3 * 14))",
      "(14 * (20 - (3 + 10)))",
      "(14 * ((20 - 3) - 10))",
      "(14 * ((20 - 10) - 3))"
    ]
  },
  {
    "target": 105,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((3 + 10) * 7) + 14)",
      "(7 - ((3 - 10) * 14))",
      "(7 + ((10 - 3) * 14))",
      "(((7 * 14) - 3) + 10)",
      "((7 * 14) - (3 - 10))",
      "(((7 * 14) + 10) - 3)",
      "((7 * 14) + (10 - 3))",
      "(10 - (3 - (7 * 14)))",
      "((7 * (20 - 3)) - 14)",
      "((7 + (10 / 20)) * 14)"
    ]
  },
  {
    "target": 108,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(7 * 14) + 10",
      "(((7 * 14) - 10) + 20)",
      "((7 * 14) - (10 - 20))",
      "(((7 * 14) + 20) - 10)",
      "((7 * 14) + (20 - 10))",
      "((7 + 20) * (14 - 10))",
      "(20 - (10 - (7 * 14)))"
    ]
  },
  {
    "target": 111,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((3 + (7 * 14)) + 10)",
      "(3 + ((7 * 14) + 10))",
      "((3 + 10) + (7 * 14))",
      "(3 * ((7 + 10) + 20))",
      "(3 * (7 + (10 + 20)))",
      "(3 * ((7 + 20) + 10))",
      "(((3 + 10) * 7) + 20)"
    ]
  },
  {
    "target": 112,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((3 * 10) - 14) * 7)",
      "((3 * 14) + (7 * 10))",
      "((3 * (14 + 20)) + 10)",
      "(7 * ((10 - 14) + 20))",
      "(7 * (10 - (14 - 20)))",
      "(7 * ((10 + 20) - 14))",
      "(7 * (10 + (20 - 14)))",
      "((7 - (14 / 10)) * 20)",
      "(7 * (14 + (20 / 10)))",
      "(7 * (20 - (14 - 10)))"
    ]
  },
  {
    "target": 115,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((7 * 14) - 3) + 20)",
      "((7 * 14) - (3 - 20))",
      "(((7 * 14) + 20) - 3)",
      "((7 * 14) + (20 - 3))",
      "(20 - (3 - (7 * 14)))"
    ]
  },
  {
    "target": 117,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(7 - ((3 - 14) * 10))",
      "(7 + (10 * (14 - 3)))",
      "((10 * 14) - (3 + 20))",
      "(((10 * 14) - 3) - 20)",
      "(((10 * 14) - 20) - 3)"
    ]
  },
  {
    "target": 119,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(3 + 14) * 7",
      "((10 * 14) - (3 * 7))",
      "7 * (20 - 3)",
      "((3 - 20) * (7 - 14))",
      "((14 - 7) * (20 - 3))"
    ]
  },
  {
    "target": 37,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "((2 * (11 - 5)) + 25)",
      "(25 - (2 * (5 - 11)))",
      "12 + 25",
      "((2 + (5 * 12)) - 25)",
      "(2 + ((5 * 12) - 25))",
      "((2 - 25) + (5 * 12))",
      "(2 - (25 - (5 * 12)))",
      "((5 * 12) - (25 - 2))",
      "((2 * (25 - 12)) + 11)",
      "(11 - (2 * (12 - 25)))"
    ]
  },
  {
    "target": 47,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(((5 - 2) * 12) + 11)",
      "((5 * 12) - (2 + 11))",
      "(((5 * 12) - 2) - 11)",
      "(((5 * 12) - 11) - 2)",
      "(11 - ((2 - 5) * 12))",
      "(2 * 11) + 25",
      "(((2 * 5) + 12) + 25)",
      "((2 * 5) + (12 + 25))",
      "(((2 * 5) + 25) + 12)",
      "(((11 - 5) * 12) - 25)"
    ]
  },
  {
    "target": 56,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(2 * ((5 + 11) + 12))",
      "(2 * (5 + (11 + 12)))",
      "(2 * ((5 + 12) + 11))",
      "(((2 * 25) - 5) + 11)",
      "((2 * 25) - (5 - 11))",
      "(((2 * 25) + 11) - 5)",
      "((2 * 25) + (11 - 5))",
      "(11 - (5 - (2 * 25)))"
    ]
  },
  {
    "target": 58,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(5 * 12) - 2",
      "(((5 - 2) * 11) + 25)",
      "(25 - ((2 - 5) * 11))",
      "(((12 / 5) * 25) - 2)",
      "((12 / (5 / 25)) - 2)",
      "(((12 * 25) / 5) - 2)",
      "((12 * (25 / 5)) - 2)",
      "((25 / (5 / 12)) - 2)",
      "((5 * (25 - 11)) - 12)"
    ]
  },
  {
    "target": 63,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "((2 - 11) * (5 - 12))",
      "((11 - 2) * (12 - 5))",
      "(((5 - 2) * 25) - 12)",
      "((5 * (25 - 12)) - 2)",
      "((2 * (12 + 25)) - 11)"
    ]
  },
  {
    "target": 64,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(((5 - 2) * 25) - 11)",
      "(2 * ((12 - 5) + 25))",
      "(2 * (12 - (5 - 25)))",
      "(2 * ((12 + 25) - 5))",
      "(2 * (12 + (25 - 5)))",
      "(2 * (25 - (5 - 12)))"
    ]
  },
  {
    "target": 66,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(11 / 2) * 12",
      "11 / (2 / 12)",
      "(11 * 12) / 2",
      "11 * (12 / 2)",
      "12 / (2 / 11)",
      "(((2 * 25) + 5) + 11)",
      "((2 * 25) + (5 + 11))",
      "(((2 * 25) + 11) + 5)"
    ]
  }
];


// Lightweight Auto-Puzzle Generator Engine
function autoGenerateDailyPuzzle(dateStr, gameMode = 'speed') {
  try {
    const pool = (gameMode === 'pro') ? CURATED_PRO_PUZZLES : CURATED_SPEED_PUZZLES;
    
    let hash = 0;
    const strToHash = dateStr + '_' + gameMode;
    for (let i = 0; i < strToHash.length; i++) {
      hash = (hash << 5) - hash + strToHash.charCodeAt(i);
      hash |= 0;
    }
    const idx = Math.abs(hash) % pool.length;
    const selected = pool[idx];

    const stmt = db.prepare(`
      INSERT OR IGNORE INTO daily_puzzles (puzzle_date, game_mode, target, numbers, solutions_json)
      VALUES (?, ?, ?, ?, ?)
    `);

    let puzzleSolutions = selected.solutions;
    if (gameMode === 'pro') {
      try {
        const fullSols = solveProPuzzle(selected.target, selected.numbers);
        if (fullSols && fullSols.length > 0) {
          puzzleSolutions = fullSols;
        }
      } catch (e) {
        console.error('Error solving pro puzzle automatically:', e);
      }
    }

    stmt.run(
      dateStr,
      gameMode,
      selected.target,
      JSON.stringify(selected.numbers),
      JSON.stringify(puzzleSolutions)
    );

    return db.prepare('SELECT * FROM daily_puzzles WHERE puzzle_date = ? AND game_mode = ?').get(dateStr, gameMode);
  } catch (err) {
    console.error('Error generating daily puzzle:', err);
    const pool = (gameMode === 'pro') ? CURATED_PRO_PUZZLES : CURATED_SPEED_PUZZLES;
    const fallback = pool[0];
    return {
      puzzle_date: dateStr,
      game_mode: gameMode,
      target: fallback.target,
      numbers: JSON.stringify(fallback.numbers),
      solutions_json: JSON.stringify(fallback.solutions)
    };
  }
}

// Get daily puzzle or auto-generate on demand
function getOrGenerateDailyPuzzle(dateStr, gameMode = 'speed') {
  let puzzle = db.prepare('SELECT * FROM daily_puzzles WHERE puzzle_date = ? AND game_mode = ?').get(dateStr, gameMode);
  if (!puzzle) {
    puzzle = autoGenerateDailyPuzzle(dateStr, gameMode);
    } else if (gameMode === 'pro') {
    try {
      let currentSols = JSON.parse(puzzle.solutions_json || '[]');
      // If puzzle has more than 10 or fewer than 5 solutions, swap to a curated 5-10 solution puzzle
      if (currentSols.length > 10 || currentSols.length < 5) {
        let hash = 0;
        const strToHash = dateStr + '_pro';
        for (let i = 0; i < strToHash.length; i++) {
          hash = (hash << 5) - hash + strToHash.charCodeAt(i);
          hash |= 0;
        }
        const idx = Math.abs(hash) % CURATED_PRO_PUZZLES.length;
        const selected = CURATED_PRO_PUZZLES[idx];
        
        const newTarget = selected.target;
        const newNumbers = JSON.stringify(selected.numbers);
        const newSolutions = JSON.stringify(selected.solutions);

        db.prepare('UPDATE daily_puzzles SET target = ?, numbers = ?, solutions_json = ? WHERE id = ?')
          .run(newTarget, newNumbers, newSolutions, puzzle.id);

        puzzle.target = newTarget;
        puzzle.numbers = newNumbers;
        puzzle.solutions_json = newSolutions;
      }
    } catch (e) {
      console.error('Pro puzzle 5-10 solution filter error:', e);
    }
  }
  return puzzle;
}

module.exports = {
  db,
  parseAndEvaluate,
  getCanonicalForm,
  getOrGenerateDailyPuzzle
};
