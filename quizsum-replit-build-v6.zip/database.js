const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'quizsum.db');
const db = new Database(dbPath);

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    email_opt_in INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS daily_puzzles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    puzzle_date TEXT UNIQUE NOT NULL, -- YYYY-MM-DD
    target INTEGER NOT NULL,
    numbers TEXT NOT NULL, -- JSON array e.g. "[3, 5, 8, 12, 20]"
    solutions_json TEXT NOT NULL, -- Array of pre-calculated valid solution strings
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS user_daily_games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER, -- NULL for guest
    guest_session_id TEXT,
    puzzle_date TEXT NOT NULL,
    active_time_ms INTEGER NOT NULL DEFAULT 0,
    solutions_found TEXT NOT NULL DEFAULT '[]', -- JSON array of submitted equations
    canonical_paths TEXT NOT NULL DEFAULT '[]', -- JSON array of canonical trees
    is_completed INTEGER DEFAULT 0,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, puzzle_date)
  );

  CREATE TABLE IF NOT EXISTS leaderboards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    puzzle_date TEXT NOT NULL,
    user_id INTEGER NOT NULL,
    username TEXT NOT NULL,
    solutions_count INTEGER NOT NULL,
    active_time_ms INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(puzzle_date, user_id)
  );
`);

// Safe Mathematical Expression Evaluator
function safeEval(expr) {
  const tokens = expr.match(/\d+|[+\-*/()]/g);
  if (!tokens) return null;

  let pos = 0;

  function parseExpression() {
    let left = parseTerm();
    while (pos < tokens.length && (tokens[pos] === '+' || tokens[pos] === '-')) {
      const op = tokens[pos++];
      const right = parseTerm();
      if (op === '+') left += right;
      if (op === '-') left -= right;
    }
    return left;
  }

  function parseTerm() {
    let left = parseFactor();
    while (pos < tokens.length && (tokens[pos] === '*' || tokens[pos] === '/')) {
      const op = tokens[pos++];
      const right = parseFactor();
      if (op === '*') left *= right;
      if (op === '/') {
        if (right === 0 || left % right !== 0) throw new Error('Invalid division');
        left = left / right;
      }
    }
    return left;
  }

  function parseFactor() {
    if (tokens[pos] === '(') {
      pos++; // consume '('
      const val = parseExpression();
      if (tokens[pos] !== ')') throw new Error('Missing closing parenthesis');
      pos++; // consume ')'
      return val;
    }
    const token = tokens[pos++];
    const num = parseInt(token, 10);
    if (isNaN(num)) throw new Error('Expected number');
    return num;
  }

  const res = parseExpression();
  if (pos !== tokens.length) throw new Error('Unexpected tokens at end');
  return res;
}

// Algebraic AST Canonical Normalizer to detect commutative duplicates (e.g., 2*12 vs 12*2, 3+5 vs 5+3)
function getCanonicalForm(expr) {
  try {
    const tokens = expr.replace(/\s+/g, '').match(/\d+|[+\-*/()]/g);
    if (!tokens) return expr.replace(/\s+/g, '');

    let pos = 0;

    function parseE() {
      let terms = [parseT()];
      while (pos < tokens.length && (tokens[pos] === '+' || tokens[pos] === '-')) {
        const op = tokens[pos++];
        const right = parseT();
        if (op === '+') terms.push(right);
        else terms.push('-' + right);
      }
      if (terms.length === 1) return terms[0];
      return '(' + terms.map(String).sort().join('+') + ')';
    }

    function parseT() {
      let factors = [parseF()];
      while (pos < tokens.length && (tokens[pos] === '*' || tokens[pos] === '/')) {
        const op = tokens[pos++];
        const right = parseF();
        if (op === '*') factors.push(right);
        else factors.push('/' + right);
      }
      if (factors.length === 1) return factors[0];
      let mults = [], divs = [];
      for (let f of factors) {
        let str = String(f);
        if (str.startsWith('/')) divs.push(str);
        else mults.push(str);
      }
      mults.sort();
      divs.sort();
      return '(' + [...mults, ...divs].join('*') + ')';
    }

    function parseF() {
      if (tokens[pos] === '(') {
        pos++;
        const res = parseE();
        pos++;
        return res;
      }
      return tokens[pos++];
    }

    return String(parseE());
  } catch (e) {
    return expr.replace(/\s+/g, '');
  }
}

// Mathematical Equation Evaluator & Validation
function parseAndEvaluate(equationStr, availableNumbers) {
  const clean = equationStr.replace(/\s+/g, '');

  if (!/^[0-9+\-*/()]+$/.test(clean)) {
    return { valid: false, reason: 'Invalid characters in equation.' };
  }

  const numbersUsed = clean.match(/\d+/g) ? clean.match(/\d+/g).map(Number) : [];
  if (numbersUsed.length === 0) {
    return { valid: false, reason: 'No numbers found in equation.' };
  }

  const availableCopy = [...availableNumbers];
  for (const num of numbersUsed) {
    const idx = availableCopy.indexOf(num);
    if (idx === -1) {
      return { valid: false, reason: `Number ${num} is not in the available tiles or used too many times.` };
    }
    availableCopy.splice(idx, 1);
  }

  try {
    const result = safeEval(clean);
    if (result === null || !Number.isInteger(result)) {
      return { valid: false, reason: 'Equation results in a non-integer or division error.' };
    }
    const canonical = getCanonicalForm(clean);
    return { valid: true, value: result, numbersUsed, canonical };
  } catch (err) {
    return { valid: false, reason: 'Invalid mathematical expression syntax.' };
  }
}

// Dynamic Auto-Puzzle Generator Engine (Guarantees >= 3 solutions, no duplications across days)
function autoGenerateDailyPuzzle(dateStr) {
  const pool = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 18, 20, 25];

  function shuffle(array) {
    let copy = [...array];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }

  function buildTrees(nums) {
    if (nums.length === 1) return [{ val: nums[0], expr: String(nums[0]) }];
    let results = [];
    for (let i = 1; i < nums.length; i++) {
      let leftTrees = buildTrees(nums.slice(0, i));
      let rightTrees = buildTrees(nums.slice(i));
      for (let l of leftTrees) {
        for (let r of rightTrees) {
          results.push({ val: l.val + r.val, expr: '(' + l.expr + ' + ' + r.expr + ')' });
          if (l.val - r.val > 0) results.push({ val: l.val - r.val, expr: '(' + l.expr + ' - ' + r.expr + ')' });
          results.push({ val: l.val * r.val, expr: '(' + l.expr + ' * ' + r.expr + ')' });
          if (r.val !== 0 && l.val % r.val === 0) results.push({ val: l.val / r.val, expr: '(' + l.expr + ' / ' + r.expr + ')' });
        }
      }
    }
    return results;
  }

  function getPermutations(arr, k) {
    if (k === 1) return arr.map(x => [x]);
    let perms = [];
    for (let i = 0; i < arr.length; i++) {
      let rest = [...arr.slice(0, i), ...arr.slice(i + 1)];
      let sub = getPermutations(rest, k - 1);
      for (let s of sub) perms.push([arr[i], ...s]);
    }
    return perms;
  }

  // Attempt up to 20 random tile sets until finding a non-duplicate target with >= 3 distinct solutions
  for (let attempt = 0; attempt < 20; attempt++) {
    const selectedNums = shuffle(pool).slice(0, 5).sort((a, b) => a - b);
    const targets = new Map();

    for (let k = 2; k <= 4; k++) {
      const perms = getPermutations(selectedNums, k);
      for (let p of perms) {
        const trees = buildTrees(p);
        for (let t of trees) {
          if (t.val >= 12 && t.val <= 350 && Number.isInteger(t.val)) {
            const canon = getCanonicalForm(t.expr);
            if (!targets.has(t.val)) targets.set(t.val, new Map());
            if (!targets.get(t.val).has(canon)) {
              targets.get(t.val).set(canon, t.expr);
            }
          }
        }
      }
    }

    // Filter candidate targets with >= 3 distinct solutions
    const validCandidates = [];
    for (let [targetVal, canonMap] of targets.entries()) {
      if (canonMap.size >= 3) {
        validCandidates.push({
          target: targetVal,
          solutions_count: canonMap.size,
          solutions: Array.from(canonMap.values())
        });
      }
    }

    if (validCandidates.length > 0) {
      // Pick a random candidate target
      const chosen = validCandidates[Math.floor(Math.random() * validCandidates.length)];

      // Check if this exact (target, numbers) was ever used in previous daily puzzles
      const existing = db.prepare('SELECT id FROM daily_puzzles WHERE target = ? AND numbers = ?')
        .get(chosen.target, JSON.stringify(selectedNums));

      if (!existing) {
        // Insert and return new daily puzzle
        const stmt = db.prepare(`
          INSERT INTO daily_puzzles (puzzle_date, target, numbers, solutions_json)
          VALUES (?, ?, ?, ?)
        `);

        stmt.run(
          dateStr,
          chosen.target,
          JSON.stringify(selectedNums),
          JSON.stringify(chosen.solutions)
        );

        return db.prepare('SELECT * FROM daily_puzzles WHERE puzzle_date = ?').get(dateStr);
      }
    }
  }

  // Fallback default puzzle if attempts exhausted
  const fallbackNums = [3, 4, 6, 8, 12];
  const stmt = db.prepare(`
    INSERT OR IGNORE INTO daily_puzzles (puzzle_date, target, numbers, solutions_json)
    VALUES (?, ?, ?, ?)
  `);
  stmt.run(
    dateStr,
    24,
    JSON.stringify(fallbackNums),
    JSON.stringify(["3 * 8", "6 * 4", "12 + 8 + 4"])
  );

  return db.prepare('SELECT * FROM daily_puzzles WHERE puzzle_date = ?').get(dateStr);
}

// Get daily puzzle or auto-generate on demand
function getOrGenerateDailyPuzzle(dateStr) {
  let puzzle = db.prepare('SELECT * FROM daily_puzzles WHERE puzzle_date = ?').get(dateStr);
  if (!puzzle) {
    puzzle = autoGenerateDailyPuzzle(dateStr);
  }
  return puzzle;
}

module.exports = {
  db,
  parseAndEvaluate,
  getCanonicalForm,
  getOrGenerateDailyPuzzle
};
