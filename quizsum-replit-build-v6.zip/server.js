const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const { db, parseAndEvaluate, getOrGenerateDailyPuzzle } = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'quizsum-secret-key-replit-2026',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 } // 30 days
  })
);

// Helper to get today's YYYY-MM-DD
function getTodayString() {
  return new Date().toISOString().split('T')[0];
}

// ------------------------------------------------------------------
// 1. GET /api/daily - Fetch today's target & numbers (Auto-Generated)
// ------------------------------------------------------------------
app.get('/api/daily', (req, res) => {
  const today = getTodayString();
  const puzzle = getOrGenerateDailyPuzzle(today);

  if (!puzzle) {
    return res.status(500).json({ error: 'Could not generate daily puzzle.' });
  }

  // Get user's existing progress if logged in or guest session
  const userId = req.session.userId || null;
  const guestId = req.session.id;

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ?').get(userId, today);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ?').get(guestId, today);
  }

  res.json({
    puzzle_date: puzzle.puzzle_date,
    target: puzzle.target,
    numbers: JSON.parse(puzzle.numbers),
    user_game: gameRecord
      ? {
          active_time_ms: gameRecord.active_time_ms,
          solutions_found: JSON.parse(gameRecord.solutions_found),
          is_completed: gameRecord.is_completed === 1
        }
      : null
  });
});

// ------------------------------------------------------------------
// 2. POST /api/verify - Validate player solution submission
// ------------------------------------------------------------------
app.post('/api/verify', (req, res) => {
  const { equation, active_time_ms } = req.body;
  const today = getTodayString();

  if (!equation || typeof equation !== 'string') {
    return res.status(400).json({ error: 'Equation string is required.' });
  }

  const puzzle = getOrGenerateDailyPuzzle(today);
  if (!puzzle) {
    return res.status(404).json({ error: 'Puzzle not found.' });
  }

  const availableNumbers = JSON.parse(puzzle.numbers);
  const target = puzzle.target;

  // Evaluate mathematical equation
  const evalResult = parseAndEvaluate(equation, availableNumbers);
  if (!evalResult.valid) {
    return res.json({
      is_correct: false,
      message: evalResult.reason
    });
  }

  if (evalResult.value !== target) {
    return res.json({
      is_correct: false,
      message: `Equals ${evalResult.value}, but the target is ${target}.`
    });
  }

  // Check against user's existing found solutions for duplicate/algebraic path check
  const userId = req.session.userId || null;
  const guestId = req.session.id;

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ?').get(userId, today);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ?').get(guestId, today);
  }

  let solutionsFound = gameRecord ? JSON.parse(gameRecord.solutions_found) : [];
  let canonicalPaths = gameRecord ? JSON.parse(gameRecord.canonical_paths) : [];

  // Check if canonical tree already exists (e.g. 2*12 vs 12*2, 3+5 vs 5+3)
  if (canonicalPaths.includes(evalResult.canonical)) {
    return res.json({
      is_correct: false,
      is_duplicate: true,
      message: 'You already found a mathematically identical solution path!'
    });
  }

  // Add new distinct solution
  solutionsFound.push(equation.trim());
  canonicalPaths.push(evalResult.canonical);

  const updatedTime = (gameRecord ? gameRecord.active_time_ms : 0) + (active_time_ms || 0);

  if (gameRecord) {
    db.prepare(`
      UPDATE user_daily_games 
      SET solutions_found = ?, canonical_paths = ?, active_time_ms = ?
      WHERE id = ?
    `).run(JSON.stringify(solutionsFound), JSON.stringify(canonicalPaths), updatedTime, gameRecord.id);
  } else {
    db.prepare(`
      INSERT INTO user_daily_games (user_id, guest_session_id, puzzle_date, active_time_ms, solutions_found, canonical_paths)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(userId, guestId, today, updatedTime, JSON.stringify(solutionsFound), JSON.stringify(canonicalPaths));
  }

  res.json({
    is_correct: true,
    message: "Well done! You've found a valid solution.",
    solutions_count: solutionsFound.length,
    solutions_found: solutionsFound
  });
});

// ------------------------------------------------------------------
// 3. POST /api/finish - Complete game session & submit score
// ------------------------------------------------------------------
app.post('/api/finish', (req, res) => {
  const { active_time_ms } = req.body;
  const today = getTodayString();
  const userId = req.session.userId || null;
  const guestId = req.session.id;

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ?').get(userId, today);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ?').get(guestId, today);
  }

  if (!gameRecord) {
    return res.status(400).json({ error: 'No active game session found.' });
  }

  const finalTime = Math.max(gameRecord.active_time_ms, active_time_ms || gameRecord.active_time_ms);
  const solutions = JSON.parse(gameRecord.solutions_found);

  // Mark game as completed
  db.prepare('UPDATE user_daily_games SET is_completed = 1, active_time_ms = ? WHERE id = ?').run(finalTime, gameRecord.id);

  // If user is logged in, post to leaderboard
  let leaderboardPosition = null;
  if (userId) {
    const user = db.prepare('SELECT username FROM users WHERE id = ?').get(userId);
    if (user) {
      db.prepare(`
        INSERT INTO leaderboards (puzzle_date, user_id, username, solutions_count, active_time_ms)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(puzzle_date, user_id) DO UPDATE SET
          solutions_count = excluded.solutions_count,
          active_time_ms = excluded.active_time_ms
      `).run(today, userId, user.username, solutions.length, finalTime);

      // Rank position
      const higherRanks = db.prepare(`
        SELECT COUNT(*) as rank FROM leaderboards
        WHERE puzzle_date = ? AND (solutions_count > ? OR (solutions_count = ? AND active_time_ms < ?))
      `).get(today, solutions.length, solutions.length, finalTime).rank;

      leaderboardPosition = higherRanks + 1;
    }
  }

  res.json({
    is_completed: true,
    solutions_found_count: solutions.length,
    solutions_found: solutions,
    final_time_ms: finalTime,
    leaderboard_position: leaderboardPosition,
    is_guest: !userId
  });
});

// ------------------------------------------------------------------
// 4. GET /api/leaderboard - Daily, Weekly, and Overall Leaderboard
// ------------------------------------------------------------------
app.get('/api/leaderboard', (req, res) => {
  const type = (req.query.type || 'daily').toLowerCase();
  const today = getTodayString();

  if (type === 'weekly') {
    // 7-day window
    const d = new Date();
    d.setDate(d.getDate() - 6);
    const sevenDaysAgo = d.toISOString().split('T')[0];

    const rows = db.prepare(`
      SELECT username, 
             SUM(solutions_count) as solutions_count, 
             SUM(active_time_ms) as active_time_ms, 
             COUNT(DISTINCT puzzle_date) as games_played
      FROM leaderboards
      WHERE puzzle_date >= ?
      GROUP BY user_id, username
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(sevenDaysAgo);

    return res.json({ type: 'weekly', leaderboard: rows });
  } else if (type === 'overall') {
    // Lifetime all-time
    const rows = db.prepare(`
      SELECT username, 
             SUM(solutions_count) as solutions_count, 
             SUM(active_time_ms) as active_time_ms, 
             COUNT(DISTINCT puzzle_date) as games_played
      FROM leaderboards
      GROUP BY user_id, username
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all();

    return res.json({ type: 'overall', leaderboard: rows });
  } else {
    // Daily (default)
    const rows = db.prepare(`
      SELECT username, solutions_count, active_time_ms, created_at 
      FROM leaderboards 
      WHERE puzzle_date = ?
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(today);

    return res.json({ type: 'daily', puzzle_date: today, leaderboard: rows });
  }
});

// ------------------------------------------------------------------
// 5. Auth Routes (Register, Login, Logout, Me)
// ------------------------------------------------------------------
app.post('/api/auth/register', (req, res) => {
  const { username, email, password, email_opt_in } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Username, email, and password are required.' });
  }

  try {
    const password_hash = bcrypt.hashSync(password, 10);
    const result = db.prepare(`
      INSERT INTO users (username, email, password_hash, email_opt_in)
      VALUES (?, ?, ?, ?)
    `).run(username.trim(), email.trim().toLowerCase(), password_hash, email_opt_in ? 1 : 0);

    req.session.userId = result.lastInsertRowid;
    req.session.username = username.trim();

    // Migrate any guest game record to user account
    const today = getTodayString();
    db.prepare('UPDATE user_daily_games SET user_id = ? WHERE guest_session_id = ? AND puzzle_date = ?')
      .run(result.lastInsertRowid, req.session.id, today);

    res.json({
      success: true,
      user: { id: result.lastInsertRowid, username: username.trim(), email: email.trim() }
    });
  } catch (err) {
    if (err.message.includes('UNIQUE constraint failed')) {
      return res.status(400).json({ error: 'Username or email already exists.' });
    }
    res.status(500).json({ error: 'Account creation failed.' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { username_or_email, password } = req.body;

  if (!username_or_email || !password) {
    return res.status(400).json({ error: 'Credentials required.' });
  }

  const user = db.prepare(`
    SELECT * FROM users WHERE username = ? OR email = ?
  `).get(username_or_email.trim(), username_or_email.trim().toLowerCase());

  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(400).json({ error: 'Invalid username/email or password.' });
  }

  req.session.userId = user.id;
  req.session.username = user.username;

  res.json({
    success: true,
    user: { id: user.id, username: user.username, email: user.email }
  });
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  if (req.session.userId) {
    const user = db.prepare('SELECT id, username, email, email_opt_in FROM users WHERE id = ?').get(req.session.userId);
    return res.json({ loggedIn: true, user });
  }
  res.json({ loggedIn: false });
});

// Start server
app.listen(PORT, () => {
  console.log(`QuizSum server running on port ${PORT}`);
});
