// QuizSum Frontend State & Game Engine
let gameState = {
  puzzleDate: null,
  target: 0,
  numbers: [],
  solutionsFound: [],
  activeTimeMs: 0,
  timerInterval: null,
  startTime: null,
  isPaused: false,
  isCompleted: false,
  currentTokens: [] // Array of { type: 'number'|'operator', val: string, tileIndex?: number }
};

let currentLeaderboardType = 'daily';

document.addEventListener('DOMContentLoaded', () => {
  initApp();
  bindEvents();
});

async function initApp() {
  checkAuthStatus();
  fetchTodayPuzzle();
}

// ------------------------------------------------------------------
// API Interaction
// ------------------------------------------------------------------
async function fetchTodayPuzzle() {
  try {
    const res = await fetch('/api/daily');
    const data = await res.json();

    if (data.error) {
      alert(data.error);
      return;
    }

    gameState.puzzleDate = data.puzzle_date;
    gameState.target = data.target;
    gameState.numbers = data.numbers;

    document.getElementById('daily-date').textContent = `Daily Challenge: ${data.puzzle_date}`;

    if (data.user_game) {
      gameState.activeTimeMs = data.user_game.active_time_ms;
      gameState.solutionsFound = data.user_game.solutions_found || [];
      gameState.isCompleted = data.user_game.is_completed;
      updateFoundCountDisplay();
      updateTimerDisplay(gameState.activeTimeMs);
    }
  } catch (err) {
    console.error('Failed to load puzzle', err);
  }
}

async function checkAuthStatus() {
  try {
    const res = await fetch('/api/auth/me');
    const data = await res.json();
    if (data.loggedIn) {
      document.getElementById('btn-account').textContent = data.user.username;
      document.getElementById('profile-username').textContent = data.user.username;
      document.getElementById('profile-email').textContent = data.user.email;
      document.getElementById('auth-forms').classList.add('hidden');
      document.getElementById('user-profile-view').classList.remove('hidden');
    }
  } catch (err) {
    console.error('Auth check error', err);
  }
}

// ------------------------------------------------------------------
// Game Logic & Events
// ------------------------------------------------------------------
function bindEvents() {
  // Start Game Button
  document.getElementById('btn-start-game').addEventListener('click', startGame);

  // Deck & Clear
  document.getElementById('btn-clear').addEventListener('click', clearEquation);
  document.getElementById('btn-backspace').addEventListener('click', backspaceEquation);
  document.getElementById('btn-submit').addEventListener('click', submitEquation);

  // Midway Finish Button
  document.getElementById('btn-finish-midway').addEventListener('click', finishAndRecordScore);

  // Operators
  document.querySelectorAll('.op-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      addOperatorToken(btn.dataset.op);
    });
  });

  // Pause Screen Buttons
  document.getElementById('btn-try-another').addEventListener('click', resumeGameSearch);
  document.getElementById('btn-finish-score').addEventListener('click', finishAndRecordScore);

  // Nav Modals
  document.getElementById('btn-account').addEventListener('click', () => {
    document.getElementById('modal-account').classList.remove('hidden');
  });
  document.getElementById('close-account').addEventListener('click', () => {
    document.getElementById('modal-account').classList.add('hidden');
  });

  document.getElementById('btn-leaderboard').addEventListener('click', () => openLeaderboard('daily'));
  document.getElementById('close-leaderboard').addEventListener('click', () => {
    document.getElementById('modal-leaderboard').classList.add('hidden');
  });

  // Leaderboard Tab Switches
  document.querySelectorAll('.lb-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.lb-tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      openLeaderboard(btn.dataset.type);
    });
  });

  // Auth form switches
  document.getElementById('switch-to-register').addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('login-section').classList.add('hidden');
    document.getElementById('register-section').classList.remove('hidden');
  });
  document.getElementById('switch-to-login').addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('register-section').classList.add('hidden');
    document.getElementById('login-section').classList.remove('hidden');
  });

  // Auth Forms Submit
  document.getElementById('form-login').addEventListener('submit', handleLogin);
  document.getElementById('form-register').addEventListener('submit', handleRegister);
  document.getElementById('btn-logout').addEventListener('click', handleLogout);
}

function startGame() {
  document.getElementById('screen-start').classList.add('hidden');
  document.getElementById('screen-active').classList.remove('hidden');

  document.getElementById('target-number').textContent = gameState.target;
  renderTiles();

  startTimer();
}

function renderTiles() {
  const container = document.getElementById('tiles-container');
  container.innerHTML = '';

  gameState.numbers.forEach((num, index) => {
    const tile = document.createElement('button');
    tile.className = 'num-tile';
    tile.textContent = num;
    tile.dataset.index = index;
    tile.addEventListener('click', () => handleTileClick(num, index));
    container.appendChild(tile);
  });
}

function handleTileClick(num, index) {
  const tileEl = document.querySelector(`.num-tile[data-index="${index}"]`);
  if (tileEl.classList.contains('used')) return;

  tileEl.classList.add('used');
  gameState.currentTokens.push({ type: 'number', val: num, tileIndex: index });
  renderEquationDisplay();
}

function addOperatorToken(op) {
  gameState.currentTokens.push({ type: 'operator', val: op });
  renderEquationDisplay();
}

function clearEquation() {
  gameState.currentTokens = [];
  document.querySelectorAll('.num-tile').forEach(t => t.classList.remove('used'));
  renderEquationDisplay();
}

function backspaceEquation() {
  const popped = gameState.currentTokens.pop();
  if (popped && popped.type === 'number') {
    const tileEl = document.querySelector(`.num-tile[data-index="${popped.tileIndex}"]`);
    if (tileEl) tileEl.classList.remove('used');
  }
  renderEquationDisplay();
}

function renderEquationDisplay() {
  const box = document.getElementById('equation-display');
  if (gameState.currentTokens.length === 0) {
    box.innerHTML = '<span class="placeholder-text">Tap tiles & operators to build equation...</span>';
    return;
  }

  box.textContent = gameState.currentTokens.map(t => t.val).join(' ');
}

// ------------------------------------------------------------------
// Timer (Stopwatch) Engine
// ------------------------------------------------------------------
function startTimer() {
  if (gameState.timerInterval) clearInterval(gameState.timerInterval);
  gameState.startTime = Date.now() - gameState.activeTimeMs;
  gameState.isPaused = false;

  gameState.timerInterval = setInterval(() => {
    if (!gameState.isPaused) {
      gameState.activeTimeMs = Date.now() - gameState.startTime;
      updateTimerDisplay(gameState.activeTimeMs);
    }
  }, 100);
}

function pauseTimer() {
  gameState.isPaused = true;
  if (gameState.timerInterval) clearInterval(gameState.timerInterval);
}

function updateTimerDisplay(ms) {
  const totalSec = Math.floor(ms / 1000);
  const mins = String(Math.floor(totalSec / 60)).padStart(2, '0');
  const secs = String(totalSec % 60).padStart(2, '0');
  const tenths = Math.floor((ms % 1000) / 100);

  document.getElementById('timer-display').textContent = `${mins}:${secs}.${tenths}`;
}

// ------------------------------------------------------------------
// Solution Verification & Pause Screen (Anti-Cheat Blur)
// ------------------------------------------------------------------
async function submitEquation() {
  if (gameState.currentTokens.length === 0) return;

  const equationStr = gameState.currentTokens.map(t => t.val).join(' ');

  try {
    const res = await fetch('/api/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        equation: equationStr,
        active_time_ms: gameState.activeTimeMs
      })
    });

    const data = await res.json();

    if (data.is_correct) {
      pauseTimer(); // Instantly pause clock
      gameState.solutionsFound = data.solutions_found;
      updateFoundCountDisplay();

      // Show Anti-Cheat Blur Pause Modal
      document.getElementById('latest-solution-box').textContent = `${equationStr} = ${gameState.target}`;
      document.getElementById('modal-pause').classList.remove('hidden');
      clearEquation();
    } else {
      showFeedback(data.message || 'Invalid equation', 'error');
    }
  } catch (err) {
    showFeedback('Error verifying submission', 'error');
  }
}

function resumeGameSearch() {
  document.getElementById('modal-pause').classList.add('hidden');
  startTimer(); // Unblur and restart clock
}

async function finishAndRecordScore() {
  pauseTimer();
  document.getElementById('modal-pause').classList.add('hidden');

  try {
    const res = await fetch('/api/finish', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active_time_ms: gameState.activeTimeMs })
    });

    const data = await res.json();

    if (data.is_guest) {
      // Prompt guest directly to register to save score
      document.getElementById('modal-account').classList.remove('hidden');
      document.getElementById('register-section').classList.remove('hidden');
      document.getElementById('login-section').classList.add('hidden');
      document.getElementById('auth-title').textContent = '🏆 Save Score to Leaderboard!';
    } else {
      openLeaderboard('daily');
    }
  } catch (err) {
    console.error('Error finishing game', err);
  }
}

function updateFoundCountDisplay() {
  document.getElementById('found-count').textContent = gameState.solutionsFound.length;
}

function showFeedback(msg, type) {
  const banner = document.getElementById('feedback-msg');
  banner.textContent = msg;
  banner.className = `feedback-banner ${type}`;
  banner.classList.remove('hidden');

  setTimeout(() => {
    banner.classList.add('hidden');
  }, 3000);
}

// ------------------------------------------------------------------
// Leaderboard & Authentication
// ------------------------------------------------------------------
async function openLeaderboard(type = 'daily') {
  currentLeaderboardType = type;
  try {
    const res = await fetch(`/api/leaderboard?type=${type}`);
    const data = await res.json();

    const container = document.getElementById('leaderboard-list');
    if (!data.leaderboard || data.leaderboard.length === 0) {
      container.innerHTML = '<p style="text-align:center; color: var(--text-muted); padding: 1.5rem 0;">No recorded scores yet for this period. Be the first!</p>';
    } else {
      const isMultiDay = type === 'weekly' || type === 'overall';
      
      let html = `<table class="lb-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Player</th>
            <th>Solutions</th>
            <th>${isMultiDay ? 'Puzzles' : 'Time'}</th>
          </tr>
        </thead>
        <tbody>`;

      data.leaderboard.forEach((row, idx) => {
        const sec = Math.floor(row.active_time_ms / 1000);
        const mins = String(Math.floor(sec / 60)).padStart(2, '0');
        const secs = String(sec % 60).padStart(2, '0');

        html += `<tr>
          <td><strong>${idx + 1}</strong></td>
          <td>${row.username}</td>
          <td><strong style="color:var(--gold-color)">${row.solutions_count}</strong></td>
          <td>${isMultiDay ? row.games_played : `${mins}:${secs}`}</td>
        </tr>`;
      });

      html += '</tbody></table>';
      container.innerHTML = html;
    }

    document.getElementById('modal-leaderboard').classList.remove('hidden');
  } catch (err) {
    console.error('Leaderboard error', err);
  }
}

async function handleLogin(e) {
  e.preventDefault();
  const userOrEmail = document.getElementById('login-user').value;
  const pass = document.getElementById('login-pass').value;

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username_or_email: userOrEmail, password: pass })
    });

    const data = await res.json();
    if (data.success) {
      location.reload();
    } else {
      alert(data.error);
    }
  } catch (err) {
    alert('Login failed.');
  }
}

async function handleRegister(e) {
  e.preventDefault();
  const username = document.getElementById('reg-user').value;
  const email = document.getElementById('reg-email').value;
  const password = document.getElementById('reg-pass').value;
  const email_opt_in = document.getElementById('reg-optin').checked;

  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password, email_opt_in })
    });

    const data = await res.json();
    if (data.success) {
      // Auto submit game if pending
      await fetch('/api/finish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active_time_ms: gameState.activeTimeMs })
      });
      location.reload();
    } else {
      alert(data.error);
    }
  } catch (err) {
    alert('Registration failed.');
  }
}

async function handleLogout() {
  await fetch('/api/auth/logout', { method: 'POST' });
  location.reload();
}
