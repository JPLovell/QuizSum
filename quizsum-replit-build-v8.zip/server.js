const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const { db, parseAndEvaluate, getOrGenerateDailyPuzzle } = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'quizsum-secret-key-replit-2026',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 } // 30 days
  })
);

// Helper to get sanitized YYYY-MM-DD date string
function getSanitizedDate(req) {
  const reqDate = req.query.date || req.body.date || req.body.puzzle_date;
  if (reqDate && /^\d{4}-\d{2}-\d{2}$/.test(reqDate)) {
    return reqDate;
  }
  return new Date().toISOString().split('T')[0];
}

// ------------------------------------------------------------------
// 1. GET /api/daily - Fetch today's target & numbers
// ------------------------------------------------------------------
app.get('/api/daily', (req, res) => {
  const today = getSanitizedDate(req);
  const puzzle = getOrGenerateDailyPuzzle(today);

  if (!puzzle) {
    return res.status(500).json({ error: 'Could not generate daily puzzle.' });
  }

  const userId = req.session.userId || null;
  const guestId = req.session.id;

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ?').get(userId, today);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ?').get(guestId, today);
  }

  res.json({
    puzzle_date: puzzle.puzzle_date,
    target: puzzle.target,
    numbers: JSON.parse(puzzle.numbers),
    user_game: gameRecord
      ? {
          active_time_ms: gameRecord.active_time_ms,
          solutions_found: JSON.parse(gameRecord.solutions_found),
          is_completed: gameRecord.is_completed === 1
        }
      : null
  });
});

// ------------------------------------------------------------------
// 2. POST /api/sync-timer - Real-time active playing time persistence
// ------------------------------------------------------------------
app.post('/api/sync-timer', (req, res) => {
  const { active_time_ms } = req.body;
  const today = getSanitizedDate(req);
  const userId = req.session.userId || null;
  const guestId = req.session.id;

  if (typeof active_time_ms !== 'number' || active_time_ms < 0) {
    return res.status(400).json({ error: 'Valid active_time_ms required.' });
  }

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ?').get(userId, today);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ?').get(guestId, today);
  }

  if (gameRecord) {
    const updatedTime = Math.max(gameRecord.active_time_ms, active_time_ms);
    db.prepare('UPDATE user_daily_games SET active_time_ms = ? WHERE id = ?').run(updatedTime, gameRecord.id);
  } else {
    db.prepare(`
      INSERT INTO user_daily_games (user_id, guest_session_id, puzzle_date, active_time_ms, solutions_found, canonical_paths)
      VALUES (?, ?, ?, ?, '[]', '[]')
    `).run(userId, guestId, today, active_time_ms);
  }

  res.json({ success: true, active_time_ms });
});

// ------------------------------------------------------------------
// 3. POST /api/verify - Validate player solution submission
// ------------------------------------------------------------------
app.post('/api/verify', (req, res) => {
  const { equation, active_time_ms } = req.body;
  const today = getSanitizedDate(req);

  if (!equation || typeof equation !== 'string') {
    return res.status(400).json({ error: 'Equation string is required.' });
  }

  const puzzle = getOrGenerateDailyPuzzle(today);
  if (!puzzle) {
    return res.status(404).json({ error: 'Puzzle not found.' });
  }

  const availableNumbers = JSON.parse(puzzle.numbers);
  const target = puzzle.target;

  const evalResult = parseAndEvaluate(equation, availableNumbers);
  if (!evalResult.valid) {
    return res.json({
      is_correct: false,
      message: evalResult.reason
    });
  }

  if (evalResult.value !== target) {
    return res.json({
      is_correct: false,
      message: `Equals ${evalResult.value}, but the target is ${target}.`
    });
  }

  const userId = req.session.userId || null;
  const guestId = req.session.id;

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ?').get(userId, today);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ?').get(guestId, today);
  }

  let solutionsFound = gameRecord ? JSON.parse(gameRecord.solutions_found) : [];
  let canonicalPaths = gameRecord ? JSON.parse(gameRecord.canonical_paths) : [];

  if (canonicalPaths.includes(evalResult.canonical)) {
    return res.json({
      is_correct: false,
      is_duplicate: true,
      message: 'You already found a mathematically identical solution path!'
    });
  }

  solutionsFound.push(equation.trim());
  canonicalPaths.push(evalResult.canonical);

  const updatedTime = Math.max(gameRecord ? gameRecord.active_time_ms : 0, active_time_ms || 0);

  if (gameRecord) {
    db.prepare(`
      UPDATE user_daily_games 
      SET solutions_found = ?, canonical_paths = ?, active_time_ms = ?
      WHERE id = ?
    `).run(JSON.stringify(solutionsFound), JSON.stringify(canonicalPaths), updatedTime, gameRecord.id);
  } else {
    db.prepare(`
      INSERT INTO user_daily_games (user_id, guest_session_id, puzzle_date, active_time_ms, solutions_found, canonical_paths)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(userId, guestId, today, updatedTime, JSON.stringify(solutionsFound), JSON.stringify(canonicalPaths));
  }

  res.json({
    is_correct: true,
    message: "Well done! You've found a valid solution.",
    solutions_count: solutionsFound.length,
    solutions_found: solutionsFound
  });
});

// ------------------------------------------------------------------
// 4. POST /api/finish - Complete game session & submit score
// ------------------------------------------------------------------
app.post('/api/finish', (req, res) => {
  const { active_time_ms } = req.body;
  const today = getSanitizedDate(req);
  const userId = req.session.userId || null;
  const guestId = req.session.id;

  let gameRecord;
  if (userId) {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE user_id = ? AND puzzle_date = ?').get(userId, today);
  } else {
    gameRecord = db.prepare('SELECT * FROM user_daily_games WHERE guest_session_id = ? AND puzzle_date = ?').get(guestId, today);
  }

  if (!gameRecord) {
    return res.status(400).json({ error: 'No active game session found.' });
  }

  const finalTime = Math.max(gameRecord.active_time_ms, active_time_ms || gameRecord.active_time_ms);
  const solutions = JSON.parse(gameRecord.solutions_found);

  db.prepare('UPDATE user_daily_games SET is_completed = 1, active_time_ms = ? WHERE id = ?').run(finalTime, gameRecord.id);

  let leaderboardPosition = null;
  if (userId) {
    const user = db.prepare('SELECT username FROM users WHERE id = ?').get(userId);
    if (user) {
      db.prepare(`
        INSERT INTO leaderboards (puzzle_date, user_id, username, solutions_count, active_time_ms)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(puzzle_date, user_id) DO UPDATE SET
          solutions_count = excluded.solutions_count,
          active_time_ms = excluded.active_time_ms
      `).run(today, userId, user.username, solutions.length, finalTime);

      const higherRanks = db.prepare(`
        SELECT COUNT(*) as rank FROM leaderboards
        WHERE puzzle_date = ? AND (solutions_count > ? OR (solutions_count = ? AND active_time_ms < ?))
      `).get(today, solutions.length, solutions.length, finalTime).rank;

      leaderboardPosition = higherRanks + 1;
    }
  }

  res.json({
    is_completed: true,
    solutions_found_count: solutions.length,
    solutions_found: solutions,
    final_time_ms: finalTime,
    leaderboard_position: leaderboardPosition,
    is_guest: !userId
  });
});

// ------------------------------------------------------------------
// 5. GET /api/leaderboard - Daily, Weekly, and Overall Leaderboard
// ------------------------------------------------------------------
app.get('/api/leaderboard', (req, res) => {
  const type = (req.query.type || 'daily').toLowerCase();
  const today = getSanitizedDate(req);

  if (type === 'weekly') {
    const d = new Date();
    d.setDate(d.getDate() - 6);
    const sevenDaysAgo = d.toISOString().split('T')[0];

    const rows = db.prepare(`
      SELECT username, 
             SUM(solutions_count) as solutions_count, 
             SUM(active_time_ms) as active_time_ms, 
             COUNT(DISTINCT puzzle_date) as games_played
      FROM leaderboards
      WHERE puzzle_date >= ?
      GROUP BY user_id, username
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(sevenDaysAgo);

    return res.json({ type: 'weekly', leaderboard: rows });
  } else if (type === 'overall') {
    const rows = db.prepare(`
      SELECT username, 
             SUM(solutions_count) as solutions_count, 
             SUM(active_time_ms) as active_time_ms, 
             COUNT(DISTINCT puzzle_date) as games_played
      FROM leaderboards
      GROUP BY user_id, username
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all();

    return res.json({ type: 'overall', leaderboard: rows });
  } else {
    const rows = db.prepare(`
      SELECT username, solutions_count, active_time_ms, created_at 
      FROM leaderboards 
      WHERE puzzle_date = ?
      ORDER BY solutions_count DESC, active_time_ms ASC
      LIMIT 100
    `).all(today);

    return res.json({ type: 'daily', puzzle_date: today, leaderboard: rows });
  }
});

// ------------------------------------------------------------------
// 6. Auth Routes (Register, Login, Logout, Me)
// ------------------------------------------------------------------
app.post('/api/auth/register', (req, res) => {
  const { username, email, password, email_opt_in } = req.body;

  const cleanUser = (username || '').trim();
  const cleanEmail = (email || '').trim().toLowerCase();
  const cleanPass = (password || '').trim();

  if (!cleanUser || cleanUser.length < 3) {
    return res.status(400).json({ error: 'Username must be at least 3 characters long.' });
  }
  if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }
  if (!cleanPass || cleanPass.length < 4) {
    return res.status(400).json({ error: 'Password must be at least 4 characters.' });
  }

  // Check if username or email already exists
  const existingUser = db.prepare('SELECT username, email FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)')
    .get(cleanUser, cleanEmail);

  if (existingUser) {
    if (existingUser.username.toLowerCase() === cleanUser.toLowerCase()) {
      return res.status(400).json({ error: 'Username is already taken. Please pick another one.' });
    }
    return res.status(400).json({ error: 'An account with this email already exists. Try logging in!' });
  }

  try {
    const password_hash = bcrypt.hashSync(cleanPass, 10);
    const result = db.prepare(`
      INSERT INTO users (username, email, password_hash, email_opt_in)
      VALUES (?, ?, ?, ?)
    `).run(cleanUser, cleanEmail, password_hash, email_opt_in ? 1 : 0);

    req.session.userId = result.lastInsertRowid;
    req.session.username = cleanUser;

    // Migrate any guest game record to user account
    const today = getSanitizedDate(req);
    db.prepare('UPDATE user_daily_games SET user_id = ? WHERE guest_session_id = ? AND puzzle_date = ?')
      .run(result.lastInsertRowid, req.session.id, today);

    res.json({
      success: true,
      user: { id: result.lastInsertRowid, username: cleanUser, email: cleanEmail }
    });
  } catch (err) {
    console.error('Registration DB Error:', err);
    res.status(500).json({ error: 'Account registration failed. Please try again.' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { username_or_email, password } = req.body;

  const cleanCred = (username_or_email || '').trim();
  const cleanPass = (password || '').trim();

  if (!cleanCred || !cleanPass) {
    return res.status(400).json({ error: 'Username/email and password are required.' });
  }

  const user = db.prepare(`
    SELECT * FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)
  `).get(cleanCred, cleanCred.toLowerCase());

  if (!user || !bcrypt.compareSync(cleanPass, user.password_hash)) {
    return res.status(400).json({ error: 'Invalid username/email or password.' });
  }

  req.session.userId = user.id;
  req.session.username = user.username;

  res.json({
    success: true,
    user: { id: user.id, username: user.username, email: user.email }
  });
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  if (req.session.userId) {
    const user = db.prepare('SELECT id, username, email, email_opt_in FROM users WHERE id = ?').get(req.session.userId);
    if (user) {
      return res.json({ loggedIn: true, user });
    }
  }
  res.json({ loggedIn: false });
});

// Start server
app.listen(PORT, () => {
  console.log(`QuizSum server running on port ${PORT}`);
});
