const { getOrGenerateDailyPuzzle } = require('./database');
const path = require('path');

function formatMsTime(ms) {
  if (!ms || ms <= 0) return '0s';
  const totalSecs = Math.floor(ms / 1000);
  const m = Math.floor(totalSecs / 60);
  const s = totalSecs % 60;
  return m > 0 ? (m + 'm ' + (s < 10 ? '0' : '') + s + 's') : (s + 's');
}

async function sendResendNotification({ to, subject, html }) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.log('[Mail Skipped] RESEND_API_KEY missing for ' + to);
    return { success: false, reason: 'RESEND_API_KEY missing' };
  }
  const fromDomain = 'resend' + '.dev';
  const apiDomain = 'resend' + '.com';
  const fromAddress = process.env.FROM_EMAIL || ('QuizSum <onboarding@' + fromDomain + '>');
  const endpoint = 'https://api.' + apiDomain + '/emails';
  try {
    const resp = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ from: fromAddress, to: [to], subject: subject, html: html })
    });
    const data = await resp.json();
    if (!resp.ok) {
      console.error('[Resend API Error]', resp.status, JSON.stringify(data));
      return { success: false, error: data };
    }
    console.log('[Resend API Success]', to, data);
    return { success: true, data };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

function getUserRankInfo(db, userId, dateStr, mode) {
  try {
    const entry = db.prepare('SELECT solutions_count, active_time_ms FROM leaderboards WHERE puzzle_date = ? AND game_mode = ? AND user_id = ?').get(dateStr, mode, userId);
    if (!entry) return null;
    const higherRanks = db.prepare('SELECT COUNT(*) as rank FROM leaderboards WHERE puzzle_date = ? AND game_mode = ? AND (solutions_count > ? OR (solutions_count = ? AND active_time_ms < ?))').get(dateStr, mode, entry.solutions_count, entry.solutions_count, entry.active_time_ms).rank;
    return { rank: higherRanks + 1, solutions_count: entry.solutions_count, active_time_ms: entry.active_time_ms };
  } catch (err) { return null; }
}

async function sendCompletionNotification(email, username, mode, puzzleDate, rank, solutionsCount, activeTimeMs) {
  const timeFormatted = formatMsTime(activeTimeMs);
  const modeTitle = mode === 'pro' ? 'Pro Mode' : 'Speed Mode';
  const appDomain = 'quizsum.on' + 'render.com';
  const appUrl = process.env.APP_URL || ('https://' + appDomain);
  const html = '<div style="font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 20px;"><h2 style="color: #4F46E5;">QuizSum Game Complete!</h2><p>Great job, <strong>' + username + '</strong>!</p><div style="background-color: #F3F4F6; padding: 15px; border-radius: 8px;"><p>Game Mode: ' + modeTitle + '</p><p>Date: ' + puzzleDate + '</p><p>Solutions Found: ' + solutionsCount + '</p><p>Time Taken: ' + timeFormatted + '</p><p style="font-size: 18px; color: #059669;">Leaderboard Rank: #' + rank + '</p></div><p style="margin-top: 20px;"><a href="' + appUrl + '" style="background-color: #4F46E5; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Play Today\'s Challenge</a></p></div>';
  return sendResendNotification({ to: email, subject: 'QuizSum ' + modeTitle + ': Rank #' + rank + ' (' + solutionsCount + ' solutions in ' + timeFormatted + ')', html: html });
}

async function sendDailyDigestNotifications(db) {
  try {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const yesterdayDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const yesterday = yesterdayDate.toISOString().split('T')[0];

    const users = db.prepare("SELECT id, username, email FROM users WHERE email_opt_in = 1 AND email LIKE '%@%' AND email NOT LIKE '%@quizsum.local'").all();
    let sentCount = 0;
    const appDomain = 'quizsum.onrender.com';
    const appUrl = process.env.APP_URL || ('https://' + appDomain);

    
    // Fetch yesterday's puzzle and solution data for recap block
    const ySpeedPuzzle = getOrGenerateDailyPuzzle(yesterday, 'speed');
    const yProPuzzle = getOrGenerateDailyPuzzle(yesterday, 'pro');

    const ySpeedSolutions = ySpeedPuzzle ? JSON.parse(ySpeedPuzzle.solutions_json || '[]') : [];
    const yProSolutions = yProPuzzle ? JSON.parse(yProPuzzle.solutions_json || '[]') : [];

    let solutionsRecapHtml = '<div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; padding: 15px; border-radius: 8px; margin-bottom: 15px;">';
    solutionsRecapHtml += '<h4 style="margin: 0 0 10px 0; color: #1E293B; font-size: 15px;">📜 Yesterday\'s Solution Recap (' + yesterday + '):</h4>';

    if (ySpeedPuzzle) {
      solutionsRecapHtml += '<p style="margin: 5px 0; font-size: 13px; color: #334155;">⚡ <strong>Speed Mode (Target ' + ySpeedPuzzle.target + '):</strong><br>';
      solutionsRecapHtml += ySpeedSolutions.map(s => '&nbsp;&nbsp;• <code style="background: #E2E8F0; padding: 2px 6px; border-radius: 4px; font-family: monospace;">' + s + '</code>').join('<br>');
      solutionsRecapHtml += '</p>';
    }

    if (yProPuzzle) {
      const proCountFormatted = yProSolutions.length >= 30 ? '30+' : yProSolutions.length;
      solutionsRecapHtml += '<p style="margin: 10px 0 5px 0; font-size: 13px; color: #334155;">🧠 <strong>Pro Mode (Target ' + yProPuzzle.target + '):</strong> ' + proCountFormatted + ' Total Unique Paths<br>';
      if (yProSolutions.length > 0) {
        const shortest = yProSolutions.reduce((a, b) => a.length <= b.length ? a : b, yProSolutions[0]);
        const longest = yProSolutions.reduce((a, b) => a.length >= b.length ? a : b, yProSolutions[0]);
        solutionsRecapHtml += '&nbsp;&nbsp;• <em>Shortest Path:</em> <code style="background: #E2E8F0; padding: 2px 6px; border-radius: 4px; font-family: monospace;">' + shortest + '</code><br>';
        if (longest !== shortest) {
          solutionsRecapHtml += '&nbsp;&nbsp;• <em>Full Grid Mastermind:</em> <code style="background: #E2E8F0; padding: 2px 6px; border-radius: 4px; font-family: monospace;">' + longest + '</code><br>';
        }
      }
      solutionsRecapHtml += '</p>';
    }

    solutionsRecapHtml += '<p style="margin-top: 12px; margin-bottom: 0;"><a href="' + appUrl + '?view=yesterday" style="background-color: #4F46E5; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; font-size: 13px; font-weight: bold; display: inline-block;">View All Yesterday\'s Solutions 🔗</a></p>';
    solutionsRecapHtml += '</div>';

    for (const user of users) {
      const ySpeedStats = getUserRankInfo(db, user.id, yesterday, 'speed');
      const yProStats = getUserRankInfo(db, user.id, yesterday, 'pro');

      const tSpeedStats = getUserRankInfo(db, user.id, today, 'speed');
      const tProStats = getUserRankInfo(db, user.id, today, 'pro');

      let statsHtml = '';

      if (ySpeedStats || yProStats) {
        statsHtml += '<div style="background-color: #F3F4F6; padding: 15px; border-radius: 8px; margin-bottom: 15px;">';
        statsHtml += '<h5 style="margin: 0 0 10px 0; color: #374151;">Yesterday\'s Standings (' + yesterday + '):</h5>';
        if (ySpeedStats) {
          statsHtml += '<p style="margin: 5px 0;">⚡ <strong>Speed Mode:</strong> Rank #' + ySpeedStats.rank + ' (' + ySpeedStats.solutions_count + '/3 found in ' + formatMsTime(ySpeedStats.active_time_ms) + ')</p>';
        } else {
          statsHtml += '<p style="margin: 5px 0; color: #6B7280;">⚡ <strong>Speed Mode:</strong> Not played</p>';
        }
        if (yProStats) {
          statsHtml += '<p style="margin: 5px 0;">🏆 <strong>Pro Mode:</strong> Rank #' + yProStats.rank + ' (' + yProStats.solutions_count + ' solutions in ' + formatMsTime(yProStats.active_time_ms) + ')</p>';
        } else {
          statsHtml += '<p style="margin: 5px 0; color: #6B7280;">🏆 <strong>Pro Mode:</strong> Not played</p>';
        }
        statsHtml += '</div>';
      }

      statsHtml += solutionsRecapHtml;

      if (tSpeedStats || tProStats) {
        statsHtml += '<div style="background-color: #ECFDF5; padding: 15px; border-radius: 8px; margin-bottom: 15px;">';
        statsHtml += '<h5 style="margin: 0 0 10px 0; color: #065F46;">Today\'s Standings (' + today + '):</h5>';
        if (tSpeedStats) {
          statsHtml += '<p style="margin: 5px 0;">⚡ <strong>Speed Mode:</strong> Rank #' + tSpeedStats.rank + ' (' + tSpeedStats.solutions_count + '/3 found in ' + formatMsTime(tSpeedStats.active_time_ms) + ')</p>';
        }
        if (tProStats) {
          statsHtml += '<p style="margin: 5px 0;">🏆 <strong>Pro Mode:</strong> Rank #' + tProStats.rank + ' (' + tProStats.solutions_count + ' solutions in ' + formatMsTime(tProStats.active_time_ms) + ')</p>';
        }
        statsHtml += '</div>';
      } else if (!ySpeedStats && !yProStats) {
        statsHtml += '<p style="color: #4F46E5; font-weight: bold;">Today\'s new puzzles are ready for you!</p>';
      }

      const html = '<div style="font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 20px; border: 1px solid #E5E7EB; border-radius: 10px;">' +
        '<h3 style="color: #4F46E5; margin-top: 0;">Today\'s QuizSum Puzzles Are Live!</h3>' +
        '<p>Hi <strong>' + user.username + '</strong>,</p>' +
        '<p>Here is your daily QuizSum leaderboard recap:</p>' +
        statsHtml +
        '<p style="margin-top: 25px;"><a href="' + appUrl + '" style="background-color: #10B981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">Play Today\'s Challenge</a></p>' +
        '</div>';

      const res = await sendResendNotification({
        to: user.email,
        subject: 'QuizSum Leaderboards & Today\'s Challenge (' + today + ')',
        html: html
      });

      if (res.success) sentCount++;
    }

    return { total: users.length, sent: sentCount };
  } catch (err) {
    console.error('[Digest Error]', err);
    return { error: err.message };
  }
}

module.exports = { formatMsTime, sendResendNotification, getUserRankInfo, sendCompletionNotification, sendDailyDigestNotifications };
