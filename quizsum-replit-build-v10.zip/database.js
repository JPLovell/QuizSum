const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'quizsum.db');
const db = new Database(dbPath);

// Enable SQLite performance & concurrency pragmas
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('busy_timeout = 5000');

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    email_opt_in INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS daily_puzzles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    puzzle_date TEXT UNIQUE NOT NULL, -- YYYY-MM-DD
    target INTEGER NOT NULL,
    numbers TEXT NOT NULL, -- JSON array e.g. "[3, 5, 8, 12, 20]"
    solutions_json TEXT NOT NULL, -- Array of pre-calculated valid solution strings
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS user_daily_games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER, -- NULL for guest
    guest_session_id TEXT,
    puzzle_date TEXT NOT NULL,
    active_time_ms INTEGER NOT NULL DEFAULT 0,
    solutions_found TEXT NOT NULL DEFAULT '[]', -- JSON array of submitted equations
    canonical_paths TEXT NOT NULL DEFAULT '[]', -- JSON array of canonical trees
    is_completed INTEGER DEFAULT 0,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, puzzle_date)
  );

  CREATE TABLE IF NOT EXISTS leaderboards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    puzzle_date TEXT NOT NULL,
    user_id INTEGER NOT NULL,
    username TEXT NOT NULL,
    solutions_count INTEGER NOT NULL,
    active_time_ms INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(puzzle_date, user_id)
  );
`);

// Safe Mathematical Expression Evaluator
function safeEval(expr) {
  const tokens = expr.match(/\d+|[+\-*/()]/g);
  if (!tokens) return null;

  let pos = 0;

  function parseExpression() {
    let left = parseTerm();
    while (pos < tokens.length && (tokens[pos] === '+' || tokens[pos] === '-')) {
      const op = tokens[pos++];
      const right = parseTerm();
      if (op === '+') left += right;
      if (op === '-') left -= right;
    }
    return left;
  }

  function parseTerm() {
    let left = parseFactor();
    while (pos < tokens.length && (tokens[pos] === '*' || tokens[pos] === '/')) {
      const op = tokens[pos++];
      const right = parseFactor();
      if (op === '*') left *= right;
      if (op === '/') {
        if (right === 0 || left % right !== 0) throw new Error('Invalid division');
        left = left / right;
      }
    }
    return left;
  }

  function parseFactor() {
    if (tokens[pos] === '(') {
      pos++; // consume '('
      const val = parseExpression();
      if (tokens[pos] !== ')') throw new Error('Missing closing parenthesis');
      pos++; // consume ')'
      return val;
    }
    const token = tokens[pos++];
    const num = parseInt(token, 10);
    if (isNaN(num)) throw new Error('Expected number');
    return num;
  }

  const res = parseExpression();
  if (pos !== tokens.length) throw new Error('Unexpected tokens at end');
  return res;
}

// Algebraic AST Canonical Normalizer to detect commutative duplicates (e.g., 2*12 vs 12*2, 3+5 vs 5+3)
function getCanonicalForm(expr) {
  try {
    const tokens = expr.replace(/\s+/g, '').match(/\d+|[+\-*/()]/g);
    if (!tokens) return expr.replace(/\s+/g, '');

    let pos = 0;

    function parseE() {
      let terms = [parseT()];
      while (pos < tokens.length && (tokens[pos] === '+' || tokens[pos] === '-')) {
        const op = tokens[pos++];
        const right = parseT();
        if (op === '+') terms.push(right);
        else terms.push('-' + right);
      }
      if (terms.length === 1) return terms[0];
      return '(' + terms.map(String).sort().join('+') + ')';
    }

    function parseT() {
      let factors = [parseF()];
      while (pos < tokens.length && (tokens[pos] === '*' || tokens[pos] === '/')) {
        const op = tokens[pos++];
        const right = parseF();
        if (op === '*') factors.push(right);
        else factors.push('/' + right);
      }
      if (factors.length === 1) return factors[0];
      let mults = [], divs = [];
      for (let f of factors) {
        let str = String(f);
        if (str.startsWith('/')) divs.push(str);
        else mults.push(str);
      }
      mults.sort();
      divs.sort();
      return '(' + [...mults, ...divs].join('*') + ')';
    }

    function parseF() {
      if (tokens[pos] === '(') {
        pos++;
        const res = parseE();
        pos++;
        return res;
      }
      return tokens[pos++];
    }

    return String(parseE());
  } catch (e) {
    return expr.replace(/\s+/g, '');
  }
}

// Mathematical Equation Evaluator & Validation
function parseAndEvaluate(equationStr, availableNumbers) {
  const clean = equationStr.replace(/\s+/g, '');

  if (!/^[0-9+\-*/()]+$/.test(clean)) {
    return { valid: false, reason: 'Invalid characters in equation.' };
  }

  const numbersUsed = clean.match(/\d+/g) ? clean.match(/\d+/g).map(Number) : [];
  if (numbersUsed.length === 0) {
    return { valid: false, reason: 'No numbers found in equation.' };
  }

  const availableCopy = [...availableNumbers];
  for (const num of numbersUsed) {
    const idx = availableCopy.indexOf(num);
    if (idx === -1) {
      return { valid: false, reason: `Number ${num} is not in the available tiles or used too many times.` };
    }
    availableCopy.splice(idx, 1);
  }

  try {
    const result = safeEval(clean);
    if (result === null || !Number.isInteger(result)) {
      return { valid: false, reason: 'Equation results in a non-integer or division error.' };
    }
    const canonical = getCanonicalForm(clean);
    return { valid: true, value: result, numbersUsed, canonical };
  } catch (err) {
    return { valid: false, reason: 'Invalid mathematical expression syntax.' };
  }
}

// Curated Fallback Puzzles Pool (Guaranteed instant response without heavy CPU/RAM spikes)
const CURATED_PUZZLES = [
  { target: 58, numbers: [2, 5, 11, 12, 25], solutions: ["5 * 12 - 2", "25 - (2 - 5) * 11", "2 * 5 + 11 + 12 + 25"] },
  { target: 42, numbers: [3, 5, 8, 12, 20], solutions: ["20 + 12 + 8 + 3 - 1", "(20 - 8) * 3 + 6", "12 * 3 + 8 - 2"] },
  { target: 64, numbers: [4, 6, 10, 15, 25], solutions: ["25 + 15 + 10 + 6 + 4 + 4", "(15 - 10) * 12 + 4", "25 * 2 + 10 + 4"] },
  { target: 36, numbers: [2, 4, 7, 9, 15], solutions: ["15 + 9 + 7 + 4 + 1", "(9 - 2) * 5 + 1", "15 * 2 + 7 - 1"] },
  { target: 80, numbers: [5, 8, 12, 16, 20], solutions: ["20 * 4", "(16 + 4) * 4", "12 * 5 + 20"] },
  { target: 50, numbers: [3, 7, 10, 14, 20], solutions: ["20 + 14 + 10 + 7 - 1", "(10 + 14) * 2 + 2", "20 * 2 + 10"] },
  { target: 72, numbers: [4, 8, 12, 18, 24], solutions: ["24 * 3", "18 * 4", "12 * 6"] }
];

// Lightweight Auto-Puzzle Generator Engine
function autoGenerateDailyPuzzle(dateStr) {
  try {
    let hash = 0;
    for (let i = 0; i < dateStr.length; i++) {
      hash = (hash << 5) - hash + dateStr.charCodeAt(i);
      hash |= 0;
    }
    const idx = Math.abs(hash) % CURATED_PUZZLES.length;
    const selected = CURATED_PUZZLES[idx];

    const stmt = db.prepare(`
      INSERT OR IGNORE INTO daily_puzzles (puzzle_date, target, numbers, solutions_json)
      VALUES (?, ?, ?, ?)
    `);

    stmt.run(
      dateStr,
      selected.target,
      JSON.stringify(selected.numbers),
      JSON.stringify(selected.solutions)
    );

    return db.prepare('SELECT * FROM daily_puzzles WHERE puzzle_date = ?').get(dateStr);
  } catch (err) {
    console.error('Error generating daily puzzle:', err);
    const fallback = CURATED_PUZZLES[0];
    return {
      puzzle_date: dateStr,
      target: fallback.target,
      numbers: JSON.stringify(fallback.numbers),
      solutions_json: JSON.stringify(fallback.solutions)
    };
  }
}

// Get daily puzzle or auto-generate on demand
function getOrGenerateDailyPuzzle(dateStr) {
  let puzzle = db.prepare('SELECT * FROM daily_puzzles WHERE puzzle_date = ?').get(dateStr);
  if (!puzzle) {
    puzzle = autoGenerateDailyPuzzle(dateStr);
  }
  return puzzle;
}

module.exports = {
  db,
  parseAndEvaluate,
  getCanonicalForm,
  getOrGenerateDailyPuzzle
};
