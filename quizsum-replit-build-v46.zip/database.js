const Database = require('better-sqlite3');
const path = require('path');

const dbPath = process.env.DB_PATH || path.join(__dirname, 'quizsum.db');
const db = new Database(dbPath);

// Enable SQLite performance & concurrency pragmas
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('busy_timeout = 5000');

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    auth_token TEXT,
    email_opt_in INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS daily_puzzles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    puzzle_date TEXT NOT NULL, -- YYYY-MM-DD
    game_mode TEXT NOT NULL DEFAULT 'speed', -- 'speed' or 'pro'
    target INTEGER NOT NULL,
    numbers TEXT NOT NULL, -- JSON array e.g. "[3, 5, 8, 12, 20]"
    solutions_json TEXT NOT NULL, -- Array of pre-calculated valid solution strings
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(puzzle_date, game_mode)
  );

  CREATE TABLE IF NOT EXISTS user_daily_games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER, -- NULL for guest
    guest_session_id TEXT,
    puzzle_date TEXT NOT NULL,
    game_mode TEXT NOT NULL DEFAULT 'speed',
    active_time_ms INTEGER NOT NULL DEFAULT 0,
    solutions_found TEXT NOT NULL DEFAULT '[]', -- JSON array of submitted equations
    canonical_paths TEXT NOT NULL DEFAULT '[]', -- JSON array of canonical trees
    is_completed INTEGER DEFAULT 0,
    started_at DATETIME,
    is_flagged INTEGER DEFAULT 0,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS leaderboards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    puzzle_date TEXT NOT NULL,
    game_mode TEXT NOT NULL DEFAULT 'speed',
    user_id INTEGER NOT NULL,
    username TEXT NOT NULL,
    solutions_count INTEGER NOT NULL,
    active_time_ms INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(puzzle_date, game_mode, user_id)
  );
  CREATE TABLE IF NOT EXISTS groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    join_code TEXT UNIQUE NOT NULL,
    owner_id INTEGER NOT NULL,
    is_public INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS group_members (
    group_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (group_id, user_id)
  );

`);

// Safe column migrations for existing databases
try { db.exec("ALTER TABLE users ADD COLUMN auth_token TEXT"); } catch(e) {}
try { db.exec("ALTER TABLE daily_puzzles ADD COLUMN game_mode TEXT DEFAULT 'speed'"); } catch(e) {}
try { db.exec("ALTER TABLE user_daily_games ADD COLUMN game_mode TEXT DEFAULT 'speed'"); } catch(e) {}
try { db.exec("ALTER TABLE leaderboards ADD COLUMN game_mode TEXT DEFAULT 'speed'"); } catch(e) {}
try { db.exec("ALTER TABLE users ADD COLUMN show_on_global_leaderboard INTEGER DEFAULT 1"); } catch(e) {}
try { db.exec("ALTER TABLE users ADD COLUMN show_on_global_leaderboard INTEGER DEFAULT 1"); } catch(e) {}
try { db.exec("ALTER TABLE groups ADD COLUMN is_public INTEGER DEFAULT 0"); } catch(e) {}
try { db.exec("ALTER TABLE user_daily_games ADD COLUMN started_at DATETIME"); } catch(e) {}
try { db.exec("ALTER TABLE user_daily_games ADD COLUMN is_flagged INTEGER DEFAULT 0"); } catch(e) {}
try { db.exec("ALTER TABLE leaderboards ADD COLUMN is_flagged INTEGER DEFAULT 0"); } catch(e) {}

// Sequential Left-To-Right Evaluator for Speed Mode (simple arithmetic without BODMAS operator precedence)
function safeEvalLeftToRight(expr) {
  const clean = expr.replace(/\s+/g, "");
  if (/[()]/.test(clean)) throw new Error("Parentheses not allowed in Speed Mode.");

  const tokens = clean.match(/\d+|[+\-*/]/g);
  if (!tokens || tokens.length % 2 === 0) throw new Error("Invalid equation syntax.");

  let val = parseInt(tokens[0], 10);
  if (isNaN(val)) throw new Error("Expected number.");

  for (let i = 1; i < tokens.length; i += 2) {
    const op = tokens[i];
    const num = parseInt(tokens[i + 1], 10);
    if (!/^[+\-*/]$/.test(op) || isNaN(num)) {
      throw new Error("Invalid equation syntax.");
    }
    if (op === "+") val += num;
    else if (op === "-") val -= num;
    else if (op === "*") val *= num;
    else if (op === "/") {
      if (num === 0 || val % num !== 0) {
        throw new Error("Invalid division or non-integer result.");
      }
      val = val / num;
    }
  }
  return val;
}

// Safe Mathematical Expression Evaluator
function safeEval(expr) {
  const tokens = expr.match(/\d+|[+\-*/()]/g);
  if (!tokens) return null;

  let pos = 0;

  function parseExpression() {
    let left = parseTerm();
    while (pos < tokens.length && (tokens[pos] === '+' || tokens[pos] === '-')) {
      const op = tokens[pos++];
      const right = parseTerm();
      if (op === '+') left += right;
      if (op === '-') left -= right;
    }
    return left;
  }

  function parseTerm() {
    let left = parseFactor();
    while (pos < tokens.length && (tokens[pos] === '*' || tokens[pos] === '/')) {
      const op = tokens[pos++];
      const right = parseFactor();
      if (op === '*') left *= right;
      if (op === '/') {
        if (right === 0 || left % right !== 0) throw new Error('Invalid division');
        left = left / right;
      }
    }
    return left;
  }

  function parseFactor() {
    if (tokens[pos] === '(') {
      pos++; // consume '('
      const val = parseExpression();
      if (tokens[pos] !== ')') throw new Error('Missing closing parenthesis');
      pos++; // consume ')'
      return val;
    }
    const token = tokens[pos++];
    const num = parseInt(token, 10);
    if (isNaN(num)) throw new Error('Expected number');
    return num;
  }

  const res = parseExpression();
  if (pos !== tokens.length) throw new Error('Unexpected tokens at end');
  return res;
}

// Algebraic AST Canonical Normalizer to detect commutative duplicates
function getCanonicalForm(expr) {
  try {
    const tokens = expr.replace(/\s+/g, '').match(/\d+|[+\-*/()]/g);
    if (!tokens) return expr.replace(/\s+/g, '');

    let pos = 0;

    function parseE() {
      let terms = [parseT()];
      while (pos < tokens.length && (tokens[pos] === '+' || tokens[pos] === '-')) {
        const op = tokens[pos++];
        const right = parseT();
        if (op === '+') terms.push(right);
        else terms.push('-' + right);
      }
      if (terms.length === 1) return terms[0];
      return '(' + terms.map(String).sort().join('+') + ')';
    }

    function parseT() {
      let factors = [parseF()];
      while (pos < tokens.length && (tokens[pos] === '*' || tokens[pos] === '/')) {
        const op = tokens[pos++];
        const right = parseF();
        if (op === '*') factors.push(right);
        else factors.push('/' + right);
      }
      if (factors.length === 1) return factors[0];
      let mults = [], divs = [];
      for (let f of factors) {
        let str = String(f);
        if (str.startsWith('/')) divs.push(str);
        else mults.push(str);
      }
      mults.sort();
      divs.sort();
      return '(' + [...mults, ...divs].join('*') + ')';
    }

    function parseF() {
      if (tokens[pos] === '(') {
        pos++;
        const res = parseE();
        pos++;
        return res;
      }
      return tokens[pos++];
    }

    return String(parseE());
  } catch (e) {
    return expr.replace(/\s+/g, '');
  }
}


function getCanonicalFormSpeed(expr) {
  const clean = expr.replace(/\s+/g, '');
  const tokens = clean.match(/\d+|[+\-*/]/g);
  if (!tokens || tokens.length % 2 === 0) return clean;

  const numbers = [];
  const operators = [];
  for (let i = 0; i < tokens.length; i++) {
    if (i % 2 === 0) {
      numbers.push(parseInt(tokens[i], 10));
    } else {
      operators.push(tokens[i]);
    }
  }

  if (operators.length === 0) return String(numbers[0]);

  const firstOp = operators[0];
  let j = 0;
  while (j < operators.length && operators[j] === firstOp) {
    j++;
  }

  let resultStr = "";
  if (firstOp === '+' || firstOp === '*') {
    const blockNums = numbers.slice(0, j + 1).sort((a, b) => a - b);
    resultStr = blockNums.join(firstOp);
  } else {
    const firstNum = numbers[0];
    const blockNums = numbers.slice(1, j + 1).sort((a, b) => a - b);
    resultStr = firstNum + firstOp + blockNums.join(firstOp);
  }

  let k = j;
  while (k < operators.length) {
    const op = operators[k];
    let m = k;
    while (m < operators.length && operators[m] === op) {
      m++;
    }
    const blockNums = numbers.slice(k + 1, m + 1).sort((a, b) => a - b);
    resultStr += op + blockNums.join(op);
    k = m;
  }

  return resultStr;
}

// Mathematical Equation Evaluator & Validation
function parseAndEvaluate(equationStr, availableNumbers, mode = 'speed') {
  const cleanCheck = equationStr.replace(/\s+/g, '');
  if (mode === 'speed' && /[()]/.test(cleanCheck)) {
    return { valid: false, reason: 'Speed Mode equations do not use parentheses ().' };
  }
  const clean = equationStr.replace(/\s+/g, '');

  if (!/^[0-9+\-*/()]+$/.test(clean)) {
    return { valid: false, reason: 'Invalid characters in equation.' };
  }

  const numbersUsed = clean.match(/\d+/g) ? clean.match(/\d+/g).map(Number) : [];
  if (numbersUsed.length === 0) {
    return { valid: false, reason: 'No numbers found in equation.' };
  }

  const availableCopy = [...availableNumbers];
  for (const num of numbersUsed) {
    const idx = availableCopy.indexOf(num);
    if (idx === -1) {
      return { valid: false, reason: `Number ${num} is not in the available tiles or used too many times.` };
    }
    availableCopy.splice(idx, 1);
  }

  try {
    const result = (mode === 'speed') ? safeEvalLeftToRight(clean) : safeEval(clean);
    if (result === null || !Number.isInteger(result)) {
      return { valid: false, reason: 'Equation results in a non-integer or division error.' };
    }
    const canonical = (mode === 'speed') ? getCanonicalFormSpeed(clean) : getCanonicalForm(clean);
    return { valid: true, value: result, numbersUsed, canonical };
  } catch (err) {
    return { valid: false, reason: err.message || 'Invalid mathematical expression syntax.' };
  }
}

// Curated Speed Puzzles Pool
const CURATED_SPEED_PUZZLES = [
  {
    "target": 18,
    "numbers": [
      2,
      3,
      4,
      6,
      10
    ],
    "solutions": [
      "3 * 6",
      "3 + 6 * 2",
      "3 * 4 + 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 20,
    "numbers": [
      2,
      4,
      5,
      6,
      10
    ],
    "solutions": [
      "4 * 5",
      "2 * 10",
      "4 - 2 * 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 22,
    "numbers": [
      2,
      3,
      5,
      10,
      11
    ],
    "solutions": [
      "2 * 11",
      "11 * 10 / 5",
      "5 - 3 * 11"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 24,
    "numbers": [
      3,
      4,
      6,
      8,
      9
    ],
    "solutions": [
      "4 * 6",
      "3 * 8",
      "6 - 3 * 8"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 25,
    "numbers": [
      2,
      5,
      5,
      10,
      15
    ],
    "solutions": [
      "5 * 5",
      "10 + 15",
      "5 + 5 + 15"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 26,
    "numbers": [
      2,
      4,
      6,
      10,
      13
    ],
    "solutions": [
      "2 * 13",
      "2 * 10 + 6",
      "13 * 4 / 2"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 28,
    "numbers": [
      2,
      4,
      7,
      8,
      12
    ],
    "solutions": [
      "4 * 7",
      "7 * 8 / 2",
      "2 * 8 + 12"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 30,
    "numbers": [
      3,
      5,
      6,
      10,
      15
    ],
    "solutions": [
      "5 * 6",
      "3 * 10",
      "5 - 3 * 15"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 32,
    "numbers": [
      2,
      4,
      8,
      10,
      12
    ],
    "solutions": [
      "4 * 8",
      "4 * 10 - 8",
      "4 + 12 * 2"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 33,
    "numbers": [
      2,
      3,
      5,
      10,
      11
    ],
    "solutions": [
      "3 * 11",
      "5 - 2 * 11",
      "3 + 11 * 2 + 5"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 35,
    "numbers": [
      2,
      5,
      7,
      10,
      15
    ],
    "solutions": [
      "5 * 7",
      "5 * 10 - 15",
      "7 * 10 / 2"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 36,
    "numbers": [
      3,
      4,
      6,
      9,
      12
    ],
    "solutions": [
      "4 * 9",
      "3 * 12",
      "4 * 6 + 12"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 38,
    "numbers": [
      2,
      3,
      5,
      10,
      19
    ],
    "solutions": [
      "2 * 19",
      "19 * 10 / 5",
      "5 - 3 * 19"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 40,
    "numbers": [
      2,
      4,
      5,
      8,
      10
    ],
    "solutions": [
      "4 * 10",
      "5 * 8",
      "4 * 2 * 5"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 42,
    "numbers": [
      3,
      6,
      7,
      8,
      12
    ],
    "solutions": [
      "6 * 7",
      "6 + 8 * 3",
      "3 * 12 + 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 44,
    "numbers": [
      2,
      4,
      6,
      10,
      11
    ],
    "solutions": [
      "4 * 11",
      "6 - 2 * 11",
      "10 - 6 * 11"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 45,
    "numbers": [
      3,
      5,
      9,
      10,
      15
    ],
    "solutions": [
      "5 * 9",
      "3 * 15",
      "5 + 10 * 3"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 48,
    "numbers": [
      2,
      4,
      6,
      8,
      12
    ],
    "solutions": [
      "6 * 8",
      "4 * 12",
      "6 * 2 * 4"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 50,
    "numbers": [
      2,
      5,
      10,
      15,
      25
    ],
    "solutions": [
      "5 * 10",
      "2 * 25",
      "5 * 15 - 25"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 52,
    "numbers": [
      2,
      4,
      5,
      10,
      13
    ],
    "solutions": [
      "4 * 13",
      "5 * 10 + 2",
      "13 * 2 * 10 / 5"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 54,
    "numbers": [
      3,
      6,
      9,
      12,
      18
    ],
    "solutions": [
      "6 * 9",
      "3 * 18",
      "6 - 3 * 18"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 55,
    "numbers": [
      2,
      5,
      10,
      11,
      15
    ],
    "solutions": [
      "5 * 11",
      "11 * 10 / 2",
      "10 - 5 * 11"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 56,
    "numbers": [
      2,
      7,
      8,
      10,
      14
    ],
    "solutions": [
      "7 * 8",
      "7 * 10 - 14",
      "8 / 2 * 14"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 60,
    "numbers": [
      5,
      6,
      10,
      15,
      20
    ],
    "solutions": [
      "6 * 10",
      "10 - 6 * 15",
      "15 - 5 * 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 63,
    "numbers": [
      3,
      7,
      9,
      12,
      21
    ],
    "solutions": [
      "7 * 9",
      "3 * 21",
      "7 * 12 - 21"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 64,
    "numbers": [
      2,
      4,
      8,
      8,
      16
    ],
    "solutions": [
      "8 * 8",
      "4 * 16",
      "8 + 8 * 4"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 65,
    "numbers": [
      2,
      5,
      10,
      13,
      15
    ],
    "solutions": [
      "5 * 13",
      "5 * 10 + 15",
      "5 * 15 - 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 70,
    "numbers": [
      5,
      7,
      10,
      12,
      20
    ],
    "solutions": [
      "7 * 10",
      "10 * 5 + 20",
      "5 * 12 + 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 72,
    "numbers": [
      3,
      6,
      8,
      9,
      12
    ],
    "solutions": [
      "8 * 9",
      "6 * 12",
      "9 + 3 * 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 75,
    "numbers": [
      5,
      10,
      15,
      20,
      25
    ],
    "solutions": [
      "5 * 15",
      "5 * 10 + 25",
      "5 * 20 - 25"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 78,
    "numbers": [
      2,
      5,
      6,
      10,
      13
    ],
    "solutions": [
      "6 * 13",
      "6 * 10 + 13 + 5",
      "6 + 10 * 5 - 2"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 80,
    "numbers": [
      4,
      5,
      10,
      20,
      25
    ],
    "solutions": [
      "4 * 20",
      "4 * 25 - 20",
      "20 - 4 * 5"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 84,
    "numbers": [
      2,
      6,
      7,
      12,
      14
    ],
    "solutions": [
      "7 * 12",
      "6 * 14",
      "7 * 2 * 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 85,
    "numbers": [
      2,
      5,
      10,
      17,
      20
    ],
    "solutions": [
      "5 * 17",
      "17 * 10 / 2",
      "10 - 5 * 17"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 88,
    "numbers": [
      2,
      4,
      8,
      10,
      11
    ],
    "solutions": [
      "8 * 11",
      "11 * 2 * 4",
      "10 - 2 * 11"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 90,
    "numbers": [
      5,
      6,
      10,
      15,
      20
    ],
    "solutions": [
      "6 * 15",
      "15 - 6 * 10",
      "5 + 10 * 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 95,
    "numbers": [
      2,
      5,
      10,
      19,
      25
    ],
    "solutions": [
      "5 * 19",
      "19 * 10 / 2",
      "19 * 25 / 5"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 96,
    "numbers": [
      2,
      6,
      8,
      12,
      16
    ],
    "solutions": [
      "8 * 12",
      "6 * 16",
      "8 * 2 * 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 100,
    "numbers": [
      4,
      5,
      10,
      20,
      25
    ],
    "solutions": [
      "4 * 25",
      "5 * 20",
      "25 / 5 * 20"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 105,
    "numbers": [
      3,
      7,
      10,
      15,
      20
    ],
    "solutions": [
      "7 * 15",
      "15 + 20 * 3",
      "10 - 3 * 15"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 108,
    "numbers": [
      3,
      6,
      9,
      12,
      18
    ],
    "solutions": [
      "9 * 12",
      "6 * 18",
      "9 - 3 * 18"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 110,
    "numbers": [
      2,
      5,
      10,
      11,
      20
    ],
    "solutions": [
      "10 * 11",
      "11 * 2 * 5",
      "11 * 20 / 2"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 112,
    "numbers": [
      2,
      6,
      8,
      10,
      14
    ],
    "solutions": [
      "8 * 14",
      "2 + 6 * 14",
      "10 - 2 * 14"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 115,
    "numbers": [
      2,
      5,
      10,
      20,
      23
    ],
    "solutions": [
      "5 * 23",
      "23 * 10 / 2",
      "10 - 5 * 23"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 120,
    "numbers": [
      5,
      6,
      10,
      20,
      25
    ],
    "solutions": [
      "6 * 20",
      "25 - 5 * 6",
      "6 + 20 * 5 - 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 125,
    "numbers": [
      5,
      10,
      20,
      25,
      50
    ],
    "solutions": [
      "5 * 25",
      "5 * 20 + 25",
      "25 * 50 / 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 128,
    "numbers": [
      2,
      4,
      8,
      10,
      16
    ],
    "solutions": [
      "8 * 16",
      "16 * 2 * 4",
      "10 - 2 * 16"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 130,
    "numbers": [
      2,
      5,
      10,
      13,
      25
    ],
    "solutions": [
      "10 * 13",
      "13 * 2 * 5",
      "10 / 2 + 5 * 13"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 135,
    "numbers": [
      3,
      9,
      10,
      15,
      20
    ],
    "solutions": [
      "9 * 15",
      "9 + 3 * 10 + 15",
      "9 - 3 * 20 + 15"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 140,
    "numbers": [
      5,
      7,
      10,
      20,
      25
    ],
    "solutions": [
      "7 * 20",
      "25 - 5 * 7",
      "7 + 5 * 10 + 20"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 144,
    "numbers": [
      2,
      6,
      12,
      12,
      24
    ],
    "solutions": [
      "12 * 12",
      "6 * 24",
      "12 + 12 * 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 145,
    "numbers": [
      2,
      5,
      10,
      20,
      29
    ],
    "solutions": [
      "5 * 29",
      "29 * 10 / 2",
      "10 - 5 * 29"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 150,
    "numbers": [
      6,
      10,
      20,
      25,
      50
    ],
    "solutions": [
      "6 * 25",
      "10 * 20 - 50",
      "50 - 25 * 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 160,
    "numbers": [
      4,
      8,
      10,
      20,
      25
    ],
    "solutions": [
      "8 * 20",
      "20 - 4 * 10",
      "20 - 8 + 4 * 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 165,
    "numbers": [
      2,
      5,
      11,
      15,
      20
    ],
    "solutions": [
      "11 * 15",
      "20 - 5 * 11",
      "11 - 2 * 20 - 15"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 168,
    "numbers": [
      2,
      6,
      12,
      14,
      20
    ],
    "solutions": [
      "12 * 14",
      "14 * 2 * 6",
      "20 - 6 * 12"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 175,
    "numbers": [
      5,
      7,
      10,
      25,
      50
    ],
    "solutions": [
      "7 * 25",
      "25 * 5 + 50",
      "25 + 10 * 5"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 180,
    "numbers": [
      5,
      9,
      10,
      20,
      25
    ],
    "solutions": [
      "9 * 20",
      "25 - 5 * 9",
      "9 + 25 * 5 + 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 185,
    "numbers": [
      2,
      5,
      10,
      20,
      37
    ],
    "solutions": [
      "5 * 37",
      "37 * 10 / 2",
      "10 - 5 * 37"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 192,
    "numbers": [
      2,
      8,
      12,
      16,
      20
    ],
    "solutions": [
      "12 * 16",
      "12 * 2 * 8",
      "20 - 8 * 16"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 200,
    "numbers": [
      8,
      10,
      20,
      25,
      50
    ],
    "solutions": [
      "8 * 25",
      "10 * 20",
      "25 * 10 - 50"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 210,
    "numbers": [
      3,
      7,
      10,
      21,
      25
    ],
    "solutions": [
      "10 * 21",
      "10 * 3 * 7",
      "3 + 7 * 21"
    ],
    "total_valid_canonical": 10
  },
  {
    "target": 216,
    "numbers": [
      2,
      6,
      12,
      18,
      20
    ],
    "solutions": [
      "12 * 18",
      "18 * 2 * 6",
      "20 - 2 * 12"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 220,
    "numbers": [
      2,
      5,
      10,
      22,
      25
    ],
    "solutions": [
      "10 * 22",
      "22 * 2 * 5",
      "10 / 2 + 5 * 22"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 225,
    "numbers": [
      5,
      9,
      15,
      25,
      50
    ],
    "solutions": [
      "9 * 25",
      "5 * 50 - 25",
      "50 - 25 * 9"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 240,
    "numbers": [
      6,
      10,
      12,
      20,
      25
    ],
    "solutions": [
      "12 * 20",
      "12 / 6 + 10 * 20",
      "12 - 10 * 20 * 6"
    ],
    "total_valid_canonical": 8
  },
  {
    "target": 250,
    "numbers": [
      5,
      10,
      20,
      25,
      50
    ],
    "solutions": [
      "10 * 25",
      "5 * 50",
      "10 - 5 * 50"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 256,
    "numbers": [
      2,
      8,
      16,
      16,
      20
    ],
    "solutions": [
      "16 * 16",
      "16 + 16 * 8",
      "16 * 2 * 8"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 270,
    "numbers": [
      3,
      9,
      10,
      25,
      27
    ],
    "solutions": [
      "10 * 27",
      "10 * 3 * 9",
      "27 + 3 * 9"
    ],
    "total_valid_canonical": 5
  },
  {
    "target": 280,
    "numbers": [
      4,
      10,
      14,
      20,
      25
    ],
    "solutions": [
      "14 * 20",
      "4 + 10 * 20",
      "4 * 10 - 20 * 14"
    ],
    "total_valid_canonical": 14
  },
  {
    "target": 288,
    "numbers": [
      2,
      6,
      12,
      20,
      24
    ],
    "solutions": [
      "12 * 24",
      "24 * 2 * 6",
      "12 * 2 + 24 * 6"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 300,
    "numbers": [
      10,
      12,
      20,
      25,
      50
    ],
    "solutions": [
      "12 * 25",
      "25 - 10 * 20",
      "25 * 10 + 50"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 320,
    "numbers": [
      4,
      10,
      16,
      20,
      25
    ],
    "solutions": [
      "16 * 20",
      "16 + 20 - 4 * 10",
      "16 - 4 + 20 * 10"
    ],
    "total_valid_canonical": 13
  },
  {
    "target": 330,
    "numbers": [
      2,
      10,
      15,
      22,
      25
    ],
    "solutions": [
      "15 * 22",
      "25 - 10 * 22",
      "15 * 2 - 22 + 25 * 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 350,
    "numbers": [
      5,
      10,
      14,
      25,
      50
    ],
    "solutions": [
      "14 * 25",
      "50 - 25 * 14",
      "14 * 5 / 10 * 50"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 360,
    "numbers": [
      6,
      10,
      18,
      20,
      25
    ],
    "solutions": [
      "18 * 20",
      "20 - 6 * 25 + 10",
      "18 / 6 - 10 + 25 * 20"
    ],
    "total_valid_canonical": 11
  },
  {
    "target": 375,
    "numbers": [
      5,
      10,
      15,
      25,
      50
    ],
    "solutions": [
      "15 * 25",
      "25 + 50 * 5",
      "5 + 10 * 25"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 380,
    "numbers": [
      2,
      5,
      19,
      20,
      25
    ],
    "solutions": [
      "19 * 20",
      "25 - 5 * 19",
      "19 + 2 - 5 * 25 - 20"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 400,
    "numbers": [
      10,
      16,
      20,
      25,
      50
    ],
    "solutions": [
      "16 * 25",
      "50 - 25 * 16",
      "16 * 10 / 20 * 50"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 420,
    "numbers": [
      3,
      7,
      20,
      21,
      25
    ],
    "solutions": [
      "20 * 21",
      "20 * 3 * 7",
      "3 - 7 + 25 * 20"
    ],
    "total_valid_canonical": 5
  },
  {
    "target": 440,
    "numbers": [
      2,
      10,
      20,
      22,
      25
    ],
    "solutions": [
      "20 * 22",
      "22 * 2 * 10",
      "20 + 22 + 2 * 10"
    ],
    "total_valid_canonical": 10
  },
  {
    "target": 450,
    "numbers": [
      5,
      10,
      18,
      25,
      50
    ],
    "solutions": [
      "18 * 25",
      "50 - 25 * 18",
      "50 - 5 * 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 480,
    "numbers": [
      4,
      10,
      20,
      24,
      25
    ],
    "solutions": [
      "20 * 24",
      "20 + 24 + 4 * 10",
      "20 * 25 - 24 + 4"
    ],
    "total_valid_canonical": 12
  },
  {
    "target": 500,
    "numbers": [
      10,
      20,
      25,
      50,
      100
    ],
    "solutions": [
      "20 * 25",
      "10 * 50",
      "20 - 10 * 50"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 525,
    "numbers": [
      5,
      10,
      21,
      25,
      50
    ],
    "solutions": [
      "21 * 25",
      "10 * 50 + 25",
      "50 - 25 * 21"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 550,
    "numbers": [
      2,
      10,
      22,
      25,
      50
    ],
    "solutions": [
      "22 * 25",
      "22 / 2 * 50",
      "22 * 50 / 2"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 560,
    "numbers": [
      4,
      10,
      20,
      25,
      28
    ],
    "solutions": [
      "20 * 28",
      "4 * 10 - 20 * 28",
      "25 - 20 * 28 * 4"
    ],
    "total_valid_canonical": 12
  },
  {
    "target": 600,
    "numbers": [
      10,
      20,
      24,
      25,
      50
    ],
    "solutions": [
      "24 * 25",
      "50 - 25 * 24",
      "24 * 10 / 20 * 50"
    ],
    "total_valid_canonical": 13
  },
  {
    "target": 625,
    "numbers": [
      5,
      10,
      25,
      25,
      50
    ],
    "solutions": [
      "25 * 25",
      "50 - 25 * 25",
      "25 * 5 * 50 / 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 650,
    "numbers": [
      2,
      10,
      25,
      26,
      50
    ],
    "solutions": [
      "25 * 26",
      "26 / 2 * 50",
      "26 * 50 / 2"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 700,
    "numbers": [
      4,
      10,
      25,
      28,
      50
    ],
    "solutions": [
      "25 * 28",
      "4 + 10 * 50",
      "50 - 25 * 28"
    ],
    "total_valid_canonical": 12
  },
  {
    "target": 720,
    "numbers": [
      6,
      10,
      20,
      25,
      36
    ],
    "solutions": [
      "20 * 36",
      "20 + 10 * 25 - 36 + 6",
      "20 + 10 * 25 + 6 - 36"
    ],
    "total_valid_canonical": 7
  },
  {
    "target": 750,
    "numbers": [
      10,
      20,
      25,
      30,
      50
    ],
    "solutions": [
      "25 * 30",
      "25 - 10 * 50",
      "25 + 50 * 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 800,
    "numbers": [
      4,
      10,
      25,
      32,
      50
    ],
    "solutions": [
      "25 * 32",
      "50 - 25 * 32",
      "25 * 10 - 50 * 4"
    ],
    "total_valid_canonical": 12
  },
  {
    "target": 840,
    "numbers": [
      6,
      10,
      20,
      25,
      42
    ],
    "solutions": [
      "20 * 42",
      "42 / 6 + 10 + 25 * 20",
      "42 - 10 - 25 * 20 * 6"
    ],
    "total_valid_canonical": 6
  },
  {
    "target": 850,
    "numbers": [
      2,
      10,
      25,
      34,
      50
    ],
    "solutions": [
      "25 * 34",
      "34 / 2 * 50",
      "34 * 50 / 2"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 900,
    "numbers": [
      5,
      10,
      20,
      45,
      50
    ],
    "solutions": [
      "20 * 45",
      "50 - 5 * 20",
      "45 - 5 + 50 * 10"
    ],
    "total_valid_canonical": 15
  },
  {
    "target": 950,
    "numbers": [
      2,
      10,
      25,
      38,
      50
    ],
    "solutions": [
      "25 * 38",
      "38 / 2 * 50",
      "38 * 50 / 2"
    ],
    "total_valid_canonical": 9
  },
  {
    "target": 1000,
    "numbers": [
      10,
      20,
      25,
      40,
      50
    ],
    "solutions": [
      "25 * 40",
      "20 * 50",
      "40 + 10 * 20"
    ],
    "total_valid_canonical": 15
  }
];


// Automated Solver Engine for Pro Mode Full Solutions
function solveProPuzzle(target, numbers) {
  const ops = ['+', '-', '*', '/'];
  const uniqueCanonical = new Map();

  function permute(arr) {
    if (arr.length === 1) return [arr];
    let res = [];
    for (let i = 0; i < arr.length; i++) {
      let current = arr[i];
      let remaining = arr.slice(0, i).concat(arr.slice(i + 1));
      for (let p of permute(remaining)) {
        res.push([current].concat(p));
      }
    }
    return res;
  }

  function getSubsets(arr) {
    let res = [];
    function helper(start, current) {
      if (current.length >= 2) res.push([...current]);
      for (let i = start; i < arr.length; i++) {
        current.push(arr[i]);
        helper(i + 1, current);
        current.pop();
      }
    }
    helper(0, []);
    return res;
  }

  function buildTrees(numArr) {
    if (numArr.length === 1) return [String(numArr[0])];
    let trees = [];
    for (let i = 1; i < numArr.length; i++) {
      let leftArr = numArr.slice(0, i);
      let rightArr = numArr.slice(i);
      let leftTrees = buildTrees(leftArr);
      let rightTrees = buildTrees(rightArr);
      for (let l of leftTrees) {
        for (let r of rightTrees) {
          for (let op of ops) {
            trees.push('(' + l + ' ' + op + ' ' + r + ')');
          }
        }
      }
    }
    return trees;
  }

  const subsets = getSubsets(numbers);
  for (let sub of subsets) {
    const orderings = permute(sub);
    for (let ord of orderings) {
      const exprs = buildTrees(ord);
      for (let expr of exprs) {
        const evalRes = parseAndEvaluate(expr, numbers, 'pro');
        if (evalRes.valid && evalRes.value === target) {
          if (!uniqueCanonical.has(evalRes.canonical)) {
            uniqueCanonical.set(evalRes.canonical, expr);
          }
        }
      }
    }
  }
  return Array.from(uniqueCanonical.values());
}

// Curated Pro Puzzles Pool
const CURATED_PRO_PUZZLES = [
  {
    "target": 29,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((3 * (10 - 7)) + 20)",
      "((3 + (10 * 20)) / 7)",
      "((3 * (20 - 7)) - 10)",
      "((7 * (10 - 3)) - 20)",
      "(20 - (3 * (7 - 10)))",
      "(((3 * 14) + 7) - 20)",
      "((3 * 14) + (7 - 20))",
      "(((3 * 14) - 20) + 7)",
      "((3 * 14) - (20 - 7))",
      "(7 - (20 - (3 * 14)))"
    ]
  },
  {
    "target": 33,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(3 * ((7 - 10) + 14))",
      "(3 * (7 - (10 - 14)))",
      "(3 * ((7 + 14) - 10))",
      "(3 * (7 + (14 - 10)))",
      "((3 - 14) * (7 - 10))",
      "(3 * (14 - (10 - 7)))",
      "((10 - 7) * (14 - 3))",
      "(3 + 10) + 20",
      "3 + (10 + 20)",
      "(3 + 20) + 10"
    ]
  },
  {
    "target": 46,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((7 - 3) * 14) - 10)",
      "((3 - (7 / 10)) * 20)",
      "(3 * 20) - 14",
      "(((3 + 20) / 7) * 14)",
      "((3 + 20) / (7 / 14))",
      "(((3 + 20) * 14) / 7)",
      "((3 + 20) * (14 / 7))",
      "(14 / (7 / (3 + 20)))",
      "(((10 - 7) * 20) - 14)"
    ]
  },
  {
    "target": 48,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(3 * ((10 - 14) + 20))",
      "(3 * (10 - (14 - 20)))",
      "(3 * ((10 + 20) - 14))",
      "(3 * (10 + (20 - 14)))",
      "(3 * (14 + (20 / 10)))",
      "(3 * (20 - (14 - 10)))",
      "((7 * (14 - 10)) + 20)",
      "(20 - (7 * (10 - 14)))"
    ]
  },
  {
    "target": 55,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((3 * 7) + 14) + 20)",
      "((3 * 7) + (14 + 20))",
      "(((3 * 7) + 20) + 14)",
      "(((3 * 14) - 7) + 20)",
      "((3 * 14) - (7 - 20))",
      "(((3 * 14) + 20) - 7)",
      "((3 * 14) + (20 - 7))",
      "(20 - (7 - (3 * 14)))"
    ]
  },
  {
    "target": 59,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((3 + (7 * 10)) - 14)",
      "(3 + ((7 * 10) - 14))",
      "((3 - 14) + (7 * 10))",
      "(3 - (14 - (7 * 10)))",
      "(((3 * 14) + 7) + 10)",
      "((3 * 14) + (7 + 10))",
      "(((3 * 14) + 10) + 7)",
      "((7 * 10) - (14 - 3))"
    ]
  },
  {
    "target": 62,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((3 + (10 / 7)) * 14)",
      "(3 * 14) + 20",
      "((3 * 20) + (14 / 7))",
      "(((10 * 20) - 14) / 3)",
      "(((10 - 7) * 14) + 20)",
      "(20 - ((7 - 10) * 14))"
    ]
  },
  {
    "target": 68,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((7 * 14) - (3 * 10))",
      "((3 - 20) * (10 - 14))",
      "((14 - 10) * (20 - 3))",
      "((7 * 14) - (10 + 20))",
      "(((7 * 14) - 10) - 20)",
      "(((7 * 14) - 20) - 10)"
    ]
  },
  {
    "target": 72,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "3 * (10 + 14)",
      "(((3 * 14) + 10) + 20)",
      "((3 * 14) + (10 + 20))",
      "(3 * ((14 - 10) + 20))",
      "(3 * (14 - (10 - 20)))",
      "(((3 * 14) + 20) + 10)",
      "(3 * ((14 + 20) - 10))",
      "(3 * (14 + (20 - 10)))",
      "(3 * (20 - (10 - 14)))"
    ]
  },
  {
    "target": 73,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "3 + (7 * 10)",
      "(3 - ((7 - 14) * 10))",
      "((3 * (7 + 14)) + 10)",
      "(3 + (10 * (14 - 7)))",
      "(3 - (7 * (10 - 20)))",
      "(3 + (7 * (20 - 10)))",
      "(((14 - 10) * 20) - 7)"
    ]
  },
  {
    "target": 76,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((7 - 3) * 14) + 20)",
      "(20 - ((3 - 7) * 14))",
      "((3 * (10 + 20)) - 14)",
      "(((7 * 10) - 14) + 20)",
      "((7 * 10) - (14 - 20))",
      "(((7 * 10) + 20) - 14)",
      "((7 * 10) + (20 - 14))",
      "(20 - (14 - (7 * 10)))"
    ]
  },
  {
    "target": 77,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "7 * (14 - 3)",
      "(((3 + 10) * 7) - 14)",
      "(((3 * 20) + 7) + 10)",
      "((3 * 20) + (7 + 10))",
      "(((3 * 20) + 10) + 7)",
      "(((14 - 10) * 20) - 3)",
      "((7 + (14 / 20)) * 10)"
    ]
  },
  {
    "target": 80,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(7 - 3) * 20",
      "(((3 + 7) * 10) - 20)",
      "((14 - (3 + 7)) * 20)",
      "(((14 - 3) - 7) * 20)",
      "(((14 - 7) - 3) * 20)",
      "(14 - 10) * 20",
      "((10 * 14) - (3 * 20))",
      "(7 * (10 + (20 / 14)))"
    ]
  },
  {
    "target": 88,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(7 * 14) - 10",
      "((3 + (14 / 10)) * 20)",
      "(((7 * 14) + 10) - 20)",
      "((7 * 14) + (10 - 20))",
      "(((7 * 14) - 20) + 10)",
      "((7 * 14) - (20 - 10))",
      "(10 - (20 - (7 * 14)))"
    ]
  },
  {
    "target": 93,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(3 * ((7 + 10) + 14))",
      "(3 * (7 + (10 + 14)))",
      "(3 * ((7 + 14) + 10))",
      "((3 + (7 * 10)) + 20)",
      "(3 + ((7 * 10) + 20))",
      "((3 + 20) + (7 * 10))"
    ]
  },
  {
    "target": 98,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "7 * 14",
      "(10 - 3) * 14",
      "((7 * 20) - (3 * 14))",
      "(14 * (20 - (3 + 10)))",
      "(14 * ((20 - 3) - 10))",
      "(14 * ((20 - 10) - 3))"
    ]
  },
  {
    "target": 105,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((3 + 10) * 7) + 14)",
      "(7 - ((3 - 10) * 14))",
      "(7 + ((10 - 3) * 14))",
      "(((7 * 14) - 3) + 10)",
      "((7 * 14) - (3 - 10))",
      "(((7 * 14) + 10) - 3)",
      "((7 * 14) + (10 - 3))",
      "(10 - (3 - (7 * 14)))",
      "((7 * (20 - 3)) - 14)",
      "((7 + (10 / 20)) * 14)"
    ]
  },
  {
    "target": 108,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(7 * 14) + 10",
      "(((7 * 14) - 10) + 20)",
      "((7 * 14) - (10 - 20))",
      "(((7 * 14) + 20) - 10)",
      "((7 * 14) + (20 - 10))",
      "((7 + 20) * (14 - 10))",
      "(20 - (10 - (7 * 14)))"
    ]
  },
  {
    "target": 111,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "((3 + (7 * 14)) + 10)",
      "(3 + ((7 * 14) + 10))",
      "((3 + 10) + (7 * 14))",
      "(3 * ((7 + 10) + 20))",
      "(3 * (7 + (10 + 20)))",
      "(3 * ((7 + 20) + 10))",
      "(((3 + 10) * 7) + 20)"
    ]
  },
  {
    "target": 112,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((3 * 10) - 14) * 7)",
      "((3 * 14) + (7 * 10))",
      "((3 * (14 + 20)) + 10)",
      "(7 * ((10 - 14) + 20))",
      "(7 * (10 - (14 - 20)))",
      "(7 * ((10 + 20) - 14))",
      "(7 * (10 + (20 - 14)))",
      "((7 - (14 / 10)) * 20)",
      "(7 * (14 + (20 / 10)))",
      "(7 * (20 - (14 - 10)))"
    ]
  },
  {
    "target": 115,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(((7 * 14) - 3) + 20)",
      "((7 * 14) - (3 - 20))",
      "(((7 * 14) + 20) - 3)",
      "((7 * 14) + (20 - 3))",
      "(20 - (3 - (7 * 14)))"
    ]
  },
  {
    "target": 117,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(7 - ((3 - 14) * 10))",
      "(7 + (10 * (14 - 3)))",
      "((10 * 14) - (3 + 20))",
      "(((10 * 14) - 3) - 20)",
      "(((10 * 14) - 20) - 3)"
    ]
  },
  {
    "target": 119,
    "numbers": [
      3,
      7,
      10,
      14,
      20
    ],
    "solutions": [
      "(3 + 14) * 7",
      "((10 * 14) - (3 * 7))",
      "7 * (20 - 3)",
      "((3 - 20) * (7 - 14))",
      "((14 - 7) * (20 - 3))"
    ]
  },
  {
    "target": 37,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "((2 * (11 - 5)) + 25)",
      "(25 - (2 * (5 - 11)))",
      "12 + 25",
      "((2 + (5 * 12)) - 25)",
      "(2 + ((5 * 12) - 25))",
      "((2 - 25) + (5 * 12))",
      "(2 - (25 - (5 * 12)))",
      "((5 * 12) - (25 - 2))",
      "((2 * (25 - 12)) + 11)",
      "(11 - (2 * (12 - 25)))"
    ]
  },
  {
    "target": 47,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(((5 - 2) * 12) + 11)",
      "((5 * 12) - (2 + 11))",
      "(((5 * 12) - 2) - 11)",
      "(((5 * 12) - 11) - 2)",
      "(11 - ((2 - 5) * 12))",
      "(2 * 11) + 25",
      "(((2 * 5) + 12) + 25)",
      "((2 * 5) + (12 + 25))",
      "(((2 * 5) + 25) + 12)",
      "(((11 - 5) * 12) - 25)"
    ]
  },
  {
    "target": 56,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(2 * ((5 + 11) + 12))",
      "(2 * (5 + (11 + 12)))",
      "(2 * ((5 + 12) + 11))",
      "(((2 * 25) - 5) + 11)",
      "((2 * 25) - (5 - 11))",
      "(((2 * 25) + 11) - 5)",
      "((2 * 25) + (11 - 5))",
      "(11 - (5 - (2 * 25)))"
    ]
  },
  {
    "target": 58,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(5 * 12) - 2",
      "(((5 - 2) * 11) + 25)",
      "(25 - ((2 - 5) * 11))",
      "(((12 / 5) * 25) - 2)",
      "((12 / (5 / 25)) - 2)",
      "(((12 * 25) / 5) - 2)",
      "((12 * (25 / 5)) - 2)",
      "((25 / (5 / 12)) - 2)",
      "((5 * (25 - 11)) - 12)"
    ]
  },
  {
    "target": 63,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "((2 - 11) * (5 - 12))",
      "((11 - 2) * (12 - 5))",
      "(((5 - 2) * 25) - 12)",
      "((5 * (25 - 12)) - 2)",
      "((2 * (12 + 25)) - 11)"
    ]
  },
  {
    "target": 64,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(((5 - 2) * 25) - 11)",
      "(2 * ((12 - 5) + 25))",
      "(2 * (12 - (5 - 25)))",
      "(2 * ((12 + 25) - 5))",
      "(2 * (12 + (25 - 5)))",
      "(2 * (25 - (5 - 12)))"
    ]
  },
  {
    "target": 66,
    "numbers": [
      2,
      5,
      11,
      12,
      25
    ],
    "solutions": [
      "(11 / 2) * 12",
      "11 / (2 / 12)",
      "(11 * 12) / 2",
      "11 * (12 / 2)",
      "12 / (2 / 11)",
      "(((2 * 25) + 5) + 11)",
      "((2 * 25) + (5 + 11))",
      "(((2 * 25) + 11) + 5)"
    ]
  }
];


// Lightweight Auto-Puzzle Generator Engine
function autoGenerateDailyPuzzle(dateStr, gameMode = 'speed') {
  try {
    const pool = (gameMode === 'pro') ? CURATED_PRO_PUZZLES : CURATED_SPEED_PUZZLES;
    
    let hash = 0;
    const strToHash = dateStr + '_' + gameMode;
    for (let i = 0; i < strToHash.length; i++) {
      hash = (hash << 5) - hash + strToHash.charCodeAt(i);
      hash |= 0;
    }
    const idx = Math.abs(hash) % pool.length;
    const selected = pool[idx];

    const stmt = db.prepare(`
      INSERT OR IGNORE INTO daily_puzzles (puzzle_date, game_mode, target, numbers, solutions_json)
      VALUES (?, ?, ?, ?, ?)
    `);

    let puzzleSolutions = selected.solutions;

    stmt.run(
      dateStr,
      gameMode,
      selected.target,
      JSON.stringify(selected.numbers),
      JSON.stringify(puzzleSolutions)
    );

    return db.prepare('SELECT * FROM daily_puzzles WHERE puzzle_date = ? AND game_mode = ?').get(dateStr, gameMode);
  } catch (err) {
    console.error('Error generating daily puzzle:', err);
    const pool = (gameMode === 'pro') ? CURATED_PRO_PUZZLES : CURATED_SPEED_PUZZLES;
    const fallback = pool[0];
    return {
      puzzle_date: dateStr,
      game_mode: gameMode,
      target: fallback.target,
      numbers: JSON.stringify(fallback.numbers),
      solutions_json: JSON.stringify(fallback.solutions)
    };
  }
}

// Get daily puzzle or auto-generate on demand
function getOrGenerateDailyPuzzle(dateStr, gameMode = 'speed') {
  let puzzle = db.prepare('SELECT * FROM daily_puzzles WHERE puzzle_date = ? AND game_mode = ?').get(dateStr, gameMode);
  if (!puzzle) {
    puzzle = autoGenerateDailyPuzzle(dateStr, gameMode);
  } else if (gameMode === 'speed') {
    try {
      let currentSols = JSON.parse(puzzle.solutions_json || '[]');
      let canons = currentSols.map(s => getCanonicalFormSpeed(s));
      let uniqueCanons = new Set(canons);
      if (canons.length === 0 || uniqueCanons.size < canons.length || currentSols.length < 3) {
        let hash = 0;
        const strToHash = dateStr + '_speed';
        for (let i = 0; i < strToHash.length; i++) {
          hash = (hash << 5) - hash + strToHash.charCodeAt(i);
          hash |= 0;
        }
        const idx = Math.abs(hash) % CURATED_SPEED_PUZZLES.length;
        const selected = CURATED_SPEED_PUZZLES[idx];
        
        const newTarget = selected.target;
        const newNumbers = JSON.stringify(selected.numbers);
        const newSolutions = JSON.stringify(selected.solutions);

        db.prepare('UPDATE daily_puzzles SET target = ?, numbers = ?, solutions_json = ? WHERE id = ?')
          .run(newTarget, newNumbers, newSolutions, puzzle.id);

        puzzle.target = newTarget;
        puzzle.numbers = newNumbers;
        puzzle.solutions_json = newSolutions;
      }
    } catch (e) {
      console.error('Speed puzzle upgrade check error:', e);
    }
  } else if (gameMode === 'pro') {
    try {
      let currentSols = JSON.parse(puzzle.solutions_json || '[]');
      // If puzzle has more than 10 or fewer than 5 solutions, swap to a curated 5-10 solution puzzle
      if (currentSols.length > 10 || currentSols.length < 5) {
        let hash = 0;
        const strToHash = dateStr + '_pro';
        for (let i = 0; i < strToHash.length; i++) {
          hash = (hash << 5) - hash + strToHash.charCodeAt(i);
          hash |= 0;
        }
        const idx = Math.abs(hash) % CURATED_PRO_PUZZLES.length;
        const selected = CURATED_PRO_PUZZLES[idx];
        
        const newTarget = selected.target;
        const newNumbers = JSON.stringify(selected.numbers);
        const newSolutions = JSON.stringify(selected.solutions);

        db.prepare('UPDATE daily_puzzles SET target = ?, numbers = ?, solutions_json = ? WHERE id = ?')
          .run(newTarget, newNumbers, newSolutions, puzzle.id);

        puzzle.target = newTarget;
        puzzle.numbers = newNumbers;
        puzzle.solutions_json = newSolutions;
      }
    } catch (e) {
      console.error('Pro puzzle 5-10 solution filter error:', e);
    }
  }
  return puzzle;
}


// --- PRIVATE GROUPS & LEAGUES HELPERS ---

function generateJoinCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = 'QS-';
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

function createGroup(name, ownerId, isPublic = 0) {
  let joinCode = generateJoinCode();
  let attempts = 0;
  while (attempts < 10) {
    const existing = db.prepare('SELECT id FROM groups WHERE join_code = ?').get(joinCode);
    if (!existing) break;
    joinCode = generateJoinCode();
    attempts++;
  }

  const res = db.prepare('INSERT INTO groups (name, join_code, owner_id, is_public) VALUES (?, ?, ?, ?)').run(name.trim(), joinCode, ownerId, isPublic ? 1 : 0);
  const groupId = res.lastInsertRowid;

  db.prepare('INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?, ?)').run(groupId, ownerId);

  return getGroupById(groupId, ownerId);
}

function getGroupById(groupId, currentUserId = null) {
  const group = db.prepare(`
    SELECT g.*, u.username as owner_username,
           (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) as member_count
    FROM groups g
    JOIN users u ON g.owner_id = u.id
    WHERE g.id = ?
  `).get(groupId);

  if (group && currentUserId) {
    group.is_owner = Boolean(group.owner_id === currentUserId);
    group.is_member = Boolean(db.prepare('SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, currentUserId));
  }
  return group;
}

function getGroupByCode(joinCode, currentUserId = null) {
  const cleanCode = (joinCode || '').trim().toUpperCase();
  const group = db.prepare('SELECT id FROM groups WHERE UPPER(join_code) = ?').get(cleanCode);
  if (!group) return null;
  return getGroupById(group.id, currentUserId);
}

function joinGroup(joinCode, userId) {
  const group = getGroupByCode(joinCode, userId);
  if (!group) {
    throw new Error('Invalid or expired join code.');
  }

  db.prepare('INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?, ?)').run(group.id, userId);
  return getGroupById(group.id, userId);
}

function getUserGroups(userId) {
  const rows = db.prepare(`
    SELECT g.id, g.name, g.join_code, g.owner_id, g.is_public, g.created_at,
           u.username as owner_username,
           (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) as member_count,
           (g.owner_id = ?) as is_owner
    FROM groups g
    JOIN group_members gm ON g.id = gm.group_id
    JOIN users u ON g.owner_id = u.id
    WHERE gm.user_id = ?
    ORDER BY g.id DESC
  `).all(userId, userId);
  return rows;
}

function getGroupMembers(groupId) {
  const members = db.prepare(`
    SELECT u.id as user_id, u.username, u.email, gm.joined_at
    FROM group_members gm
    JOIN users u ON gm.user_id = u.id
    WHERE gm.group_id = ?
    ORDER BY gm.joined_at ASC
  `).all(groupId);
  return members;
}

function getGroupLeaderboard(groupId, puzzleDate, gameMode = 'speed', type = 'daily', reqUserId = 0) {
  const reqUid = reqUserId || 0;
  if (type === 'weekly') {
    const d = new Date(puzzleDate);
    d.setDate(d.getDate() - 7);
    const sevenDaysAgo = d.toISOString().split('T')[0];

    return db.prepare(`
      SELECT l.username, 
             SUM(l.solutions_count) as solutions_count, 
             SUM(l.active_time_ms) as active_time_ms, 
             COUNT(DISTINCT l.puzzle_date) as games_played
      FROM leaderboards l
      JOIN group_members gm ON l.user_id = gm.user_id
      WHERE gm.group_id = ? AND l.puzzle_date >= ? AND l.game_mode = ?
        AND (l.is_flagged IS NULL OR l.is_flagged = 0 OR l.user_id = ?)
      GROUP BY l.user_id, l.username
      ORDER BY solutions_count DESC, active_time_ms ASC
    `).all(groupId, sevenDaysAgo, gameMode, reqUid);
  } else if (type === 'overall') {
    return db.prepare(`
      SELECT l.username, 
             SUM(l.solutions_count) as solutions_count, 
             SUM(l.active_time_ms) as active_time_ms, 
             COUNT(DISTINCT l.puzzle_date) as games_played
      FROM leaderboards l
      JOIN group_members gm ON l.user_id = gm.user_id
      WHERE gm.group_id = ? AND l.game_mode = ?
        AND (l.is_flagged IS NULL OR l.is_flagged = 0 OR l.user_id = ?)
      GROUP BY l.user_id, l.username
      ORDER BY solutions_count DESC, active_time_ms ASC
    `).all(groupId, gameMode, reqUid);
  } else {
    return db.prepare(`
      SELECT l.username, l.solutions_count, l.active_time_ms, l.created_at
      FROM leaderboards l
      JOIN group_members gm ON l.user_id = gm.user_id
      WHERE gm.group_id = ? AND l.puzzle_date = ? AND l.game_mode = ?
        AND (l.is_flagged IS NULL OR l.is_flagged = 0 OR l.user_id = ?)
      ORDER BY l.solutions_count DESC, l.active_time_ms ASC
    `).all(groupId, puzzleDate, gameMode, reqUid);
  }
}

function getPublicGroups() {
  return db.prepare(`
    SELECT g.id, g.name, g.join_code, g.created_at,
           u.username as owner_username,
           (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) as member_count
    FROM groups g
    JOIN users u ON g.owner_id = u.id
    WHERE g.is_public = 1
    ORDER BY member_count DESC, g.id DESC
    LIMIT 50
  `).all();
}

function getGroupsStats() {
  const totalGroups = db.prepare('SELECT COUNT(*) as count FROM groups').get().count;
  const totalPlayersInGroups = db.prepare('SELECT COUNT(DISTINCT user_id) as count FROM group_members').get().count;
  return { total_groups: totalGroups, total_group_players: totalPlayersInGroups };
}

function kickGroupMember(groupId, ownerId, targetUserId) {
  const group = db.prepare('SELECT owner_id FROM groups WHERE id = ?').get(groupId);
  if (!group || group.owner_id !== ownerId) {
    throw new Error('Only the group admin can remove members.');
  }
  if (targetUserId === ownerId) {
    throw new Error('Group admin cannot kick themselves. Delete group or leave instead.');
  }
  db.prepare('DELETE FROM group_members WHERE group_id = ? AND user_id = ?').run(groupId, targetUserId);
  return true;
}

function leaveGroup(groupId, userId) {
  const group = db.prepare('SELECT owner_id FROM groups WHERE id = ?').get(groupId);
  if (!group) throw new Error('Group not found.');
  if (group.owner_id === userId) {
    const nextMember = db.prepare('SELECT user_id FROM group_members WHERE group_id = ? AND user_id != ? ORDER BY joined_at ASC').get(groupId, userId);
    if (nextMember) {
      db.prepare('UPDATE groups SET owner_id = ? WHERE id = ?').run(nextMember.user_id, groupId);
    } else {
      db.prepare('DELETE FROM groups WHERE id = ?').run(groupId);
    }
  }
  db.prepare('DELETE FROM group_members WHERE group_id = ? AND user_id = ?').run(groupId, userId);
  return true;
}

function resetGroupCode(groupId, ownerId) {
  const group = db.prepare('SELECT owner_id FROM groups WHERE id = ?').get(groupId);
  if (!group || group.owner_id !== ownerId) {
    throw new Error('Only the group admin can reset the join code.');
  }
  let newCode = generateJoinCode();
  db.prepare('UPDATE groups SET join_code = ? WHERE id = ?').run(newCode, groupId);
  return newCode;
}


module.exports = {
  db,
  parseAndEvaluate,
  getCanonicalForm,
  getOrGenerateDailyPuzzle,
  createGroup,
  getGroupById,
  getGroupByCode,
  joinGroup,
  getUserGroups,
  getGroupMembers,
  getGroupLeaderboard,
  getPublicGroups,
  getGroupsStats,
  kickGroupMember,
  leaveGroup,
  resetGroupCode
};
